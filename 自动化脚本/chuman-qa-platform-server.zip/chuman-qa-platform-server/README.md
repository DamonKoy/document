








## 项目简介

我们选择了python语言作为QA测试平台的编程语言，项目中主要用到flask、layUI框架。

### 项目环境配置

1. 安装python3

2. 安装虚拟环境，并创建激活虚拟环境

   ```shell
   sudo python3 -m pip install virtualenv
   python3 -m virtualenv venv
   ```

3. 进入项目，安装依赖：

   ```shell
   pip install -r requirements.txt
   ```

### 项目文件目录结构

```shell
.
├── README.md								    // 说明文档
├── api
│   ├── app_api.py								// app相关api
│   └── web_api.py								// 后台相关api
├── app
│   ├── models.py								// models层
│   └── views
│       ├── api_test.py						    // 接口自动化视图
│       ├── home.py								// 首页视图
│       └── toolbox.py						    // 工具箱视图
├── config
│   ├── env_config.yaml						    // 环境配置
│   └── log_config.yaml						    // 日志配置
├── conftest.py										
├── gunicorn.conf.py							// gunicorn配置文件
├── manage.py									// 管理
├── requirements.txt							// 记录依赖库文档
├── static										// 静态资源
│   ├── js
│   └── layui									// 引入的layui库
├── templates									// 模板
│   ├── api_test								// 接口自动化模板
│   ├── error.html
│   ├── home.html								// 首页模板
│   ├── index.html
│   ├── response.html
│   └── toolbox									// 工具箱模板
└── testcases									// 用例组装



```

### 项目运行

平常进行调试则执行

```python
python manage.py runserver -r -d
```

指定ip和端口，IP：0.0.0.0 时即为对外公开

```python
python manager.py runserver --host 0.0.0.0 --port 5000
```

在服务器上使用gunicorn进行启动

```python
gunicorn manage:app -c gunicorn.conf.py
```

本地调试链接：

 http://127.0.0.1:5000/ 

开机不自动启动防火墙

```
sudo systemctl disable firewalld.service
```

关闭防火墙

```
sudo systemctl stop firewalld.service
```

