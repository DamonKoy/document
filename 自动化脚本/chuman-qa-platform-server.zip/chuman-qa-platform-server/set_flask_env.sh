ENV=$1

if [ ! ${ENV} ]
then
    ENV=local
fi

export FLASK_ENV=${ENV}