# -*- coding: utf-8 -*-
# 定义路由及视图函数
# Flask中定义路由是通过装饰器实现的

from flask import Blueprint, render_template, url_for, redirect
from app.models.models import OperationLog

home_blue = Blueprint('home_blue', __name__)


@home_blue.route('/')
def index():
    return redirect(url_for('home_blue.home'))


@home_blue.route('/home/', methods=['GET'])  # 路由默认只支持get方式
def home():
    OperationLog().add_log(function_name='进入首页', case='home', type='home')
    return render_template('home.html')


