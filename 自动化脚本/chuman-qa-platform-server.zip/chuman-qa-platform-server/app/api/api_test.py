# -*- coding: utf-8 -*-
# 定义路由及视图函数
# Flask中定义路由是通过装饰器实现的
import os
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor


from flask import Blueprint, render_template, request, make_response
from app.models.models import db, OperationLog

api_test_blue = Blueprint('api_test_blue', __name__)

__running_tasks = []
__tasks = []


@api_test_blue.route('/api_test/module_list', methods=['GET'])
def module_list():
    return render_template('api_test/module_list.html')


@api_test_blue.route('/api_test/task_list', methods=['GET'])
def task_list():
    return render_template('api_test/task_list.html')


@api_test_blue.route('/api_test/get_task_list', methods=['GET'])
def get_task_list():
    page = int(request.args.get('page'))
    limit = int(request.args.get('limit'))
    start = (page - 1) * limit
    end = page * limit
    return {
        'code': 0,
        'count': len(__tasks),
        'data': __tasks[::-1][start:end]
    }


@api_test_blue.route('/api_test/get_module_list', methods=['GET'])
def get_module_list():
    case_path = '../chuman-api-test-new/testcases'
    module_list = []
    script_list = []
    data = []
    for file in os.listdir(case_path):
        if file.startswith('test_') and file.endswith('.py'):
            module = file[5:][:-3].title()
            module_list.append(module)
            script_list.append(file)
            data.append({'module': module, 'script': file})
    page = int(request.args.get('page'))
    limit = int(request.args.get('limit'))
    start = (page - 1) * limit
    end = page * limit
    resp = {
        'code': 0,
        'count': len(module_list),
        'data': data[start:end]
    }
    return resp


@api_test_blue.route('/api_test/run_api_testcase', methods=['GET'])
def run_api_testcase():
    """
    把要执行的接口用例加入到任务列表中
    """
    global __tasks
    global __running_tasks
    args = request.args
    scripts = args.get('scripts')
    modules = args.get('modules')
    env = args.get('env')
    cur_time = time.time()
    task_id = int(cur_time)
    strf_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(cur_time))
    execute_scripts = ''
    if scripts == 'all':
        execute_scripts = 'testcases/'
    else:
        scripts = scripts.split(',')[:-1]
        execute_scripts = " ".join(['testcases/' + script + " " for script in scripts])
    cmd1 = 'cd ../chuman-api-test-new'
    cmd2 = 'pipenv install --skip-lock'
    cmd3 = f'pipenv run pytest --env={env} {execute_scripts}'
    cmd4 = f'allure generate reports -o ../chuman-qa-platform-server/app/static/reports/{task_id}'
    cmd = cmd1 + ";  " + cmd2 + "; " + cmd3 + "; " + cmd4
    task_index = len(__tasks)
    task = {
        'env': env,
        'task_id': task_id,
        'time': strf_time,
        'modules': modules,
        'state': '运行中',
        'cmd': cmd,
        'task_index': task_index
    }
    __tasks.append(task)
    OperationLog().add_log(function_name='执行接口自动化任务', case='api_test', type=modules,
                           request_data=task)       # 将操作日志记录到数据库
    if len(__running_tasks) == 0:
        __running_tasks.append(task)
        pool = ThreadPoolExecutor(1)
        pool.submit(run_api_case)
    else:
        __running_tasks.append(task)
    return {
        'code': 0
    }


def run_api_case():
    """
    执行任务列表中的接口用例
    """
    global __tasks
    global __running_tasks
    while len(__running_tasks) != 0:
        exe_task = __running_tasks[0]
        task_id = exe_task['task_id']
        cmd = exe_task['cmd']
        task_index = exe_task['task_index']
        process = subprocess.Popen(cmd, shell=True)
        while process.poll() is None:
            time.sleep(1)
        __tasks[task_index]['state'] = '运行结束'
        __running_tasks.pop(0)


@api_test_blue.errorhandler(404)
def not_found(error):
    resp = make_response(render_template('error.html'), 404)
    resp.headers['X-Something'] = 'A value'
    return resp


