
from flask import Blueprint, render_template, request
from sqlalchemy import func
from app.models.models import db, OperationLog, Devices, DeviceTransferRecord
import json
from sqlalchemy import and_

devices_blue = Blueprint('devices_blue', __name__)


@devices_blue.route('/devices/device_list/', methods=['GET', 'POST'], strict_slashes=False)
def get_device_list():
    """获取设备列表数据"""
    # 通过数据库获取设备列表json数据
    if request.method == 'GET':
        OperationLog().add_log(function_name='查看设备列表', case='devices', type='get_device_list')
        return render_template('devices/device_list.html')
    elif request.method == 'POST':
        query_data = Devices.query.all()
        resp = {
            'code': 0,
            'msg': '',
            'count': 50,
            'data': Devices().get_query(query_data)
        }
        return resp


@devices_blue.route('/devices/update_holder/', methods=['GET', 'POST'], strict_slashes=False)
def update_holder():
    """更新设备持有人信息"""
    id = request.args.get('id')
    auditor = request.args.get('auditor')
    if request.method == 'GET':
        return render_template('/devices/update_holder.html')
    elif request.method == 'POST':
        original_holder = request.form.get('original_holder')
        current_holder = request.form.get('current_holder')
        remarks = request.form.get('remarks')
        print(remarks)
        try:
            Devices().update_holder(id=id, auditor=auditor, holder=current_holder)
        except Exception as e:
            print(e)
            return '更新设备持有人失败，请联系管理员'
        OperationLog().add_log(function_name='更新设备持有人信息', case='devices', type='update_holder',
                               request_data=[id, auditor, original_holder, current_holder, remarks],
                               result='更新成功')  # 添加日志到数据库
        DeviceTransferRecord().add_record(device_id=id, original_holder=original_holder,
                                          current_holder=current_holder, remarks=remarks)
        return '数据更新成功'


@devices_blue.route('/devices/device_transfer_record/', methods=['GET', 'POST'], strict_slashes=False)
def device_transfer_record():
    """查看设备转借记录"""
    if request.method == 'GET':
        OperationLog().add_log(function_name='查看设备转借记录', case='devices', type='device_transfer_record')
        return render_template('devices/device_transfer_record.html')
    elif request.method == 'POST':
        data = db.session.query(DeviceTransferRecord.id, Devices.model, Devices.brand, Devices.platform,
                                Devices.system_version, DeviceTransferRecord.current_holder,
                                DeviceTransferRecord.original_holder,
                                func.date_format(DeviceTransferRecord.create_time, '%Y-%m-%d %H:%i:%s').
                                label('create_time'), DeviceTransferRecord.remarks).\
            filter(Devices.id == DeviceTransferRecord.device_id).order_by(DeviceTransferRecord.id.desc()).all()

        # 注意，data 并不是标准的 Python tuple。你如果查看它的类型，会发现一个奇怪的名称：
        # <class 'sqlalchemy.util._collections.result'> 。它是一个 AbstractKeyedTuple 对象，
        # 拥有一个 keys() 方法，这样可以很容易将其转换成 dict ：
        resp = {
            'code': 0,
            'msg': '',
            'count': 50,
            'data': [dict(zip(i.keys(), i))for i in data]
        }
        return resp


@devices_blue.route('/devices/get_sreach_data/', methods=['GET', 'POST'], strict_slashes=False)
def get_sreach_data():
    """获取筛选条件对应的数据"""
    if request.method == 'POST':
        status_data = db.session.query(Devices.status).group_by(Devices.status).all()
        holder_data = db.session.query(Devices.holder).group_by(Devices.holder).all()
        a = [dict(zip(i.keys(), i))for i in status_data]
        # 将两个数组的元素合并
        a.extend([dict(zip(i.keys(), i))for i in holder_data])
        return json.dumps(a)


@devices_blue.route('/devices/device_search/', methods=['GET'], strict_slashes=False)
def device_search():
    """获取筛选条件对应的结果"""
    if request.method == 'GET':
        # 拼接查询条件
        param = []
        if ('search_name' in request.args) and (request.args['search_name']):
            search_name = request.args['search_name']
            param.append(Devices.model.like(f'%{search_name}%'))
        if ('status' in request.args) and (request.args['status']):
            status = request.args['status']
            param.append(Devices.status == status)
        if ('holder' in request.args) and (request.args['holder']):
            holder = request.args['holder']
            param.append(Devices.holder == holder)

        query_data = Devices.query.filter(*param).all()
        resp = {
            'code': 0,
            'msg': '',
            'count': 10,
            'data': Devices().get_query(query_data)
        }
        OperationLog().add_log(function_name='设备列表搜索', case='devices', type='device_search',
                               request_data=param)  # 添加日志到数据库
        return resp


@devices_blue.route('/devices/transfer_record_search/', methods=['GET'], strict_slashes=False)
def transfer_record_search():
    """获取筛选条件对应的结果"""
    if request.method == 'GET':
        # 拼接查询条件
        param = []
        if ('search_name' in request.args) and (request.args['search_name']):
            search_name = request.args['search_name']
            param.append(Devices.model.like(f'%{search_name}%'))

        data = db.session.query(DeviceTransferRecord.id, Devices.model, Devices.brand, Devices.platform,
                                Devices.system_version, DeviceTransferRecord.current_holder,
                                DeviceTransferRecord.original_holder,
                                func.date_format(DeviceTransferRecord.create_time, '%Y-%m-%d %H:%i:%s').
                                label('create_time'), DeviceTransferRecord.remarks).filter\
            (and_(Devices.id == DeviceTransferRecord.device_id, *param)).order_by(DeviceTransferRecord.id.desc()).all()
        resp = {
            'code': 0,
            'msg': '',
            'count': 50,
            'data': [dict(zip(i.keys(), i))for i in data]
        }
        OperationLog().add_log(function_name='设备转借记录搜索', case='devices', type='transfer_record_search',
                               request_data=param)  # 添加日志到数据库
        return resp