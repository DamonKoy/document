
import pymysql
import json

from flask import Blueprint
from flask import Flask, render_template, request
from app.utils.common import get_app_performance_list_json
from app.models.models import db, OperationLog


app_performance_blue = Blueprint('app_performance_blue', __name__)


@app_performance_blue.route('/app_performance/', methods=['GET'])
def toolbox_list():
    return render_template('app_performance/app_performance_list.html')


@app_performance_blue.route('/app_performance/get_app_performance_list/', methods=['GET'], strict_slashes=False)
def get_toolbox_list():
    """获取工具箱列表数据"""
    # 获取json文件
    performance_list = get_app_performance_list_json()
    resp = {
        'code': 0,
        'msg': '',
        'count': 50,
        'data': performance_list
    }
    return resp


@app_performance_blue.route('/app_performance/search_name/<search_name>/', methods=['GET'], strict_slashes=False)
def search_name(search_name):
    """专项测试列表模糊搜索"""
    search_list = []
    for i in get_app_performance_list_json():
        if search_name in i['name']:
            search_list.append(i)
        else:
            pass
    resp = {
        'code': 0,
        'msg': '',
        'count': 10,
        'data': search_list
    }
    OperationLog().add_log(function_name='专项测试列表搜索', case='app_performance', type='search_name',
                           request_data=search_name, result=resp)       # 添加日志到数据库
    return resp


def get_database():
    dd = pymysql.connect(host='192.168.216.210', port=4306, user='root', password='1z2x3c4v5b6n7m', charset='UTF8MB4')
    co = dd.cursor()
    co.execute('show databases like "chumanAndroid%";')
    database_names = co.fetchall()
    return database_names[-1][0], database_names[-2][0]   # 只获取最新2个版本

    # 获取所有版本并展示
    # lst = []
    # for i in range(0, len(database_names)):
    #     lst.append(database_names[i][0])
    # return lst


def fetch_all(database, tablename):
    db = pymysql.connect(host='192.168.216.210', port=4306, user='root',
                         password='1z2x3c4v5b6n7m', charset='UTF8MB4', database=database)
    con = db.cursor()
    con.execute(f'select native, dalvik, graphics, total, fps, cpu from {tablename}')
    new_all = con.fetchall()
    native, dalvik, graphics, total, fps, cpu = [], [], [], [], [], []
    for x in new_all:
        native.append(x[0])
        dalvik.append(x[1])
        graphics.append(x[2])
        total.append(x[3])
        fps.append(x[4])
        cpu.append(x[5])
    con.close()
    db.close()
    return native, dalvik, graphics, total, fps, cpu


@app_performance_blue.route('/app_performance/app_performance_report', methods=['GET', 'POST'])
def performancereport():
    data = []
    versions = []
    for i in get_database():
        tablename = request.args.get('name')
        version = i[13:]
        versions.append(str(version))
        native, dalvik, graphics, total, fps, cpu = fetch_all(i, tablename)
        data.append({'version': version, 'native': native, 'dalvik': dalvik, 'graphics': graphics,
                            'total': total, 'fps': fps, 'cpu': cpu})
    xlist = list(range(len(total)))
    OperationLog().add_log(function_name='获取专项测试报告信息', case='app_performance', type=tablename,
                           request_data=versions)       # 添加日志到数据库
    return render_template('app_performance/app_performance_report.html', xlist=xlist,
                           data=data, legenddata=json.dumps(versions))

