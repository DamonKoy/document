

from flask import Blueprint, render_template, request


ui_test_blue = Blueprint('ui_test_blue', __name__)


@ui_test_blue.route('/ui_test/task_list', methods=['GET'], strict_slashes=False)
def task_list():
    """获取任务列表"""
    return render_template('ui_test/task_list.html')


@ui_test_blue.route('/ui_test/add_task', methods=['GET', 'POST'], strict_slashes=False)
def add_task():
    """添加UI测试任务"""
    if request.method == 'GET':
        return render_template('ui_test/add_task.html')


