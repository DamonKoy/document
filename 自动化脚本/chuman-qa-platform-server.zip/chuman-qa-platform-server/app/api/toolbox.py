
from sqlalchemy import and_
from app.view_model.toolbox_view_model import *
from flask import Blueprint, render_template, request
from app.models.models import db, OperationLog, ToolBox

toolbox_blue = Blueprint('toolbox_blue', __name__)


@toolbox_blue.route('/toolbox/', methods=['GET'])
def toolbox_list():
    return render_template('toolbox/toolbox_list.html')


@toolbox_blue.route('/toolbox/get_toolbox_list/', methods=['GET'], strict_slashes=False)
def get_toolbox_list():
    """获取工具箱列表数据"""
    # 获取json文件
    # toolbox_list = get_toolbox_list_json()
    # 通过数据库获取工具箱json数据
    version = request.args.get('version')   # 获取当前页面的版本信息
    if version == '0.0.0':
        query_data = ToolBox.query.all()
    else:
        query_data = ToolBox.query.filter_by(version=version).all()  # 查询版本对应的功能列表
    resp = {
        'code': 0,
        'msg': '',
        'count': 50,
        'data': ToolBox().get_query(query_data)
    }
    return resp


@toolbox_blue.route('/toolbox/search_name/<search_name>/', methods=['GET'], strict_slashes=False)
def search_name(search_name):
    """工具箱列表模糊搜索"""
    # 通过数据库查询返回模糊搜索数据
    version = request.args.get('version')
    if version == '0.0.0':
        query_data = ToolBox.query.filter(ToolBox.name.like('%' + search_name + '%')).all()
    else:
        query_data = ToolBox.query.filter(and_(ToolBox.version==version, ToolBox.name.like('%' + search_name + '%'))).all()
    # 通过json文件进行查询返回搜索数据
    # search_list = []
    # for i in get_toolbox_list_json():
    #     if search_name in i['name']:
    #         search_list.append(i)
    #     else:
    #         pass
    resp = {
        'code': 0,
        'msg': '',
        'count': 10,
        'data': ToolBox().get_query(query_data)
    }
    OperationLog().add_log(function_name='工具箱列表搜索', case='toolbox', type='search_name',
                        request_data=search_name)      # 添加日志到数据库
    return resp


@toolbox_blue.route('/toolbox/search_name/<search_version>/', methods=['GET'], strict_slashes=False)
def search_version(search_version):
    """工具箱列表模糊搜索"""
    # 通过数据库查询返回模糊搜索数据
    query_data = ToolBox.query.filter(ToolBox.version.like(f'%{search_version}%')).all()
    resp = {
        'code': 0,
        'msg': '',
        'count': 10,
        'data': ToolBox().get_query(query_data)
    }
    OperationLog().add_log(function_name='工具箱列表搜索', case='toolbox', type='search_name',
                        request_data=search_name)      # 添加日志到数据库
    return resp


# @toolbox_blue.route('/toolbox/<type>/', methods=['GET', 'POST'], strict_slashes=False)
# def toolbox(type):
#     """通用方法，获取toolbox对应功能的内容"""
#     func_json = get_toolbox_info(type)
#     data_list = []
#     # 判断请求方式进行返回
#     if request.method == 'GET':
#         html = 'toolbox/' + func_json[0]['type'] + '.html'
#         return render_template(html)
#     elif request.method == 'POST':
#         for i in range(0, len(func_json[0]['data'])):
#             data_list.append(request.form.get(func_json[0]['data'][i]))
#         func = globals().get(type)     # 寻找对应的方法函数
#         result = func(*data_list)
#         OperationLog().add_log(function_name=func_json[0]['name'], case='toolbox', type=type,
#                                request_data=data_list, result=result)       # 添加日志到数据库
#         return result


@toolbox_blue.route('/toolbox/<type>/', methods=['GET', 'POST'], strict_slashes=False)
def toolbox(type):
    """通用方法，获取toolbox对应功能的内容"""
    query_data = ToolBox.query.filter_by(type=type).first()
    data_list = []
    # 判断请求方式进行返回
    if request.method == 'GET':
        html = 'toolbox/' + query_data.type + '.html'
        return render_template(html)
    elif request.method == 'POST':
        query_data_list = query_data.data.split(',')    # 将返回的字符串变成数组
        for i in query_data_list:
            data_list.append(request.form.get(i))
        func = globals().get(type)     # 寻找对应的方法函数
        print(func)
        result = func(*data_list)
        print(result)
        OperationLog().add_log(function_name=query_data.name, case='toolbox', type=type,
                               request_data=data_list, result=result)       # 添加日志到数据库
        return result


