
from app.models.models import db
# from flask import current_app

# app = current_app.__get__current_object()   # 不引入上下文则报错


def commit_logs():
    # with app.app_context():   # 不引入上下文则报错
        db.session.commit()
        print('---------执行定时任务---------')