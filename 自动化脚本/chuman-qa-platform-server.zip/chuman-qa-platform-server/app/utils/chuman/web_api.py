import requests

from app.utils.common import get_value_from_envconfig
from app.utils.common import log_request_info


@log_request_info
def set_user_exp_in_batch(env='demo', user_ids=None, exp_type=None, exp=None):
    """
    后台增加用户成就经验值
    :param env: 环境
    :param user_ids: 用户触漫号
    :param exp_type: 类型：1=创作、2=触龄、3=土豪、4=人气、5=活跃
    :param exp: 经验值数量
    :return:
    """
    api_url = get_value_from_envconfig(env, 'new_web_url')
    web_key = get_value_from_envconfig(env, 'web_key')
    headers = {'mauthorization': f'{web_key}:TEST:'}
    params = {
        'm': 'Api',
        'c': 'AdmUser',
        'a': 'set_user_exp_in_batch',
    }
    data = {
        'user_ids': user_ids,
        'exp_type': exp_type,
        'exp': exp,
    }
    return requests.post(api_url, headers=headers, params=params, data=data)


@log_request_info
def edit_coin_reward(env='demo', coin_type=None, userinfo=None):
    """
    发放奖励
    :param env: 环境
    :param coin_type: 货币类型，1为金币2为蓝钻3为金钻
    :param userinfo: 用户id和对应数量的序列化数据
    :return:
    """
    api_url = get_value_from_envconfig(env, 'new_web_url')
    web_key = get_value_from_envconfig(env, 'web_key')
    headers = {'mauthorization': f'{web_key}:TEST:'}
    params = {
        'm': 'Api',
        'c': 'AdmUserResRefund',
        'a': 'edit_coin_reward',
    }
    data = {
        'operate_admin': 'tester',      # 操作人
        'applicate_admin': 'tester',        # 申请人
        'examine_admin': 'tester',      # 审批人
        'appli_reason': 6,      # 申请原因1为运营活动经费2为市场3为品牌4为ip5为产品6为测试7充值会员补发钻石经费8小店代充经费
        'coin_type': coin_type,
        'userinfo': userinfo,
    }
    return requests.post(api_url, headers=headers, params=params, data=data)


@log_request_info
def uc_anchor_info(env='demo', user_id=None, is_show=None, show_place='1'):
    """
    添加主播开播权限
    :param env: 环境
    :param user_id: 用户id
    :param is_show: 是否允许分发，0=不允许；1=允许
    :param show_place: 分发位置
    :return:
    """
    api_url = get_value_from_envconfig(env, 'new_web_url')
    web_key = get_value_from_envconfig(env, 'web_key')
    headers = {'mauthorization': f'{web_key}:TEST:'}
    params = {
        'm': 'Api',
        'c': 'AdmLiveBroadcast',
        'a': 'uc_anchor_info',
    }
    data = {
        'id': 0,
        'user_id': user_id,
        'is_show': is_show,     # 1为允许分发， 0为不允许
        'show_place': show_place,       # 分发位置
        'show_stime': None,
        'show_etime': None,
        'type': 2,       # 主播属性，1为签约主播，2为非签约主播
        'is_ban': 0,    # 0位允许直播，1为禁止直播
        'ban_type': 0,      # 禁止天数
    }
    return requests.post(api_url, headers=headers, params=params, data=data)


@log_request_info
def white_list_add(env, user_id, type):
    """
    添加用户白名单
    :param env:
    :param user_id: 用户id
    :param type: 类型 1:保存图片与点赞 2:内部素材包 3:帖子视频 4:发布短视频需要审核 5:发布短视频不需要审核 6.创建同人社区
    :return:
    """
    api_url = get_value_from_envconfig(env, 'new_web_url')
    web_key = get_value_from_envconfig(env, 'web_key')
    headers = {'mauthorization': f'{web_key}:TEST:',
               'Content-Type': 'application/x-www-form-urlencoded',
               }
    params = {
        'm': 'Api',
        'c': 'AdmUser',
        'a': 'white_list_add',
    }
    data = {
        'user_id': user_id,
        'type': type,
    }
    return requests.post(api_url, headers=headers, params=params, data=data)


@log_request_info
def edit_push(env, title, message, point_ids, point_chuman_ids, obj_type, obj_id, url):
    """
    个性化推送
    :param env: 环境
    :param title: 推送标题
    :param message: 推送内容
    :param point_ids: 被推送的用户id
    :param point_chuman_ids: 被推送的触漫号
    :param obj_type: 跳转类型1：漫画，2:漫剧，3为直播间，4为h5,5为素材商店，6为服装，7为专题，8为帖子，9为图文信息模板，10为新手模板，11为漫画模板页，12为小铅笔页，13为服装店，14直播TAB页面，15为作品榜单，16为会员中心，17为人设空间，18社团榜单，19社团，20首页，21他人人设空间，22人物创作，23我的优惠券，24我的社团，25指定社团，26指定讨论，27漫画单篇， 28漫剧单篇
    :param obj_id: 跳转目标id
    :param url: 跳转链接
    :param notice_type: 消息类型：1为站内消息，2为push（多选以英文逗号分割）
    :param type: 类型,0无,1全员,2分组,3特定ID/触漫号,4特定身份,5用户分群，6新版设备分群
    :param group_type: 推送组0为默认，1为特定
    :param is_timing: 定时开关，1开启，
    :return:
    """
    notice_type = 2
    type = 3
    group_type = 0
    is_timing = 0

    api_url = get_value_from_envconfig(env, 'new_web_url')
    web_key = get_value_from_envconfig(env, 'web_key')
    headers = {'mauthorization': f'{web_key}:TEST:',
               'Content-Type': 'application/x-www-form-urlencoded',
               }
    params = {
        'm': 'Api',
        'c': 'AdmPush',
        'a': 'edit_push',
    }
    data = {
        'env': env,
        'title': title,
        'message': message,
        'point_ids': point_ids,
        'point_chuman_ids': point_chuman_ids,
        'obj_type': obj_type,
        'obj_id': obj_id,
        'url': url,
        'notice_type': notice_type,
        'type': type,
        'group_type': group_type,
        'is_timing': is_timing,
    }
    return requests.post(api_url, headers=headers, params=params, data=data)

