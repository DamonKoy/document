import requests
import time

from app.utils.common import get_value_from_envconfig
from app.utils.common import log_request_info
from app.utils.common import get_yesterday_time


@log_request_info
def get_course_question_list(session, env='demo', training_id=None):
    """
    触漫学院获取题目列表
    :param session:
    :param env:
    :param training_id: 题目id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_course_question_list',
        'training_id': training_id,
    }
    return session.get(api_url, params=params)


@log_request_info
def add_course_training_record(session, env='demo', training_id=None, question_num=5):
    """
    触漫学院答题获取星星
    :param session:
    :param env:
    :param question_num: 回答数量
    :param training_id: 题目id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'add_course_training_record',
    }
    data = {
        'training_id': training_id,
        'question_num': question_num,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_community_qa(session, env='demo'):
    """
    获取社区问答题目
    :param session:
    :param env:
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'SpecialTask',
        'a': 'get_community_qa',
    }
    return session.get(api_url, params=params)


@log_request_info
def submit_question_answer(session, env='demo', number=16):
    """
    提交发布帖子视频题目答案
    :param session:
    :param env:
    :param number: 答对题目数量
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'submit_question_answer',
        'number': number,
    }
    return session.get(api_url, params=params)


@log_request_info
def test_add_fame(session, env='demo', type=9, desc='', fame=500):
    """
    提交发布帖子视频题目答案
    :param session:
    :param env:
    :param type: 类型:1.点赞新手、2.关注新手、3.新手作品专业漫评、4.学徒作品上首页、5.批改学徒作品、
    6.专业漫评获得5个赞同、7.专业漫评获得15个赞同、8.专业漫评获得作者赞同、9.漫娘奖励
    :param desc: 说明
    :param fame: 声望值(500变成'成为编辑'按钮)
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Tribe',
        'a': 'test_add_fame',
        'type': type,
        'desc': desc,
        'fame': fame,
    }
    return session.get(api_url, params=params)


@log_request_info
def token(env='demo', id=None):
    """
    获取用户id的install_token
    :param env:
    :param id: 用户id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'token',
        'id': id,
    }
    return requests.get(api_url, params=params)


def conver_to_user_id(chuman_id):
    """
    将触漫号转为用户id
    :param chuman_id: 触漫号
    :return:
    """
    length = len(chuman_id)
    try:
        user_id = int(chuman_id[1:length], 16)      # 对第二位到尾位进行16进制转10进制
    except Exception:
        return '输入的触漫号不正确，请重新尝试'
    else:
        return {f"触漫号": chuman_id, "用户id": user_id}


def conver_to_chuman_id(user_id):
    """
    将用户id转为触漫号
    :param user_id: 用户id
    :return:
    """
    a = user_id[0]      # a 为前缀
    try:
        temp = hex(int(user_id))        # 将10进制转为16进制
    except Exception:
        return '输入的用户id不正确，请重新尝试'
    else:
        chuman_id = (a + temp[2:]).upper()      # 将前缀+16进制的拼接
        return {"用户id": user_id, "触漫号": chuman_id}


@log_request_info
def testPurchase(session, env, user_id, vip_tag):
    """
    开通会员服务
    :param env: 环境
    :param user_id: 用户id
    :param vip_tag: 开通类别[vip_001,vip_002,vip_003,vip_004,...,vip_012]
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'testPurchase',
    }
    data = {
        'user_id': user_id,
        'vip_tag': vip_tag,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def doll_machine_add_user_num(session, env, activity_id, user_id, num, type=2):
    """
    增加福利中心活动参与次数
    :param session:
    :param env:
    :param activity_id:
    :param user_id:
    :param num:
    :param type:
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'doll_machine_add_user_num',
        'activityId': activity_id,
        'userId': user_id,
        'num': num,
        'type': type,
    }
    return session.get(api_url, params=params)


@log_request_info
def generate_verify_code_by_phone(env, phone_num):
    """
    手机号码注册获取验证码
    :param env:
    :param phone_num: 手机号码
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'generate_verify_code_by_phone',
        'phone_num': phone_num,
    }
    return requests.get(api_url, params=params)


@log_request_info
def test_user_skip_auth_check(env, user_id, time):
    """
    跳过实名制验证
    :param env:
    :param user_id: 用户id
    :param time: 缓存过期时间，单位为秒，默认3600s
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'test_user_skip_auth_check',
        'user_id': user_id,
        'time': time,
    }
    return requests.get(api_url, params=params)


@log_request_info
def clear_user_auth_status(env, user_id, time):
    """
    清除用户实名制状态
    :param env:
    :param user_id: 用户id
    :param time: 缓存过期时间，单位为秒，默认3600s
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'clear_user_auth_status',
        'user_id': user_id,
        'time': time,
    }
    return requests.get(api_url, params=params)


@log_request_info
def reset_sms_limit(session, env, mobile):
    """
    重置手机验证码发送次数限制
    :param env:
    :param mobile: 手机号码
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'reset_sms_limit',
        'mobile': mobile,
    }
    return session.get(api_url, params=params)


@log_request_info
def unbind_user_account(session, env, name, username):
    """
    解绑第三方账号用户
    :param env: 环境
    :param name: 第三方平台(wechat,qq,weibo)
    :param username: 第三方标识(登录时抓包获取)
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'unbind_user_account',
    }
    data = {
        'name': name,
        'username': username,
    }
    return session.post(api_url, params=params, data=data)


# @log_request_info
# def generate_new_user(env, phone, password):
#     """
#     生成账号
#     :param env: 环境
#     :param phone: 手机号码
#     :param password: 密码
#     :return:
#     """
#     api_url = get_value_from_envconfig(env, 'api_url')
#     params = {
#         'm': 'Api',
#         'c': 'ArtificialLimb',
#         'a': 'generate_new_user',
#     }
#     data = {
#         'phone': phone,
#         'password': password,
#     }
#     return requests.post(api_url, params=params, data=data)


@log_request_info
def clear_app_user(env, user_token):
    """
    清除第三方token
    :param env:
    :param user_token: 第三方user_token
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'clear_app_user',
    }
    data = {
        'user_token': user_token,
    }
    return requests.post(api_url, params=params, data=data)


@log_request_info
def clear_app_device(env, device_id):
    """
    清理设备id记录
    :param env:
    :param device_id: 设备id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'clear_app_device',
    }
    data = {
        'device_id': device_id,
    }
    return requests.post(api_url, params=params, data=data)


@log_request_info
def muti_logout_user(session, env, user_ids):
    """
    通过用户ID进行删除账号
    :param env:
    :param user_ids: 用户id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'AdmUser',
        'a': 'muti_logout_user',
    }
    data = {
        'user_ids': user_ids,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def clear_to_new_user(session, env, user_id, device_id, user_token):
    """
    拉新后注销成新用户(包括清理账号、设备id、第三方token)
    :param session:
    :param env:
    :param user_token: 要清除的第三方user_token
    :param device_id: 要清除的设备id
    :param user_id: 要清除的用户id
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'clear_to_new_user',
    }
    data = {
        'user_id': user_id,
        'device_id': device_id,
        'user_token': user_token,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def test_update_user_info(session, env, user_id, seven_day):
    """
    修改累计签到天数
    :param session:
    :param env:
    :param user_id:
    :param seven_day:
    :return:
    """
    last_login_time = get_yesterday_time()
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'ArtificialLimb',
        'a': 'test_update_user_info',
        'user_id': user_id,
        'seven_day': seven_day,
        'last_login_time': last_login_time,
    }
    return session.get(api_url, params=params)


@log_request_info
def update_sign_switch(session, env, user_id, sign_time):
    """
    修改最后签到时间
    :param session:
    :param env:
    :param user_id:
    :param sign_time:
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'SignIn',
        'a': 'update_sign_switch',
        'user_id': user_id,
        'signTime': sign_time,
    }
    return session.get(api_url, params=params)


@log_request_info
def new_register_android(session, env, phone_num, check_code):
    """
    安卓手机注册
    :param session:
    :param env:
    :param phone_num:
    :param check_code:
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'new_register'
    }
    data = {
        'device_model': 'LLD-AL20',
        'phone_num': phone_num,
        'check_code': check_code,
        'language:': 'zh-hans',
        'pwd': 'qa123456',
        'type': 0,
        'brand': 'HONOR',
        'version': 1,
        'token': ''
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def new_register_ios(session, env, phone_num, check_code):
    """
    iOS手机注册
    :param session:
    :param env:
    :param phone_num:
    :param check_code:
    :return:
    """
    api_url = get_value_from_envconfig(env, 'api_url')
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'new_register'
    }
    data = {
        'device_model': 'iPhone',
        'phone_num': phone_num,
        'check_code': check_code,
        'language:': 'zh-hans-cn',
        'pwd': 'qa123456',
        'type': 1,
        'brand': 'apple',
        'version': 1
    }
    return session.post(api_url, params=params, data=data)