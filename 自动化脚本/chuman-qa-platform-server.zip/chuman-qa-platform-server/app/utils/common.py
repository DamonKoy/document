import functools
import yaml
import json
import requests
import time
import datetime

from app.utils.log import CustomLogger

logger = CustomLogger.get_logger()


env_config_file = 'app/config/env_config.yaml'
toolbox_list_file = 'app/data/toolbox_list.json'
app_performance_list_file = 'app/data/app_performance_list.json'


def get_yaml_data(yaml_file):
    """
    获取yaml文件内容
    """
    yaml_data = {}
    with open(yaml_file, encoding='utf-8') as config_file_obj:
        yaml_obj = yaml.load(config_file_obj, Loader=yaml.FullLoader)
    for key, value in yaml_obj.items():
        yaml_data[key] = value
    return yaml_data


def get_value_from_envconfig(env, key):
    """
    获取env环境对应key的值
    """
    env_config = get_yaml_data(env_config_file)[env]
    value = env_config[key]
    return value


def log_request_info(func):
    """
    装饰器，打印请求信息
    :param func:
    :return:
    """
    @functools.wraps(func)
    def wrap(*args, **kwargs):
        logger.info(f'执行{func.__name__}请求')
        response = func(*args, **kwargs)
        response.encoding = 'utf-8'
        request = response.request
        request_info = f"""{func.__name__}请求的详细信息如下所示：
{'=' * 40} request info {'=' * 40}
METHOD: {request.method}
URL: {request.url}
HEADERS: {request.headers}
BODY: {request.body}

{'=' * 40} response  info {'=' * 40}
STATUS_CODE: {response.status_code}
HEADERS: {response.headers}
BODY: {response.json() if response.status_code == 200 else response.text}
"""
        logger.info(request_info)
        return response
    return wrap


def log_test_info(func):
    """
    装饰器，打印测试用例信息
    :param func:
    :return:
    """
    @functools.wraps(func)
    def wrap(*args, **kwargs):
        try:
            logger.info(f'开始执行用例：{func.__name__}')
            func(*args, **kwargs)
        except Exception as e:
            logger.error(f'执行用例{func.__name__}时报错', exc_info=1)
            raise e
    return wrap


def get_toolbox_list_json():
    """
    工具箱列表json数据
    :return:
    """
    with open(f"{toolbox_list_file}", 'r') as f:
        load_dict = json.load(f)
    return load_dict


def get_toolbox_info(type: str):
    """获取工具箱的详细信息"""
    toolbox_list = get_toolbox_list_json()
    fuc_list = []
    for i in range(0, len(toolbox_list)):
        if type == toolbox_list[i].get('type'):
            fuc_list.append(toolbox_list[i])
            return fuc_list
    else:
        return 'error'


def get_user_install_token(user_id, env=None):
    """
    获取指定环境、指定用户的install_token
    :param user_id: 用户id
    :param env: 指定环境
    :return: 指定环境、指定用户的install_token
    """
    try:
        if env is None:
            env = 'demo'
        key = f'{env}_{user_id}'
        app_key = get_value_from_envconfig(env, 'app_key')
        api_url = get_value_from_envconfig(env, 'api_url')
        headers = {'mauthorization': f'{app_key}::'}
        params = {'m': 'Api', 'c': 'User', 'a': 'token', 'id': user_id}
        res = requests.get(api_url, params=params, headers=headers, verify=False)
        print(f"获取{env}环境用户{user_id}的install_token，返回的内容是：\n{res.json()}")
        return res.json()['data']['install_token']
    except Exception as e:
        print(f'获取{env}环境用户{user_id}的install_token出错', exc_info=1)
        raise e


def get_user_session(user_id, env=None, versioncode=None, client=None):
    """
    获取指定环境、指定版本、指定用户的session
    :param user_id: 用户id
    :param env: 指定环境
    :param versioncode: 指定版本
    :return: 指定环境、指定版本、指定用户的session
    """
    if env is None:
        env = 'demo'
    if versioncode is None:
        versioncode = get_value_from_envconfig(env, 'versioncode')
    key = f'{env}_{user_id}'
    install_token = get_user_install_token(user_id, env=env)
    app_key = get_value_from_envconfig(env, 'app_key')
    # 'secretkey': '76065e8fe0279d4c94823deb8a5c9245' 用于验证脚手架api2环境
    headers = {'mauthorization': f'{app_key}:{install_token}:TEST',
               'versioncode': versioncode,
               'secretkey': '76065e8fe0279d4c94823deb8a5c9245'}
    if client == 'ios':
        headers = {
            'mauthorization': f'{app_key}:{install_token}:TEST',
            'versioncode': 'ios_5.0.0',
            'secretkey': '76065e8fe0279d4c94823deb8a5c9245',
            'Content-Type': 'application/x-www-form-urlencoded',
            'channel': 'cheezz',
            'User-Agent': 'Cheezz/3.34.0 (iPhone; iOS 12.0; Scale/3.00)',
            'device': 'ios'
        }
    session = requests.Session()
    session.headers.update(headers)
    return session


def get_html_content(function_name):
    """
    通过功能名称获取html_content的值
    :param function_name: 功能名称
    :return:
    """
    with open(f"static/css/{function_name}.txt") as f:
        content = f.readlines()
        content = ''.join(content)
        return content


def get_app_performance_list_json():
    """
    专项测试列表json数据
    :return:
    """
    with open(f"{app_performance_list_file}", 'r') as f:
        load_dict = json.load(f)
    return load_dict


def get_app_performance_info(type: str):
    """获取专项测试的详细信息"""
    performance_list = get_app_performance_list_json()
    fuc_list = []
    for i in range(0, len(performance_list)):
        if type == performance_list[i].get('type'):
            fuc_list.append(performance_list[i])
            return fuc_list
    else:
        return 'error'


def get_yesterday_time():
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)
    yesterday_time = int(time.mktime(time.strptime(str(yesterday), '%Y-%m-%d')))
    return yesterday_time