import os

from flask import Flask
from flask_apscheduler import APScheduler
from apscheduler.schedulers.background import BackgroundScheduler

from app.api.api_test import api_test_blue
from app.api.home import home_blue
from app.api.toolbox import toolbox_blue
from app.api.app_performance import app_performance_blue
from app.api.devices import devices_blue
from app.api.ui_test import ui_test_blue

from app.config.settings import FLASK_ENV_CONFIG
from app.models.models import db, ToolBox, chumanAndroid523, chumanAndroid530
from app.config.apscheduler_config import Config


def create_app():
    app = Flask(__name__)
    flask_env = os.getenv('FLASK_ENV', 'local').lower()
    flask_env_config = FLASK_ENV_CONFIG[flask_env]
    app.config.from_object(flask_env_config)
    app.config.from_object(Config)
    register_blueprints(app)
    register_plugins(app)
    # register_scheduler(app)
    return app


def register_blueprints(app):
    """注册蓝图"""
    app.register_blueprint(home_blue)
    app.register_blueprint(toolbox_blue)
    app.register_blueprint(api_test_blue)
    app.register_blueprint(app_performance_blue)
    app.register_blueprint(devices_blue)
    app.register_blueprint(ui_test_blue)


def register_plugins(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
        db.create_all(bind=['chumanAndroid523'])
        db.create_all(bind=['chumanAndroid530'])


def register_scheduler(app):
    """Configure Scheduler"""
    # scheduler = APScheduler()   # 实例化APScheduler
    scheduler = APScheduler(BackgroundScheduler(timezone="Asia/Shanghai"))
    scheduler.init_app(app)     # 把任务列表载入实例flask
    scheduler.start()   # 启动任务计划