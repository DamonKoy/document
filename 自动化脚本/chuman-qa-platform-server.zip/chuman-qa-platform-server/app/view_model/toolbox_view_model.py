import json
import logging

from app.utils.chuman import web_api
from app.utils.chuman import app_api

from app.utils.common import get_user_session


def add_experience(env, flag, ids, exp_type, experience):
    """
    增加用户经验值和成就
    :param env:
    :param user_ids:
    :param exp_type:
    :param experience:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'chuman_id':
        chuman_id = ids
    elif flag == 'user_id':
        chuman_id = app_api.conver_to_chuman_id(ids)['触漫号']

    resp = web_api.set_user_exp_in_batch(env, chuman_id, exp_type, experience).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def add_course_training_record(env, flag, ids):
    """
    达到触漫学堂发布条件
    :param env:
    :param user_id:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']

    # 题目id
    session = get_user_session(env=env, user_id=user_id)
    training_list = [10, 14, 21, 23, 36, 24, 25, 29, 30, 31, 32, 33]
    for i in training_list:
        app_api.get_course_question_list(session, env, training_id=i).json()
        resp = app_api.add_course_training_record(session, env, training_id=i).json()
        print(f"达到触漫学堂发布条件json为{resp}")
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def submit_question_answer(env, user_id):
    """
    达到视频帖子发布条件
    :param env:
    :param user_id:
    :return:
    """
    session = get_user_session(env=env, user_id=user_id)
    app_api.get_community_qa(session, env).json()
    print(f"获取社区问题json为{res}")
    resp = app_api.submit_question_answer(session, env).json()
    print(f"提交问题json为{resp}")
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def test_add_fame(env, flag, ids):
    """
    达到编辑条件
    :param env:
    :param user_id:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.test_add_fame(session, env).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def get_install_token(env, flag, ids):
    """
    获取用户install_token
    :param env:
    :param user_id:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']

    resp = app_api.token(env, user_id).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def conver_to_user_id(chuman_id):
    """
    将触漫号转为用户id
    :param chuman_id: 触漫号
    :return:
    """
    resp = app_api.conver_to_user_id(chuman_id)
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def conver_to_chuman_id(user_id):
    """
    将用户id转为触漫号
    :param user_id: 用户id
    :return:
    """
    resp = app_api.conver_to_chuman_id(user_id)
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def edit_coin_reward(env, coin_type, flag, ids, num):
    """
    发放奖励
    :param env: 环境
    :param coin_type: 货币类型，1为金币2为蓝钻3为金钻
    :param user_id: 用户id
    :param num: 对应资源数量
    :return:
    """

    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']

    info = f"{user_id}:{num}"
    resp = web_api.edit_coin_reward(env, coin_type, info)
    # 接口成功也会返回500，以后再调整
    # if resp.status_code == 200:
    #     if resp.json()['status'] == 'ok':
    #         return '发放资源成功'
    # else:
    #     return f"发放资源失败，接口状态码为{resp.status_code}，可以让开发排查用户ID为{user_id}调用edit_coin_reward接口报错原因"
    return '发放资源成功'


def buy_vip(env, flag, ids, vip_tag):
    """
    开通会员
    :param env:
    :param user_id:
    :param vip_tag:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']

    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.testPurchase(session, env, user_id, vip_tag).json()
    if resp['status'] == 'ok':
        remainder_days = resp['data']['remainder_days']
        expiry_date = resp['data']['expiry_date']
        return f"用户id：{user_id}，当前开通会员天数：{remainder_days}，会员有效日期：{expiry_date}"
    else:
        return "开通失败"


def doll_machine_add_user_num(env, activity_id, flag, ids, num):
    """
    增加福利中心活动参与次数
    :param env: 环境
    :param activity_id: 活动id
    :param user_id: 用户id
    :param num: 参与次数
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.doll_machine_add_user_num(session, env, activity_id, user_id, num).json()
    # 进行中文转义
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def generate_verify_code_by_phone(env, phone_num):
    """
    手机注册获取验证码
    :param env: 环境
    :param phone_num: 手机号码
    :return:
    """
    resp = app_api.generate_verify_code_by_phone(env, phone_num).json()
    # 进行中文转义
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def test_user_skip_auth_check(env, flag, ids, time):
    """
    跳过实名制验证
    :param env:
    :param user_id:
    :param time:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    resp = app_api.test_user_skip_auth_check(env, user_id, time).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def clear_user_auth_status(env, flag, ids, time):
    """
    清除用户实名制状态
    :param env:
    :param user_id:
    :param time:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    resp = app_api.clear_user_auth_status(env, user_id, time).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def uc_anchor_info(env, flag, ids, is_show, show_place):
    """
    添加主播开播权限
    :param env:
    :param user_id:
    :param time:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    resp = web_api.uc_anchor_info(env, user_id, is_show, show_place).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def reset_sms_limit(env, mobile):
    """
    重置手机验证码发送次数
    :param env:
    :param mobile:
    :return:
    """
    session = get_user_session(env=env, user_id='49550409')
    resp = app_api.reset_sms_limit(session, env, mobile).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def white_list_add(env, flag, ids, type):
    """
    添加用户白名单
    :param env:
    :param user_id: 用户id
    :param type: 类型 1:保存图片与点赞 2:内部素材包 3:帖子视频 4:发布短视频需要审核 5:发布短视频不需要审核 6.创建同人社区
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    resp = web_api.white_list_add(env, user_id, type).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def unbind_user_account(env, flag, ids, name, username):
    """
    解绑第三方账号用户
    :param env: 环境
    :param name: 第三方平台(wechat,qq,weibo)
    :param username: 第三方标识(登录时抓包获取)
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.unbind_user_account(session, env, name, username).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def new_register(env, phone, client):
    """
    通过手机注册生成账号
    :param env: 环境
    :param phone: 手机号码
    :param client: 客户端
    :return:
    """
    try:
        int(phone)
    except Exception as e:
        print(e)
        return '请输入正确的手机号码'
    print(env, phone, client)
    verify_resp = app_api.generate_verify_code_by_phone(env, phone).json()
    if verify_resp['status'] == 'error':
        return '请输入正确的手机号码'
    else:
        check_code = verify_resp['data']['code']
    if client == 'ios':
        session = get_user_session(env=env, user_id='3', versioncode='ios_5.0.0', client=client)
        resp = app_api.new_register_ios(session, env, phone, check_code).json()
    elif client == 'android':
        session = get_user_session(env=env, user_id='3')
        resp = app_api.new_register_android(session, env, phone, check_code).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def clear_app_user(env, user_token):
    """
    清除第三方token
    :param env:
    :param user_token: 第三方user_token
    :return:
    """
    resp = app_api.clear_app_user(env, user_token).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def clear_app_device(env, device_id):
    """
    清理设备id记录
    :param env:
    :param device_id: 设备id
    :return:
    """
    resp = app_api.clear_app_device(env, device_id).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def muti_logout_user(env, flag, ids):
    """
    通过用户ID进行删除账号
    :param env:
    :param user_ids: 用户id
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    try:
        session = get_user_session(env=env, user_id=user_id)
    except Exception as e:
        return '该用户获取install_token失败，请检查是否已进行过该操作'
    resp = app_api.muti_logout_user(session, env, user_id).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def clear_to_new_user(env, flag, ids, device_id, user_token):
    """
    拉新后注销成新用户(包括清理账号、设备id、第三方token)
    :param env:
    :param user_token: 要清除的第三方user_token
    :param device_id: 要清除的设备id
    :param user_id: 要清除的用户id
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.clear_to_new_user(session, env, user_id, device_id, user_token).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def edit_push(env, title, message, ids, obj_type, obj_id, flag):
    """
    个性化推送
    :param env: 环境
    :param title: 推送标题
    :param content: 推送内容
    :param 用于识别用户id还是触漫号
    :param ids: 被推送的用户ID或触漫号
    :param obj_type: 跳转类型1：漫画，2:漫剧，3为直播间，4为h5, 5为素材商店，6为服装，7为专题，8为帖子，9为图文信息模板，10为新手模板，11为漫画模板页，12为小铅笔页，13为服装店，14直播TAB页面，15为作品榜单，16为会员中心，17为人设空间，18社团榜单，19社团，20首页，21他人人设空间，22人物创作，23我的优惠券，24我的社团，25指定社团，26指定讨论，27漫画单篇， 28漫剧单篇
    :param obj_id: 跳转目标id
    :return:
    """
    types = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '21', '25', '27', '28']     # 需要输入跳转id的类型
    talk_type = ['26']
    url_type = ['4', '5', '28']
    point_ids = None
    point_chuman_ids = None
    url = None

    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        point_ids = ids
    elif flag == 'chuman_id':
        point_chuman_ids = ids

    # 判断跳转目标类型
    if obj_type in types:
        if obj_id == '':
            return '请输入跳转目标再进行提交'
        elif obj_type in url_type:
            url = obj_id
            obj_id = None
        else:
            url = None

    resp = web_api.edit_push(env, title, message, point_ids, point_chuman_ids, obj_type, obj_id, url).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def test_update_user_info(env, flag, ids, seven_day):
    """
    修改累计签到天数
    :param env:
    :param user_id:
    :param seven_day:
    :param last_login_time:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.test_update_user_info(session, env, user_id, seven_day).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp


def update_sign_switch(env, flag, ids, sign_time):
    """
    修改最后签到时间
    :param env:
    :param user_id:
    :param sign_time:
    :return:
    """
    # 判断使用user_id还是触漫号
    if flag == 'user_id':
        user_id = ids
    elif flag == 'chuman_id':
        user_id = app_api.conver_to_user_id(ids)['用户id']
    session = get_user_session(env=env, user_id=user_id)
    resp = app_api.update_sign_switch(session, env, user_id, sign_time).json()
    resp = json.dumps(resp, ensure_ascii=False)
    return resp

