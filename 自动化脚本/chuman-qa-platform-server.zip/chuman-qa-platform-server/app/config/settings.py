# def get_db_uri(dbinfo):
#     """获取数据库信息，如果不存在就返回默认值"""
#     BACKEND = dbinfo.get('BACKEND') or 'mysql'
#
#     DRIVER = dbinfo.get('DRIVER') or 'pymysql'
#
#     USER = dbinfo.get('USER') or 'root'
#
#     PASSWORD = dbinfo.get('PASSWORD') or '1z2x3c4v5b6n7m'
#
#     HOST = dbinfo.get('HOST') or '192.168.216.210:4306'
#
#     PROT = dbinfo.get('PROT') or '4306'
#
#     DB = dbinfo.get('DB') or 'chuman_qa_platform'
#
#     return f"{BACKEND}+{DRIVER}://{USER}:{PASSWORD}@{HOST}:{PROT}/{DB}"


class LocalConfig:
    DEBUG = True
    HOST = '127.0.0.1'
    PORT = 5000
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chuman_qa_platform'
    SQLALCHEMY_BINDS = {
        'chumanAndroid523': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chumanAndroid523',
        'chumanAndroid530': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chumanAndroid530',
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # 如果设置成 True (默认情况)，Flask-SQLAlchemy 将会追踪对象的修改并且发送信号。这需要额外的内存， 如果不必要的可以禁用它。e


class DevConfig:
    DEBUG = True
    HOST = '0.0.0.0'
    PORT = 5000
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chuman_qa_platform'
    SQLALCHEMY_BINDS = {
        'chumanAndroid523': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chumanAndroid523',
        'chumanAndroid530': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:4306/chumanAndroid530',
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False


class ProdConfig:
    DEBUG = False
    HOST = '0.0.0.0'
    PORT = 5000
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:3306/chuman_qa_platform'
    SQLALCHEMY_BINDS = {
        'chumanAndroid523': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:3306/chumanAndroid523',
        'chumanAndroid530': 'mysql+pymysql://root:1z2x3c4v5b6n7m@192.168.216.210:3306/chumanAndroid530',
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False


FLASK_ENV_CONFIG = {
    'local': LocalConfig,
    'dev': DevConfig,
    'prod': ProdConfig
}
