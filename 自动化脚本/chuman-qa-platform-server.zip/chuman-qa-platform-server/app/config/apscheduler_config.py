
class Config(object):
    JOBS = [
        {
            'id': 'commit_logs',
            'func': 'app:utils.tasks.commit_logs',    # 方法名(根据当前文件名的路径获取)
            'args': '',     # 入参
            'trigger': 'interval',  # interval表示循环任务
            'seconds': 60,
        }
    ]

    SCHEDULER_TIMEZONE = 'Asia/Shanghai'
    SCHEDULER_API_ENABLED = True    # 调度器开关

