from datetime import datetime

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, DateTime

db = SQLAlchemy()


class ApiTest(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    exec_time = Column(DateTime, default=datetime.now(), index=True)
    exec_env = Column(String(20), nullable=False)
    exec_module = Column(String(256), nullable=False)
    is_finished = Column(Integer, nullable=False)
    report_url = Column(String(256))


class ToolBox(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(256), nullable=False)
    case = Column(String(256), nullable=False)
    type = Column(String(256), nullable=False)
    data = Column(String(256), nullable=False)
    version = Column(String(20), nullable=True)
    creat_time = Column(DateTime, default=datetime.now(), index=True)
    remarks = Column(String(256), nullable=True)

    def get_query(self, query_result):
        """通过查询结果返回对应的json格式"""
        all = []
        for i in range(0, len(query_result)):
            all.append({'id': query_result[i].id,
                'name': query_result[i].name,
                'case': query_result[i].case,
                'type': query_result[i].type,
                'data': query_result[i].data,
                'version': query_result[i].version,
                'remarks': query_result[i].remarks,
            })
        return all


class OperationLog(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    function_name = Column(String(256), nullable=False)
    case = Column(String(256), nullable=False)
    type = Column(String(256), nullable=False)
    operation_user = Column(String(256), default='操作人员')
    request_data = Column(String(1024), nullable=True)
    result = Column(String(2048), nullable=True)
    deal_time = Column(DateTime, default=datetime.now(), index=True)

    def add_log(self, function_name, case, type, operation_user='系统操作人员', request_data=None, result=None):
        """添加日志到数据库方法"""
        log = OperationLog(function_name=function_name, case=case, type=str(type), operation_user=operation_user,
                           request_data=str(request_data), result=str(result), deal_time=datetime.now())
        db.session.add(log)
        db.session.commit()


class Devices(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    icon = Column(String(518), nullable=True)
    platform = Column(String(30), nullable=True)
    brand = Column(String(256), nullable=True)
    model = Column(String(256), nullable=True)
    system_version = Column(String(30), nullable=True)
    resolution = Column(String(256), nullable=True)
    auditor = Column(String(100), nullable=True)
    holder = Column(String(100), nullable=True)
    status = Column(String(30), nullable=True, default='空闲中')
    remarks = Column(String(256), nullable=True)
    create_time = Column(DateTime, default=datetime.now(), index=True)
    update_time = Column(DateTime, default=datetime.now(), onupdate=datetime.now())

    def update_holder(self, id, auditor, holder):
        """更新设备借出信息"""
        if auditor == holder:
            status = '空闲中'
        else:
            status = '借出中'

        self.query.filter_by(id=id).update({'holder': holder, 'status': status, 'update_time': datetime.now()})
        db.session.commit()

    def get_query(self, query_result):
        """通过查询结果返回对应的json格式"""
        all = []
        for i in range(0, len(query_result)):
            all.append({'id': query_result[i].id,
                'platform': query_result[i].platform,
                'brand': query_result[i].brand,
                'model': query_result[i].model,
                'system_version': query_result[i].system_version,
                'resolution': query_result[i].resolution,
                'auditor': query_result[i].auditor,
                'holder': query_result[i].holder,
                'status': query_result[i].status,
                'remarks': query_result[i].remarks,
                'update_time': query_result[i].update_time.strftime('%Y-%m-%d %H:%M:%S'),
            })
        return all


class DeviceTransferRecord(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    device_id = Column(Integer, db.ForeignKey('devices.id'), nullable=False)
    original_holder = Column(String(256), nullable=True)
    current_holder = Column(String(256), nullable=True)
    remarks = Column(String(256), nullable=True)
    create_time = Column(DateTime, default=datetime.now(), index=True)

    def add_record(self, device_id, original_holder, current_holder, remarks=None):
        """添加转让记录到数据库"""
        record = DeviceTransferRecord(device_id=device_id, original_holder=original_holder,
                                      current_holder=current_holder, remarks=remarks, create_time=datetime.now())
        db.session.add(record)
        db.session.commit()


class Statistics(db.Model):
    id = Column(Integer, primary_key=True, autoincrement=True)
    function_name = Column(String(256), nullable=False)
    operation_user = Column(String(256), default='系统操作人员')
    time = Column(DateTime, default=datetime.now(), index=True)
    click_num = Column(Integer)


class chumanAndroid523(db.Model):
    __bind_key__ = 'chumanAndroid523'
    __tablename__ = 'chumanAndroid523'
    id = Column(Integer, primary_key=True, autoincrement=True)


class chumanAndroid530(db.Model):
    __bind_key__ = 'chumanAndroid530'
    __tablename__ = 'chumanAndroid530'
    id = Column(Integer, primary_key=True, autoincrement=True)


