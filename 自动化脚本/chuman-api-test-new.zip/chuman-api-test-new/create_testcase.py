import string
import os
import importlib

# testcase目录地址
directory_path = os.path.join(os.getcwd(), "testcases")


# 文件名，用于 test_XXXX.py里面的xxx,我这里用api名字（这个列表可复制create_data里面的file_name_list）
file_name_list = [
"get_charater_suit_list_new",
]


def create_testcase(api_module_name, allure_feature, file_name_list):
    """
    按新框架要求，以模块为单位，生成testcases下面某个模块的接口的testcase文件
    :param api_module_name: api模块名, 如chat模块，就填"chat"
    :param allure_feature: 用于allure.feature
    :param file_name_list: testcases/XX模块下面的文件名列表（即模块相关的接口列表）(建议自己整理一波模块中有被引用的接口，因为有一些接口虽然在
                          api文件中定义了，但是并没有相关的用例);如api/app/chat.py里面只有一个接口send_friend_greet且有被引用来写用例，那就在file_name_list
                          里面填send_friend_greet,有多个就填多个
    :return:
    """
    for name in file_name_list:
        # testcase下面的目录名
        class_name = "Test" + string.capwords(name.replace("_", " ")).replace(" ", "")
        api_module = importlib.import_module('api.app.' + api_module_name)
        api_doc = eval("api_module."+name).__doc__
        try:
            api_name = api_doc[:api_doc.index(":param")].replace("\n", "").replace(" ", "")
        except ValueError:
            api_name = api_doc[:api_doc.index(":return")].replace("\n", "").replace(" ", "")
        data_name = name + "_data"
        file = os.path.join(directory_path, api_module_name.replace("_", ""), "test_" + name) + ".py"
        try:
           os.mkdir(os.path.join(directory_path, api_module_name.replace("_", "")))
        except Exception as e:
            print(e, "create_testcase error")
        content = "import allure\n" \
                  + "import os\n"\
                  + "from api.app import " + api_module_name +"\n"\
                  + "from utils import assertion\n"\
                  + "from data." + api_module_name.replace("_", "") + "." + name + " import *\n\n"\
                  + "env = os.getenv('env')\n\n\n"\
                  + "@allure.feature('" + allure_feature + "')\n" \
                  + "@allure.story('" + api_name + "')\n" \
                  + "class " + class_name + ":\n" \
                  + "    @allure.title('" + api_name + "')\n" \
                  + "    def test_" + name + "(self, " + data_name + "):\n" \
                  + "        session = " + data_name + "[\"session\"]\n" \
                  + "        res = " + api_module_name + "." + name + "(session, request_info=" + data_name + ").json()\n" \
                  + "        validators = [\n" \
                  + "            [assertion.assert_is_subset, {\"status\": \"ok\"}, res],\n" \
                  + "            [assertion.assert_schema, res, " + data_name + "['schema_file']],\n" \
                  + "        ]\n" \
                  + "        assertion.validate(validators)\n" \

        with open(file, 'w') as f:
            f.write(content)
            f.close()


create_testcase("giftpack", "素材礼包", file_name_list=file_name_list)

