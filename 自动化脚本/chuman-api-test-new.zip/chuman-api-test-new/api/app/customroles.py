# -*- coding: UTF-8 -*-
import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def add_custom_role(session, request_info=None):
    """
    5.1.0-添加自定义角色
    :param session:
    :param user_id:
    :param page:
    :param pagesize:
    :param is_outside:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CustomRoles',
        'a': 'add_custom_role',

    }
    data = {
        'character_id': '',
        'avatar': '',
        'sex': '',
        'name': '',
        'title_thumb': '',
        'desc': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)



@log_request_info
def get_custom_role_list(session, request_info=None):
    """
    5.1.0-获取自定义角色列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CustomRoles',
        'a': 'get_custom_role_list',
        'page': '',
        'pagesize': ''

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def delete_custom_role(session, request_info=None):
    """
    5.1.0-删除自定义角色
    :param session:
    :param ids:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CustomRoles',
        'a': 'delete_custom_role',

    }
    data = {
        'ids': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)