import os

from utils.common import handle_test_data
from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_content_list(session, request_info=None):
    """
        获取推荐漫剧分类列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_content_list',
        'drama_id': '',
        'is_view': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)




@log_request_info
def share_drama_group(session, request_info=None):
    """
        分享对话剧连载
        :param group_id: 连载ID
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'share_drama_group',
        'group_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)





@log_request_info
def get_drama_base_info(session, request_info=None):
    """
        获取对话剧基本信息
        :param drama_id: 对话剧单篇ID
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_drama_base_info',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)




@log_request_info
def get_role_info(session, request_info=None):
    """
        获取对话剧角色信息
        :param role_id: 角色id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_role_info',
        'role_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)





@log_request_info
def share_drama(session, request_info=None):
    """
        分享对话剧
        :param drama_id: 对话剧连载单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'share_drama',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def get_like_follow_status(session, request_info=None):
    """
        获取对话剧点赞和对话剧作者关注状态
        :param drama_id: 对话剧连载单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_like_follow_status',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)








@log_request_info
def like_drama(session, request_info=None):
    """
        点赞对话剧
        :param drama_id: 对话剧连载单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'like_drama',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)






@log_request_info
def get_drama_simple_info(session, request_info=None):
    """
        获取精简的对话剧信息
        :param drama_id: 对话剧连载单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_drama_simple_info',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def get_role_drama_list(session, request_info=None):
    """
        获取导入角色页面的对话剧列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_role_drama_list',


    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def get_manage_drama_list(session, request_info=None):
    """
        获取管理页面对话剧列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_manage_drama_list',


    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def get_last_role_list(session, request_info=None):
    """
        获取对话剧连载上一篇角色列表
        :param group_id: 连载ID
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_last_role_list',
        'group_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def get_last_six_list(session, request_info=None):
    """
        获取最新使用图片列表
        :param drama_id: 对话剧连载单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_last_six_list',
        'drama_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)







@log_request_info
def user_follow(session, request_info=None):
    """
        关注/取消关注对话剧作者
        :param user_id: 用户id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'user_follow',
        'user_id': '',

    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)




@log_request_info
def get_group_drama_list(session, request_info=None):
    """
    5.1.0 同人群组对话剧列表
    :param session:
    :param groupId:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'get_group_drama_list',
        'groupId': '',
        'type': '',
        'page': 1,
        'pagesize': 30,

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def edit_drama(session, request_info=None):
    """
    5.1.0-新建（修改）对话剧
    :param session:
    :param drama_id:
    :param title_image:
    :param title:
    :param category:
    :param is_release:
    :param author_desc:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDrama',
        'a': 'edit_drama',

    }
    data = {
        'drama_id': '',
        'title_image': '',
        'title': '',
        'category': '',
        'is_release': '',
        'author_desc': '',
        'club_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)