import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_scene_package_info_by_column(session, request_info=None):
    """
    5.2.0 - 通过分栏目获取场景包信息
    :param session:
    :param column_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CloudPackage',
        'a': 'get_scene_package_info_by_column',
        'column_id': '',
        'page': '',
        'pagesize': '',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def column_package_list(session, request_info=None):
    """
    4.10.0 - 分栏目列表
    :param session:
    :param column_id:
    :param page:
    :param pagesize:
    :param block_size:
    :param history_list:
    :param editor_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CloudPackage',
        'a': 'column_package_list',
        'column_id': '',
        'page': '',
        'pagesize': '',
        'block_size': '',
        #5.13.0版本已经不传下面两个参数
        # 'category_id': '',
        # 'type': '',
        'history_list': '',
        'editor_type': '',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def category_package_list(session, category_id, page=None, pagesize=None, sp_type=None, block_size=None,
                          history_list=None, editor_type=None, scene_type=None):
    """
    4.10.0 - 大类全部素材列表
    :param session:
    :param category_id:
    :param page:
    :param pagesize:
    :param sp_type:
    :param block_size:
    :param history_list:
    :param editor_type:
    :param scene_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CloudPackage',
        'a': 'category_package_list',
        'category_id': category_id,
        'page': page,
        'pagesize': pagesize,
        'sp_type': sp_type,
        'block_size': block_size,
        'history_list': history_list,
        'editor_type': editor_type,
        'scene_type': scene_type
    }

    return session.get(api_url, params=params)


@log_request_info
def package_info_static(session, request_info=None):
    """
    4.10.0-素材包素材内容
    :param session:
    :param cloud_package_id:
    :param system:
    :param editor_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CloudPackage',
        'a': 'package_info_static',
        'cloud_package_id': '',
        'system': '',
        'editor_type': '',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_category_column(session, category_id, overall_view=None, editor_type=None):
    """
    4.10.0-获取当前分类栏目
    :param session:
    :param category_id:
    :param overall_view:
    :param editor_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CloudPackage',
        'a': 'get_category_column',
        'category_id': category_id,
        'overall_view': overall_view,
        'editor_type': editor_type,

    }

    return session.get(api_url, params=params)
