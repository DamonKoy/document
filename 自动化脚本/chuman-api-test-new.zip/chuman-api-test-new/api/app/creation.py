import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_user_single_list(session, user_id=None, page=None, pagesize=None, is_outside=None):
    """
    获取用户单篇列表
    :param session: 用户session，数据类型为requests.sessions.Session
    :param user_id: 用户id
    :param page: 页码
    :param pagesize:每页数量
    :param is_outside: 是否对外，1为是，0为否
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_user_single_list',
        'user_id': user_id,
        'page': page,
        'pagesize': pagesize,
        'is_outside': is_outside
    }
    return session.get(api_url, params=params)


@log_request_info
def get_drama_group_info(session, group_id=None, is_outside=None):
    """
    5.1.0-对话剧详情
    :param session:
    :param group_id:
    :param is_outside:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_drama_group_info',
        'group_id': group_id,
        'is_outside': is_outside
    }
    return session.get(api_url, params=params)


@log_request_info
def del_group_totally(session, group_id, type=None):
    """
    删除对话剧连载
    :param session:
    :param group_id:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'del_group_totally',

    }
    data = {
        'group_id': group_id,
        'type': type
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_my_group_list(session, page=None, pagesize=None):
    """
    获取个人连载作品
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_my_group_list',
        'pagesize': pagesize,
        'page': page

    }
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_list(session, scene_id=None):
    """
    推荐作品列表
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_recommend_list',
        'scene_id': scene_id
    }
    return session.get(api_url, params=params)


@log_request_info
def get_user_group_list(session, user_id=None, page=1, pagesize=30):
    """
    用户连载集
    :param session:
    :param user_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_user_group_list',
        'user_id': user_id,
        "page": page,
        "pagesize": pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def get_comic_group_list(session):
    """
    用户漫画连载列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_comic_group_list',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_creation_notice(session):
    """
    作品通知信息
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_creation_notice',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_group_comics_list(session, group_id=None, is_outside=None, page=1, pagesize=30, sort_type=None):
    """
    漫画连载作品集
    :param session:
    :param group_id:
    :param is_outside:
    :param page:
    :param pagesize:
    :param sort_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_group_comics_list',
        'group_id': group_id,
        'is_outside': is_outside,
        'page': page,
        'pagesize': pagesize,
        'sort_type': sort_type
    }
    return session.get(api_url, params=params)


@log_request_info
def follow_works(session, ids=None):
    """
    批量订阅作品
    :param session:
    :param ids:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'follow_works',
        'ids': ids
    }
    return session.get(api_url, params=params)


@log_request_info
def get_draft_redpoint(session):
    """
    获取草稿箱红点
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_draft_redpoint',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_user_draft_list(session, page=1, pagesize=30):
    """
    用户草稿列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_user_draft_list',
        'page': page,
        'pagesize': pagesize,
    }
    return session.get(api_url, params=params)


@log_request_info
def rough_draft_single_list(session, page=1, pagesize=30):
    """
    草稿箱单篇列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'rough_draft_single_list',
        'page': page,
        'pagesize': pagesize,
    }
    return session.get(api_url, params=params)


@log_request_info
def get_drama_group_list(session):
    """
    用户漫剧连载列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_drama_group_list',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_list(session, scene_id=None):
    """
    推荐作品列表
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_recommend_list',
        'scene_id': scene_id
    }
    return session.get(api_url, params=params)


@log_request_info
def follow_group(session, group_id=None, type=None):
    """
    关注连载
    :param session:
    :param group_id:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'follow_group',

    }
    data = {
        'group_id': group_id,
        'type': type
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def unfollow_group(session, group_id=None, type=None):
    """
    取消关注连载
    :param session:
    :param group_id:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'unfollow_group',

    }
    data = {
        'group_id': group_id,
        'type': type
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def like_group(session, obj_type=None, obj_id=None):
    """
    点赞连载
    :param session:
    :param obj_type:
    :param obj_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'like_group',
        'obj_type': obj_type,
        'obj_id': obj_id
    }
    return session.get(api_url, params=params)


@log_request_info
def del_single(session, single_ids=None, single_type=None, ctrl_type=None):
    """
    删除单篇
    :param session:
    :param single_ids:
    :param single_type:
    :param ctrl_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'del_single',
        'single_ids': single_ids,
        'single_type': single_type,
        'ctrl_type': ctrl_type
    }
    return session.get(api_url, params=params)


@log_request_info
def get_comic_group_track(session, group_id=None, page=1, pagesize=30):
    """
    漫画连载轨迹
    :param session:
    :param group_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'get_comic_group_track',
        'group_id': group_id,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def rough_draft_group_single_list(session, group_id=None, type=None, page=1, pagesize=30):
    """
    草稿箱连载单篇列表
    :param session:
    :param group_id:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'rough_draft_group_single_list',
        'group_id': group_id,
        'type': type,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def del_rough_draft_group_single_list(session, group_id=None, type=None, single_ids=None, ctrl_type=None):
    """
    删除单篇
    :param session:
    :param single_ids:
    :param single_type:
    :param ctrl_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Creation',
        'a': 'del_rough_draft_group_single_list',
        'group_id': group_id,
        'type': type,
        'single_ids': single_ids,
        'ctrl_type': ctrl_type
    }
    return session.get(api_url, params=params)
