import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def save_cover(session, type, title_img=None, json_data=None, cate_res_id_list=None, font_ids=None, decoration_ids=None, title=None, filter_id=None, background_id=None):
    """
        4.6.4-保存封面模板
        :param session:
        :param cate_res_id_list='2561,14349,32,2626,2560':
        :param font_ids='11,11,11,11,11,11,11,11':
        :param decoration_ids='12,13':
        :return:
        """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'save_cover'
    }

    data = {
        'type': type,
        'title_img': title_img,
        'json_data': json_data,
        'cate_res_id_list': cate_res_id_list,
        'font_ids': font_ids,
        'decoration_ids': decoration_ids,
        'title': title,
        'filter_id': filter_id,
        'background_id': background_id
    }

    return session.post(api_url, params=params, data=data)


@log_request_info
def delete_cover(session, cover_id):
    """
        5.1.0-删除我的模板
        :param session:
        :param cover_id:
        :return:
        """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'delete_cover',
        'cover_id': cover_id,
    }

    return session.get(api_url, params=params)


@log_request_info
def delete_custom_cover(session, ids, type):
    """
    5.1.0-删除自定义封面
    :param session:
    :param ids:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'delete_custom_cover',
        'ids': ids,
        'type': type,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_cover_tag_list(session):
    """
    5.1.0-封面模板分类列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_cover_tag_list',
    }

    return session.get(api_url, params=params)


@log_request_info
def get_buys_list(session, type, page=1, pagesize=30):
    """
    5.1.0-已购买的模板列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_buys_list',
        'type': type,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_my_list(session, type, page=1, pagesize=30):
    """
    5.1.0-我的模板列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_my_list',
        'type': type,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def add_custom_cover(session, type, cover_img):
    """
    5.1.0-添加自定义封面
    :param session:
    :param type:
    :param cover_img:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'add_custom_cover',

    }
    data = {
        'type': type,
        'cover_img': cover_img,
    }

    return session.post(api_url, params=params, data=data)


@log_request_info
def get_custom_cover_list(session, type, page=1, pagesize=50):
    """
    5.1.0-获取自定义封面列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_custom_cover_list',
        'type': type,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_decoration_category_list(session, cover_id, page=1, pagesize=50):
    """
    4.6.4-获取封面装饰素材分类列表
    :param session:
    :param cover_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_decoration_category_list',
        'cover_id': cover_id,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_decoration_list(session, decoration_id, page=1, pagesize=998):
    """
    4.6.4-获取封面装饰素材列表
    :param session:
    :param decoration_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_decoration_list',
        'decoration_id': decoration_id,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_background_list(session, background_id, page=1, pagesize=998):
    """
    4.6.4-获取封面装饰素材列表
    :param session:
    :param background_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_background_list',
        'background_id': background_id,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_cover_background_packege_list(session, cover_id, page=1, pagesize=50):
    """
    4.6.4-获取封面底图包列表
    :param session:
    :param cover_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'get_cover_background_packege_list',
        'cover_id': cover_id,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def buy_cover_resource(session, type, obj_id):
    """
    4.6.4-单独购买模板素材包
    :param session:
    :param type:
    :param obj_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'CoverEditor',
        'a': 'buy_cover_resource',
        'type': type,
        'obj_id': obj_id,
    }

    return session.get(api_url, params=params)
