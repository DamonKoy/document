import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_heat_activity_info(session, id=None, refer_id=None):
    """
    获取征稿活动详情
    :param id: 活动ID
    :param refer_id: 外部分享页，分享者ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ActivitiesTemplate',
        'a': 'get_heat_activity_info',
        'id': id,
        'refer_id': refer_id,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_ActivityCenter_List(session, page=1, pagesize=30):
    """
    活动中心首页
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ActivitiesTemplate',
        'a': 'getActivityCenterList',
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_vote_activity_info(session, id=None):
    """
    投票活动详情
    :param id: 活动ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ActivitiesTemplate',
        'a': 'get_vote_activity_info',
        'id': id,
    }

    return session.get(api_url, params=params)



