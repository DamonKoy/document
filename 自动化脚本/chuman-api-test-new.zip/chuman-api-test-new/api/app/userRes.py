import os

from utils.common import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_recharge_info(session, proc_num, user_id=None):
    """
    4.10.0-获取充值前信息
    :param session:
    :param proc_num:
    :param user_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserRes',
        'a': 'get_recharge_info',
        'proc_num': proc_num,
        'user_id': user_id
    }
    return session.get(api_url, params=params)