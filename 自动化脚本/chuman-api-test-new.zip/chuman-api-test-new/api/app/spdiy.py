import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_my_set_list_shop(session, request_info=None):
    """
    Spdiy - 4.2.1-我的发型、表情商店
    :param session:
    :param res_id:
    :param category_id:
    :param sex:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_my_set_list_shop',
        'res_id': '',
        'category_id': '',
        'sex': '',
        'page': 1,
        'pagesize': 10,

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_asset_info(session, request_info=None):
    """
    获取用户资产数据信息
    :param session:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_asset_info',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def buy_package_set(session, request_info=None):
    """
    4.9.7-购买表情、发型包
    :param session:
    :param set_id:
    :param version:
    :param coupon_token:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'buy_package_set',
        'set_id': '',
        'version': '',
        'coupon_token': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def package_buy(session, request_info=None):
    """
    4.9.7-购买素材小包
    :param package_id:
    :param session:
    :param version:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'package_buy',
        'package_id': '',
        'version': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_menu_style(session, request_info=None):
    """
    获取服装店菜单tab效果
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_menu_style'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def character_card_edit(session, request_info):
    """
    X角色卡编辑
    :param session:
    :param character_id:
    :param name:
    :param sex:
    :param title_thumb:
    :param json_data:
    :param avatar:
    :param desc:
    :param setting_img:
    :param clothing_res_id:
    :param face_res_id:
    :param hair_res_id:
    :param look_res_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'character_card_edit'
    }
    data = {
        'character_id': '',
        'name': '',
        'sex': '',
        'title_thumb': '',
        'json_data': '',
        'avatar': '',
        'desc': '',
        'setting_img': '',
        'clothing_res_id': '',
        'face_res_id': '',
        'hair_res_id': '',
        'look_res_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def character_card_list(session, request_info=None):
    """
    X角色卡列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'character_card_list'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_base_character(session, request_info=None):
    """
    获取基础角色
    :param session:
    :param sex:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_base_character',
        'sex': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_first_class_name(session, request_info=None):
    """
    获取第一类目列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_first_class_name'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_my_set_package_list_character_hair(session, sex=None, res_id=None, sp_type=None, page=1, pagesize=30):
    """
    获取已购买的发型包素材包列表(创建人物，发型)
    :param session:
    :param sex:
    :param res_id:
    :param page:
    :param pagesize:
    :param sp_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_my_set_package_list_character_hair',
        'sex': sex,
        'res_id': res_id,
        'page': page,
        'pagesize': pagesize,
        'sp_type': sp_type
    }
    return session.get(api_url, params=params)


@log_request_info
def get_my_set_package_list_comic_hair(session, request_info=None):
    """
    获取已购买的发型包素材包列表(创作)
    :param session:
    :param sex:
    :param res_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_my_set_package_list_comic_hair',
        'sex': '',
        'res_id': '',
        'page': 1,
        'pagesize': 10
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def package_category_list_character(session, category=None, page=None, pagesize=None, res_id=None, sex=None, sp_type=None):
    """
    素材包分类列表（角色）
    :param category:
    :param sex:
    :param sp_type:
    :param session:
    :param res_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'package_category_list_character',
        'category': category,
        'sp_type': sp_type,
        'sex': sex,
        'res_id': res_id,
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def package_category_list_comic(session, request_info=None):
    """
    素材包分类列表
    :param session:
    :param category:
    :param sex:
    :param res_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'package_category_list_comic',
        'category': '',
        'sex': '',
        'res_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def pay_head_frame(session, request_info=None):
    """
    购买头像框
    :param session:
    :param head_frame_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'pay_head_frame',
        'head_frame_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def cloth_action_list(session, res_id, page=1, pagesize=100):
    """
    5.13.0-获取服装的动作列表
    :param session:
    :param res_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'cloth_action_list',
        'res_id': res_id,
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def get_category_column(session, category_id=None):
    """
    获取当前分类栏目(创作)
    :param session:
    :param category_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_category_column',
        'category_id': category_id
    }
    return session.get(api_url, params=params)


@log_request_info
def get_my_set_list(session, res_id, category_id, sex, page=1, pagesize=30, sp_type=None):
    """
    获取已购买的表情列表（创建任务和创作的表情）
    :param session:
    :param category_id:
    :param res_id:
    :param category_id:
    :param page:
    :param pagesize:
    :param sex:
    :param sp_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Spdiy',
        'a': 'get_my_set_list',
        'res_id': res_id,
        'category_id': category_id,
        'page': page,
        'pagesize': pagesize,
        'sex': sex,
        'sp_type': sp_type

    }
    return session.get(api_url, params=params)
