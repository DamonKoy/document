# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_charater_suit_list_new(session, request_info=None):
    """
    Giftpack - 4.10.0-人物套装列表(简易编辑器)
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Giftpack',
        'a': 'get_charater_suit_list_new',
        'page': 1,
        'pagesize': 30,
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)