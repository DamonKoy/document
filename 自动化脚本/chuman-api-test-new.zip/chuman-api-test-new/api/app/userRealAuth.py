# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_auth_toast(session, request_info=None):
    """
    4.11.2-获取实名认证弹窗信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserRealAuth',
        'a': 'get_auth_toast',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_identity_valid(session, request_info=None):
    """
    4.10.0-实名认证
    :param session:
    :param id_number:
    :param username:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserRealAuth',
        'a': 'check_identity_valid',
    }
    data = {
        'id_number': '',
        'username': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)