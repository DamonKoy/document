# -*- coding: UTF-8 -*-
import os
from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def check_add_discuss(session, request_info=None):
    """
    ClubDiscuss - 4.10.0-检查是否允许发布社团讨论或评论
    :param session:
    :param club_id:
    :param discuss_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'check_add_discuss'
    }
    data = {
        'club_id': '',
        'discuss_id': None
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_club_discuss_list(session, request_info=None):
    """
    获取社团讨论列表
    :param session:
    :param club_id:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_club_discuss_list',
        'club_id': '',
        'type': '',
        'page': 1,
        'pagesize': 30
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def add_club_discuss(session, request_info=None):
    """
    发布社团讨论
    :param session:
    :param club_id:
    :param title:
    :param instructions:
    :param is_extern:
    :param user_id_group:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'add_club_discuss'
    }
    data = {
        'club_id': '',
        'title': '',
        'instructions': '',
        'is_extern': '',
        'user_id_group': ''
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_discuss_comment_list(session, request_info=None):
    """
    获取评论列表
    :param session:
    :param discuss_id:
    :param club_id:
    :param comment_id:
    :param last_id:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_discuss_comment_list',
        'discuss_id': '',
        'club_id': '',
        'comment_id': '',
        'last_id': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def add_discuss_comment(session, request_info=None):
    """
    回复讨论
    :param session:
    :param discuss_id:
    :param club_id:
    :param message:
    :param img_list:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'add_discuss_comment',
        'discuss_id': '',
        'club_id': '',
        'message': '',
        'img_list': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def add_discuss_comment_like(session, request_info=None):
    """
    讨论评论点赞
    :param session:
    :param comment_id:
    :param like_num:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'add_discuss_comment_like',
        'comment_id': '',
        'like_num': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_club_discuss_list(session, request_info=None):
    """
    获取社团讨论列表
    :param session:
    :param club_id:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_club_discuss_list',
        'club_id': '',
        'type': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_discuss_detail(session, request_info=None):
    """
    获取讨论详情
    :param session:
    :param discuss_id:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_discuss_detail',
        'discuss_id': '',
        'club_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_discuss_message_list(session, request_info=None):
    """
    讨论邀请消息
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_discuss_message_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_discussion_at_list(session, request_info=None):
    """
    获取@列表
    :param session:
    :param club_id:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ClubDiscuss',
        'a': 'get_discussion_at_list',
        'club_id': '',
        'type': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)