import os

from utils.common import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_club_homepage_info(session, group_id):
    """
    外部判断是否是参赛作品，能否删除
    :param session:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGameMicroService',
        'a': 'check_activity_work_delete'
    }
    data = {
        'group_id': group_id
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def reset_activity_work_num_cache(session, author_id):
    """
    外部重置用户活动作品数量缓存
    :param session:
    :param author_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGameMicroService',
        'a': 'reset_activity_work_num_cache'
    }
    data = {
        'author_id': author_id
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def update_heat_activity_work_score(session, obj_type, obj_id, score_type, activity_id, mtime, encode_token):
    """
    外部更新活动作品热度值
    :param session:
    :param obj_type:
    :param obj_id:
    :param score_type:
    :param activity_id:
    :param mtime:
    :param encode_token:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGameMicroService',
        'a': 'update_heat_activity_work_score'
    }
    data = {
        'obj_type': obj_type,
        'obj_id': obj_id,
        'score_type': score_type,
        'activity_id': activity_id,
        'mtime': mtime,
        'encode_token': encode_token
    }
    return session.post(api_url, params=params, data=data)