import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_rec_tag_list(session):
    """
        获取推荐漫剧分类列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_rec_tag_list',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_hot_game_group_list(session):
    """
        获取最热漫剧连载列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_hot_game_group_list',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_single_list(session, group_id, sort_type, is_outside, page=1, pagesize=50):
    """
        获取漫剧连载单篇列表
        :param group_id: 连载ID
        :param sort_type: 排序类型，1为正序，2为倒序
        :param is_outside: 是否对外，1为是，0为否
        :param page:页码
        :param pagesize:每页数量
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_single_list',
        'group_id': group_id,
        'sort_type': sort_type,
        'is_outside': is_outside,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_pop_style_list(session, page, pagesize):
    """
        获取会话风格列表
        :param page:页码
        :param pagesize:每页数量
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_pop_style_list',
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_single_info(session, single_id):
    """
        获取漫剧单篇信息
        :param single_id: 漫剧单篇ID
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_single_info',
        'single_id': single_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_style_list(session, page=1, pagesize=30):
    """
        获取漫剧单篇风格列表
        :param page:页码
        :param pagesize:每页数量
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_style_list',
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_gift_rank_list(session, group_id):
    """
        获取漫剧连载土豪榜列表
        :param group_id: 漫影连载id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_gift_rank_list',
        'group_id': group_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_default_style(session, group_id):
    """
        获取漫剧默认风格
        :param group_id: 漫影连载id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_default_style',
        'group_id': group_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_style_info(session, style_id):
    """
        获取漫剧单篇风格详情
        :param style_id: 风格ID
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_style_info',
        'style_id': style_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_gift_rank_info(session, group_id):
    """
        获取漫剧连载土豪榜信息
        :param group_id: 漫影连载id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_gift_rank_info',
        'group_id': group_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def like_game_single(session, single_id):
    """
        点赞漫剧单篇
        :param single_id: 漫剧单篇id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'like_game_single',

    }

    data = {
        'single_id': single_id,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def share_game_group(session, group_id):
    """
        分享漫剧连载
        :param group_id: 漫影连载id
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'share_game_group',
        'group_id': group_id,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_game_group_info(session, group_id, is_outside):
    """
        漫剧连载详情
        :param group_id: 漫剧连载id
        :param is_outside: 是否对外，1为是，0为否，默认对外
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_game_group_info',
        'group_id': group_id,
        'is_outside': is_outside,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_my_game_group_list(session, page=1, pagesize=30):
    """
        我的漫剧连载列表
        :param page:页码
        :param pagesize:每页数量
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_my_game_group_list',
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_pop_style_list(session, page=1, pagesize=30):
    """
        会话风格列表
        :param page:页码
        :param pagesize:每页数量
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_pop_style_list',
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def remove_game_single(session, group_id=None, single_ids=None):
    """
    移除漫影连载单篇
    :param session:
    :param group_id:
    :param single_ids:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'remove_game_single'
    }

    data = {
        'group_id': group_id,
        'single_ids': single_ids
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def edit_game_group(session, group_id, title=None, title_image=None, music_url=None, cover_data_json=None,
                    cover_motion_json=None, tags=None, style_id=None, desc=None, video_title=None, video_url=None):
    """
    创建/修改漫影连载
    :param session:
    :param group_id:
    :param title:
    :param title_image:
    :param music_url:
    :param cover_data_json:
    :param cover_motion_json:
    :param tags:
    :param style_id:
    :param desc:
    :param video_title:
    :param video_url:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'edit_game_group'
    }

    data = {
        'group_id': group_id,
        'title': title,
        'title_image': title_image,
        'music_url': music_url,
        'cover_data_json': cover_data_json,
        'cover_motion_json': cover_motion_json,
        'tags': tags,
        'style_id': style_id,
        'desc': desc,
        'video_title': video_title,
        'video_url': video_url
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def edit_game_single(session, group_id, single_id, title=None, title_image=None, music_url=None, cover_data_json=None, cover_motion_json=None, tags=None, style_id=None, desc=None, data_json=None, is_public=None, word_num=None, scene_num=None, event_num=None, has_scene_chat=None, is_free=None):
    """
    创建/修改漫影连载单篇
    :param session: 
    :param group_id: 
    :param single_id: 
    :param title: 
    :param title_image: 
    :param music_url: 
    :param cover_data_json: 
    :param cover_motion_json: 
    :param tags: 
    :param style_id: 
    :param desc: 
    :param data_json: 
    :param is_public: 
    :param word_num: 
    :param scene_num: 
    :param event_num: 
    :param has_scene_chat: 
    :param is_free: 
    :return: 
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'edit_game_single'
    }

    data = {
        'group_id': group_id,
        'single_id': single_id,
        'title': title,
        'title_image': title_image,
        'music_url': music_url,
        'cover_data_json': cover_data_json,
        'cover_motion_json': cover_motion_json,
        'tags': tags,
        'style_id': style_id,
        'desc': desc,
        'data_json': data_json,
        'is_public': is_public,
        'word_num': word_num,
        'scene_num': scene_num,
        'event_num': event_num,
        'has_scene_chat': has_scene_chat,
        'is_free': is_free
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def delele_game_group(session, group_id=None):
    """
    删除漫影连载
    :param session:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'delele_game_group'
    }

    data = {
        'group_id': group_id,
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def give_group_gift(session, gift_id=None, gift_num=None, receiver_id=None, group_id=None):
    """
    打赏漫影连载
    :param session:
    :param gift_id:
    :param gift_num:
    :param receiver_id:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'give_group_gift'
    }

    data = {
        'group_id': group_id,
        'gift_id': gift_id,
        'gift_num': gift_num,
        'receiver_id': receiver_id
    }
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_new_game_group_list(session, last_id=None, last_scores=None, page=1, pagesize=30):
    """
    最新漫影连载列表
    :param session:
    :param last_id:
    :param last_scores:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_new_game_group_list',
        'last_id': last_id,
        'last_scores': last_scores,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def get_category_game_group_list(session, tag_id=None, page=1, pagesize=30):
    """
    分类漫影连载列表
    :param session:
    :param last_id:
    :param last_scores:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'get_category_game_group_list',
        'tag_id': tag_id,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


@log_request_info
def give_single_gift(session, gift_id=None, gift_num=None, receiver_id=None, single_id=None):
    """
    打赏漫影单篇
    :param session:
    :param gift_id:
    :param gift_num:
    :param receiver_id:
    :param single_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AdventureGame',
        'a': 'give_single_gift'
    }

    data = {
        'single_id': single_id,
        'gift_id': gift_id,
        'gift_num': gift_num,
        'receiver_id': receiver_id
    }
    return session.post(api_url, params=params, data=data)







