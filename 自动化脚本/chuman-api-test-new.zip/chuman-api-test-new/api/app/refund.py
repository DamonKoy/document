# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def refund_user_id(session, request_info=None):
    """
    进入退款申请页用户user_id
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Refund',
        'a': 'refund_user_id',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params, verify=False)



@log_request_info
def refund_detail(session, request_info=None):
    """
    用户查询退款工单记录
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Refund',
        'a': 'refund_detail',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params, verify=False)


@log_request_info
def create(session, request_info=None):
    """
    用户提交退款工单
    :param session:
    :param user_name:
    :param user_telephone:
    :param id_card_front:
    :param id_card_back:
    :param book_main_pic:
    :param book_guarder_pic:
    :param book_child_pic:
    :param refund_type:
    :param ali_account:
    :param ali_real_name:
    :param bank_name:
    :param user_email:
    :param id_card_no:
    :param bank_card_no:
    :param bank_real_name:
    :param user_phone:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Refund',
        'a': 'create',

    }
    data = {'user_name': '', 'user_telephone': '', 'id_card_front': '', 'id_card_back': '',
           'book_main_pic': '', 'book_guarder_pic': '', 'book_child_pic': '', 'refund_type': '',
            'ali_account': '', 'ali_real_name': '','bank_name': '', 'user_email': '',
            'id_card_no': '', 'bank_card_no': '', 'bank_real_name': '', 'user_phone': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data, verify=False)




@log_request_info
def update_refund(session, request_info=None):
    """
    获取用户提交申请退款信息
    """
    params = {
        'm': 'Api',
        'c': 'Refund',
        'a': 'update_refund',

    }
    data = {'refund_no': '', 'type': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data, verify=False)