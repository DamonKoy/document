import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_template_category_list(session, type):
    """
    5.0.0-漫画模板分类列表
    :param session:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicTemplate',
        'a': 'get_template_category_list',
        'type': type,
    }

    return session.get(api_url, params=params)


@log_request_info
def get_template_list(session, category_id, page=None, pagesize=None):
    """
    4.11.0-漫画模板列表
    :param session:
    :param category_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicTemplate',
        'a': 'get_template_list',
        'category_id': category_id,
        'page': page,
        'pagesize': pagesize
    }

    return session.get(api_url, params=params)


@log_request_info
def save_user_comic_template(session):
    """
    4.9.1-保存用户模板信息
    :param session:
    :param block:
    :param title_img:
    :param height:
    :param width:
    :param data_json:
    :param title:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicTemplate',
        'a': "save_user_comic_template"
    }

    data = {
        'block': 1,
        'title_img': "app/comics/titles/title_53874218_1_c869a1a3aaef465396c0261489b747ed.jpg",
        'height': 800,
        'width': 640,
        'data_json': "app/comics/jsons/json_53874218_542f3a7fc31a4b2b99ee271267c8c0ed.json",
        'title': "test"
    }

    return session.post(api_url, params=params, data=data)
