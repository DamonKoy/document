# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_banner_list(session, request_info=None):
    """
    获取首页新闻列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_banner_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_active_block_list(session, request_info=None):
    """
    获取推荐四宫格列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_active_block_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_club_list(session, request_info=None):
    """
    获取首页热门推荐讨论列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_club_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_work_ranking_list(session, request_info=None):
    """
    获取首页排行榜列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_work_ranking_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_ads_banner(session, request_info=None):
    """
    获取首页广告横幅列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_ads_banner',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_special_topic_list(session, request_info=None):
    """
    获取首页专题推荐列表
    :param session:
    :param scene_id: 场景id
    :param jump_id: 阅读最后一篇的id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_special_topic_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_comic_single_list(session, request_info=None):
    """
    获取首页漫画单篇列表
    :param session:
    :param scene_id: 场景id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_comic_single_list',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def homepage_feed_list(session, request_info=None):
    """
    获取首页feed推荐列表
    :param session:
    :param scene_id: 场景id
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'homepage_feed_list',
        'scene_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_club_theme_list(session, request_info=None):
    """
    获取首页热门讨论主题列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_club_theme_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_activity_center(session, request_info=None):
    """
    获取首页活动中心列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_activity_center',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_homepage_bone(session, request_info=None):
    """
    5.1.0-首页骨架
    :param session:
    :param page:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_activity_center',
        'scene_id': '',
        'page': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_short_video_list(session, request_info=None):
    """
    4.11.0-获取短视频列表
    :param session:
    :param scene_id:
    :param tab_scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_short_video_list',
        'scene_id': '',
        'tab_scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_shadow_banner_list(session, request_info=None):
    """
    4.9.81-首页banner列表
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_shadow_banner_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_comic_single_list(session, request_info=None):
    """
    首页漫画单篇
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_comic_single_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_live_broadcast_list(session, request_info=None):
    """
    首页直播列表
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_live_broadcast_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_official_comic_list(session, request_info=None):
    """
    首页官方精选漫画
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_official_comic_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_official_game_list(session, request_info=None):
    """
    首页官方精选漫剧
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_official_game_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_channel_list(session, request_info=None):
    """
    首页频道推荐
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_channel_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_club_list(session, request_info=None):
    """
    首页社团推荐
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_club_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_club_list_by_theme(session, request_info=None):
    """
    社团推荐-通过一级主题获取社团列表
    :param page:
    :param pagesize:
    :param session:
    :param first_theme_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_club_list_by_theme',
        'first_theme_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_club_theme_list(session, request_info=None):
    """
    社团推荐-获取社团主题列表
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_recommend_club_theme_list',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_special_topic_list(session, request_info=None):
    """
    首页内容专题
    :param jump_id:
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_special_topic_list',
        'scene_id': '',
        'jump_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_work_ranking_list(session, request_info=None):
    """
    首页排行榜
    :param rank_type:
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'get_work_ranking_list',
        'scene_id': '',
        'rank_type': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def homepage_feed_list(session, request_info=None):
    """
    首页推荐列表
    :param pagesize:
    :param page:
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomepageSlice',
        'a': 'homepage_feed_list',
        'scene_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
