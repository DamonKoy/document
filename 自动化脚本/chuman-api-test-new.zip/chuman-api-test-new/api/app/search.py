import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def search_panel(session, request_info=None):
    """
    获取搜索热词列表
    :params proc_type: 类型
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Search',
        'a': 'search_panel',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def search_proc(session, request_info=None):
    """
    获取综合搜索结果
    :params proc_type: 类型
    :params page: 页数
    :params pagesize: 每页数量
    :params keyword: 搜索词
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Search',
        'a': 'search_proc',
        'proc_type': "",
        'keyword': "",
        'page': 1,
        'pagesize': 10,

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
