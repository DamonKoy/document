import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_club_homepage_info(session, club_id=None, page=None, pagesize=None):
    """
    5.0.0 获取喜欢主题，感兴趣社团，招揽信息，我的社团首页信息，热门讨论信息
    :param session:
    :param club_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_homepage_info',
        'club_id': club_id,
        'page': page,
        'pagesize': pagesize,
    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_homepage_info(session, request_info=None):
    """
    5.0.0 获取喜欢主题，感兴趣社团，招揽信息，我的社团首页信息，热门讨论信息
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_homepage_info',
        'club_id': '',
        'page': '',
        'pagesize': '',
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def is_club_banned(session, club_id):
    """
    Club - 4.10.0-社团是否被封禁
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'is_club_banned',

    }
    data = {
        'club_id': club_id
    }

    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def is_club_banned(session, request_info=None):
    """
    Club - 4.10.0-社团是否被封禁
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'is_club_banned',

    }
    data = {
        'club_id': ''
    }

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def get_club_home_page(session, club_id):
    """
    Club - 4.10.0-获取漫画社主页
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_home_page',
        'club_id': club_id

    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_home_page(session, request_info=None):
    """
    Club - 4.10.0-获取漫画社主页
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_home_page',
        'club_id': ''
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def checkUserClub(session):
    """
    检查用户是否已创建社团
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'checkUserClub'

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def checkUserClub(session, request_info=None):
    """
    检查用户是否已创建社团
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'checkUserClub'

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_club_member_list(session, club_id, page=None, pagesize=None):
    """
    4.9.6-获取社团成员人设信息列表
    :param session:
    :param club_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_member_list',
        'club_id': club_id,
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_member_list(session, request_info=None):
    """
    4.9.6-获取社团成员人设信息列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_member_list',
        'club_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def getClubNoticeUnreadNum(session):
    """
    消息--未读数量信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'getClubNoticeUnreadNum'
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def getClubNoticeUnreadNum(session, request_info=None):
    """
    消息--未读数量信息
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'getClubNoticeUnreadNum'
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_manage_info(session, club_id):
    """
    漫画社管理页面
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_manage_info',
        'club_id': club_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_manage_info(session, request_info=None):
    """
    漫画社管理页面
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_manage_info',
        'club_id': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def add_club_theme_feedback(session, title):
    """
    填写用户反馈主题
    :param session:
    :param title:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'add_club_theme_feedback'
    }
    data = {
        'title': title
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def add_club_theme_feedback(session, request_info=None):
    """
    填写用户反馈主题
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'add_club_theme_feedback'
    }
    data = {
        'title': ''
    }
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def club_latest_work_list(session, club_id, page=None, pagesize=None):
    """
    漫画社信息作品最近更新列表
    :param session:
    :param club_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'club_latest_work_list',
        'club_id': club_id,
        'page': page,
        'pagesize': pagesize
    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def club_latest_work_list(session, request_info=None):
    """
    漫画社信息作品最近更新列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'club_latest_work_list',
        'club_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def edit_club(session, id, logo_url, name, descp, theme_first_id, theme_second_id):
    """
    新建/修改社团
    :param session:
    :param id:
    :param logo_url:
    :param name:
    :param descp:
    :param theme_first_id:
    :param theme_second_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'edit_club'
    }
    data = {
        'id': id,
        'logo_url': logo_url,
        'name': name,
        'descp': descp,
        'theme_first_id': theme_first_id,
        'theme_second_id': theme_second_id
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def edit_club(session, request_info=None):
    """
    新建/修改社团
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'edit_club'
    }
    data = {
        'id': '',
        'logo_url': '',
        'name': '',
        'descp': '',
        'theme_first_id': '',
        'theme_second_id': ''
    }
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def get_club_add_limit(session):
    """
    判定社团创建等级限制
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_add_limit'
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_add_limit(session, request_info=None):
    """
    判定社团创建等级限制
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_add_limit'
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


# @log_request_info
# def get_club_category_first(session):
#     """
#     获取社团分类-一级主题
#     :param session:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Club',
#         'a': 'get_club_category_first'
#     }
#     return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_category_first(session, request_info=None):
    """
    获取社团分类-一级主题
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_category_first'
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_club_category_second(session, theme_first_id):
    """
    获取社团分类-二级主题
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_category_second',
        'theme_first_id': theme_first_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_category_second(session, request_info=None):
    """
    获取社团分类-二级主题
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_category_second',
        'theme_first_id': ''
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_club_list_by_theme(session, theme_first_id, theme_second_id, page=None, pagesize=None):
    """
    获取社团列表
    :param session:
    :param theme_first_id:
    :param theme_second_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_list_by_theme',
        'theme_first_id': theme_first_id,
        'theme_second_id': theme_second_id,
        'page': page,
        'pagesize': pagesize,
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_list_by_theme(session, request_info=None):
    """
    获取社团列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_list_by_theme',
        'theme_first_id': '',
        'theme_second_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_club_position_list(session, club_id):
    """
    获取社团职位列表
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_position_list',
        'club_id': club_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_position_list(session, request_info=None):
    """
    获取社团职位列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_position_list',
        'club_id': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_club_theme_first_list(session, page=None, pagesize=None):
    """
    社团创建-获取一级主题列表
    :param pagesize:
    :param page:
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_theme_first_list',
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_theme_first_list(session, request_info=None):
    """
    社团创建-获取一级主题列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_theme_first_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_club_theme_second_list(session, request_info=None):
    """
    社团创建-获取二级主题列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_theme_second_list',
        'theme_first_id': "",
        'page': "",
        'pagesize': ""
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_club_theme_second_list(session, request_info=None):
    """
    社团创建-获取二级主题列表
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_club_theme_second_list',
        'theme_first_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_member_info(session, member_id, club_id):
    """
    获取社团成员信息
    :param session:
    :param member_id:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_member_info',
        'member_id': member_id,
        'club_id': club_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_member_info(session, request_info=None):
    """
    获取社团成员信息
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'get_member_info',
        'member_id': '',
        'club_id': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def save_club_position_name(session, club_id, custom_name_json):
    """
    保存漫画社自定义职位名称
    :param session:
    :param club_id:
    :param custom_name_json:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'save_club_position_name'
    }
    data = {
        'club_id': club_id,
        'custom_name_json': custom_name_json
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def save_club_position_name(session, request_info=None):
    """
    保存漫画社自定义职位名称
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'save_club_position_name'
    }
    data = {
        'club_id': '',
        'custom_name_json': ''
    }
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def save_user_position(session, club_id, user_id, position_id):
    """
    保存用户社团职位
    :param session:
    :param club_id:
    :param user_id:
    :param position_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'save_user_position'
    }
    data = {
        'club_id': club_id,
        'user_id': user_id,
        'position_id': position_id
    }

    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def save_user_position(session, request_info=None):
    """
    保存用户社团职位
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'save_user_position'
    }
    data = {
        'club_id': '',
        'user_id': '',
        'position_id': ''
    }
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def search_recommend_club_list(session, page=None, pagesize=None):
    """
    搜索社团推荐
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'search_recommend_club_list',
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def search_recommend_club_list(session, request_info=None):
    """
    搜索社团推荐
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'search_recommend_club_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def entry_club_chat(session, club_id):
    """
    进入社团聊天室
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'entry_club_chat'
    }
    data = {
        'club_id': club_id
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def entry_club_chat(session, request_info=None):
    """
    进入社团聊天室
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'entry_club_chat'
    }
    data = {
        'club_id': ''
    }
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def exit_club_chat(session, club_id):
    """
    退出社团聊天室
    :param session:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'exit_club_chat'
    }
    data = {
        'club_id': club_id
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def exit_club_chat(session, request_info=None):
    """
    退出社团聊天室
    """
    params = {
        'm': 'Api',
        'c': 'Club',
        'a': 'exit_club_chat'
    }
    data = {
        'club_id': ''
    }

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)