import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_first_cs_coupon_info(session):
    """
        素材市集获取第一张优惠券信息
        :param session:
        :param request_info:
        :return：
    """
    params = {
        'm': 'Api',
        'c': 'ChumanShop',
        'a': 'get_first_cs_coupon_info',
    }
    return session.get(api_url, params=params)
