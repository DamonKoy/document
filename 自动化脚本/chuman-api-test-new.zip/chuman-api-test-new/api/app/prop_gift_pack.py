import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def buy_prop_giftpack(session, request_info=None):
    """
    购买大礼包
    :param session:
    :param prop_giftpack_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PropGiftpack',
        'a': 'buy_prop_giftpack'
    }
    data = {
        'prop_giftpack_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_prop_giftpack_info(session, request_info=None):
    """
    获取道具馆大礼包详情
    :param session:
    :param prop_giftpack_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PropGiftpack',
        'a': 'get_prop_giftpack_info',
        'prop_giftpack_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_prop_giftpack_list(session, request_info=None):
    """
    获取道具馆大礼包列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PropGiftpack',
        'a': 'get_prop_giftpack_list',
        'page': 1,
        'pagesize': 10
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)