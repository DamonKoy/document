# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def notice_list(session, request_info=None):
    """
    获取处罚公告列表
    :param session:
    :param page:
    :param pageSize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PunisNotice',
        'a': 'notice_list',
        'page': '',
        'pageSize': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def notice_detail(session, request_info=None):
    """
    获取处罚公告详细
    :param session:
    :param page:
    :param pageSize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PunisNotice',
        'a': 'notice_detail',
        'page': '',
        'pageSize': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
