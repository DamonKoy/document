import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def add_comment(session, request_info=None):
    """
    添加评论
    :param session:
    :param comment_type:
    :param comment_obj_id:
    :param message:
    :param img_list:
    :param obj_type:
    :param obj_id:
    :param video_obj:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'add_comment'
    }
    data = {
        'comment_type': '',
        'comment_obj_id': '',
        'message': '',
        'img_list': '',
        'obj_type': '',
        'obj_id': '',
        'video_obj': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_comment_like(session, request_info=None):
    """
    添加评论点赞
    :param session:
    :param comment_type:
    :param comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'add_comment_like'
    }
    data = {
        'comment_type': '',
        'comment_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_comment_reply(session, request_info=None):
    """
    添加评论回复
    :param session:
    :param comment_type:
    :param comment_id:
    :param comment_obj_id:
    :param reply_to:
    :param message:
    :param img_list:
    :param obj_type:
    :param obj_id:
    :param video_obj:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'add_comment_reply'
    }
    data = {
        'comment_type': '',
        'comment_id': '',
        'comment_obj_id': '',
        'reply_to': '',
        'message': '',
        'img_list': '',
        'obj_type': '',
        'obj_id': '',
        'video_obj': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_reply_comment_like(session, request_info=None):
    """
    添加回复评论点赞
    :param session:
    :param comment_type:
    :param comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'add_reply_comment_like'
    }
    data = {
        'comment_type': '',
        'comment_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def del_comment(session, request_info=None):
    """
    删除评论
    :param session:
    :param comment_type:
    :param comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'del_comment'
    }
    data = {
        'comment_type': '',
        'comment_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_comment_info(session, request_info=None):
    """
    评论信息详情
    :param session:
    :param comment_type:
    :param comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'get_comment_info',
        'comment_type': '',
        'comment_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_comment_new_reply_list(session, request_info=None):
    """
    评论最新回复列表
    :param session:
    :param comment_type:
    :param comment_id:
    :param last_id:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'get_comment_new_reply_list',
        'comment_type': '',
        'comment_id': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


def get_hot_comment_list(session, request_info=None):
    """
    热门评论列表
    :param session:
    :param obj_id:
    :param comment_type:
    :param last_id:
    :param pagesize:
    :param first_comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'get_hot_comment_list',
        'obj_id': '',
        'comment_type': '',
        'last_id': '',
        'pagesize': '',
        'first_comment_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


def get_new_comment_list(session, request_info=None):
    """
    最新评论列表
    :param session:
    :param obj_id:
    :param comment_type:
    :param last_id:
    :param pagesize:
    :param first_comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comment',
        'a': 'get_new_comment_list',
        'obj_id': '',
        'comment_type': '',
        'last_id': '',
        'pagesize': '',
        'first_comment_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)