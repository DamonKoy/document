import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_update_drama_group_list(session, request_info=None):
    """
        获取有更新的对话剧连载列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_update_drama_group_list',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def like_drama_group(session, request_info=None):
    """
        点赞对话剧连载
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'like_drama_group',
        'group_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


@log_request_info
def get_group_drama_list(session, request_info=None):
    """
        获取对话剧连载的对话剧列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_group_drama_list',
        'group_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_manage_drama_group_list(session, request_info=None):
    """
        获取管理页面对话剧连载列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_manage_drama_group_list',
        'page': '',
        'pagesize': '',
        'type': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_drama_group_base_info(session, request_info=None):
    """
        获取对话剧连载基本信息
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_drama_group_base_info',
        'group_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_music_main_page(session, request_info=None):
    """
        获取音效主页信息（第一次打开音效页面的信息）
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_music_main_page',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_like_follow_status(session, request_info=None):
    """
        获取对话剧点赞和对话剧作者关注状态
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_like_follow_status',
        'group_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)





@log_request_info
def edit_drama_group(session, request_info=None):
    """
    新建（修改）对话剧连载
    :param session:
    :param group_id:
    :param title_image:
    :param title:
    :param category:
    :param desc:
    :param club_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'edit_drama_group',

    }
    data = {
        'group_id': '',
        'title_image': '',
        'title': '',
        'category': '',
        'desc': '',
        'club_id': '',
        'type': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)



@log_request_info
def get_can_group_drama_list(session, request_info=None):
    """
    获取可以加入连载的对话剧列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_can_group_drama_list',
        'type': '',
        'page': '',
        'pagesize': '',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def del_drama_group(session, request_info=None):
    """
    移除对话剧连载
    :param session:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'del_drama_group',
    }
    data = {
        'group_id': '',
            }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_drama_contribute_list(session, request_info= None):
    """
        获取对话剧推荐列表
        :param session:
        :param group_id:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'ChumanDramaGroup',
        'a': 'get_drama_contribute_list',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



