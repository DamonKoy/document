import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def my_groups(session, page, pagesize):
    """
        我的集
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'my_groups',
        'page': page,
        'pagesize': pagesize,


    }

    return session.get(api_url, params=params)


@log_request_info
def comic_create_comic_list(session, request_info=None):
    """
        我的漫画单篇列表
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_create_comic_list',
        'page': 1,
        'pagesize': 10,


    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def group_info(session, id):
    """
     连载详情
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'group_info',
        'id': id,

    }

    return session.get(api_url, params=params)


@log_request_info
def brand_new_comment_list(session, comic_id, page, pagesize, first_comment_id):
    """
    获取漫画最新评论列表
    :param session:
    :param comic_id:
    :param page:
    :param pagesize:
    :param first_comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'brand_new_comment_list',
        'comic_id': comic_id,
        'page': page,
        'pagesize': pagesize,
        'first_comment_id': first_comment_id,

    }

    return session.get(api_url, params=params)


@log_request_info
def comic_create_group_list(session, page=1, pagesize=30):
    """
    4.5.2-获取画漫画连载列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_create_group_list',
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


@log_request_info
def group_track(session, id, page, pagesize):
    """
    Comic - 大作轨迹
    :param session:
    :param id:
    :param page:
    :param pagesize:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'group_track',
        'id': id,
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


@log_request_info
def my_comics(session, page, pagesize):
    """
    我的漫画
    :param session:
    :param page:
    :param pagesize:
    :return:
    """


    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'my_comics',
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


@log_request_info
def group_comics(session, id, order, page, pagesize):
    """
    Comic - 连载漫画列表
    :param session:
    :param id:
    :param order:
    :param page:
    :param pagesize:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'group_comics',
        'id': id,
        'order': order,
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


@log_request_info
def share_config(session, type):
    """
    Comic - 5.1.0--获取分享配置
    :param session:
    :param type:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'share_config',
        'type': type,

    }

    return session.get(api_url, params=params)


@log_request_info
def get_top_tag_list(session):
    """
    Comic - (内容频道版本)作品分类顶部tag列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'get_top_tag_list',



    }

    return session.get(api_url, params=params)


@log_request_info
def comic_tags(session, page, pagesize):
    """
    Comic - (内容频道版本)作品分类列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_tags',
        'page': page,
        'pagesize': pagesize,



    }

    return session.get(api_url, params=params)


@log_request_info
def comic_edit(session, id=0, title='test', data_json='test',
               cover_json='', font_face='test',
               title_image='',
               version=1, state=1,
               comic_type=0, is_new_comic=0):

    """
    Comic - 4.10.0-漫画编辑
    :param session:
    :param id:
    :param title:
    :param data_json:
    :param cover_json:
    :param font_face:
    :param title_image:
    :param version:
    :param state:
    :param comic_type:
    :param is_new_comic:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_edit',

    }
    data = {'id': id, 'title': title, 'data_json': data_json, 'cover_json': cover_json,
            'font_face': font_face, 'title_image': title_image,
            'version': version,  'state': state,
             'comic_type': comic_type, 'is_new_comic': is_new_comic,
            }

    return session.post(api_url, params=params, data=data)


@log_request_info
def app_home_page(session):
    """
    Comic - 获取APP主页
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'app_home_page',

    }

    return session.get(api_url, params=params)


@log_request_info
def myComicGroupCount(session, version):
    """
    Comic - z个人主页我的漫画连载数
    :param session:
    :param version:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'myComicGroupCount',
        'version': version,


    }

    return session.get(api_url, params=params)


@log_request_info
def comic_del(session, id):
    """
    删除漫画单篇
    :param session:
    :param id:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_del',
    }
    data = {
        'id': id
    }

    return session.post(api_url, params=params, data=data)


@log_request_info
def group_edit(session, id, tags, name=None, title_image=None, summary=None):
    """
    Comic - 4.10.0-修改漫画分组
    :param session:
    :param id:
    :param cover_json:
    :param big_data_template_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'group_edit',
    }
    data = {
        'id': id,
        'tags': tags,
        'name': name,
        'title_image': title_image,
        'summary': summary
    }

    return session.post(api_url, params=params, data=data)


@log_request_info
def group_add(session, name=None, tags=None, summary=None):
    """
    Comic - 4.10.0-添加漫画分组
    :param session:
    :param name:
    :param cover_json:
    :param big_data_template_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'group_add',
    }
    data = {
        'name': name,
        'tags': tags,
        'summary': summary
    }

    return session.post(api_url, params=params, data=data)


@log_request_info
def comic_info(session, id):
    """
    Comic - 阅读漫画
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Comic',
        'a': 'comic_info',
        'id': id
    }

    return session.get(api_url, params=params)









