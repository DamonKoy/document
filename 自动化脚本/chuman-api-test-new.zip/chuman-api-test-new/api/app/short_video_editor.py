import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def save_voice(session, request_info=None):
    """
    保存用户音频
    :param session:
    :param upload_json:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'save_voice',


    }
    data = {"upload_json": ''}

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def save_agree(session, request_info=None):
    """
    同意协议
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'save_agree',


    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_agreement(session, request_info=None):
    """
    获取协议状态
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'get_agreement',


    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def batch_picture(session, request_info=None):
    """
    角色选择-npc
    :param session:
    :param type:
    :param history_list:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'batch_picture',
        'type': type,
        'history_list': '',
        'page': '1',
        'pagesize': '10',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_easy_template(session, request_info=None):
    """
    漫影编辑器-用户是否有简易漫画作品
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'check_easy_template',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_editor_tab(session, request_info=None):
    """
    漫影编辑器-画面编辑子类tab显示与否
    :param session:
    :param type:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'check_editor_tab',
        'type': type,
        'scene_id': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def batch_easy_template(session, request_info=None):
    """
    漫影编辑器-获取用户简易漫画列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'batch_easy_template',
        'page': '',
        'pagesize': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_sound_list(session, request_info=None):
    """
    漫影编辑器-获取音效文件列表
    :param session:
    :param page:
    :param category_id:
    :param column_id:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ShortVideoEditor',
        'a': 'get_sound_list',
        'category_id': 2,
        'column_id': '',
        'page': '',
        'pagesize': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)