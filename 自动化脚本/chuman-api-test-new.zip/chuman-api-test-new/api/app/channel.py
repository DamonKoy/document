import os
import time

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


# 只定义了接口没有具体的用例
@log_request_info
def accept_member_apply(session, request_info=None):
    """
    同意申请加入频道-内部
    :param session:
    :param apply_id: 申请加入频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'accept_member_apply'
    }
    data = {
        'apply_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)

# 只定义了接口没有具体的用例
@log_request_info
def add_channel(session, request_info=None):
    """
    创建频道-内部
    :param session:
    :param title: 标题
    :param allow_pos: 是否允许投稿，1为是，0为否，默认1
    :param title_image: 封面
    :param drama_need_audit: 漫剧是否需要审核，1为是，0为否，默认1
    :param desc: 简介
    :param game_need_audit: 漫影是否需要审核，1为是，0为否，默认1
    :param allow_join: 是否允许加入，1为是，0为否，默认1
    :param tags: 标签，多个标签用英文逗号分隔
    :param need_audit: 漫画是否需要审核，1为是，0为否，默认1
    :return:
    """
    # title = title if title is not None else str(time.time())[0:12]
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'add_channel'
    }
    data = {
        'title': '',
        'allow_pos': '',
        'title_image': '',
        'drama_need_audit': '',
        'desc': '',
        'game_need_audit': '',
        'allow_join': '',
        'tags': '',
        'need_audit': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)

# 只定义了接口没有具体的用例
@log_request_info
def add_column(session, request_info=None):
    """
    创建栏目-内部
    :param session:
    :param is_public: 是否公开，1为是，0为否
    :param name: 名称
    :param type: 栏目类型，1为漫画，2为漫剧，3为漫影
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'add_column'
    }
    data = {
        'is_public': '',
        'name': '',
        'type': '',
        'channel_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)

# 只定义了接口没有具体的用例
@log_request_info
def add_column_show(session, request_info=None):
    """
    排栏目首页-内部
    :param session:
    :param column_id: 栏目ID
    :param content_ids: 内容ID，多个以英文逗号分隔
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'add_column_show'
    }
    data = {
        'column_id': '',
        'content_ids': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_member_apply(session, request_info=None):
    """
    申请加入频道-外部
    :param session:
    :param channel_id: 频道ID
    :param content: 内容
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'add_member_apply'
    }
    data = {
        'channel_id': '',
        'content': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def channel_noti(session, request_info=None):
    """
    获取频道消息列表
    :param session:
    :param type: 消息类型
    :param channel_id: 频道ID
    :param page: 页码
    :param pagesize: 每页个数
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'channel_noti',
        'type': '',
        'channel_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def channel_noti_info(session, request_info=None):
    """
    频道消息详情
    :param session:
    :param channel_id: 频道Id
    :param noti_id: 消息ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'channel_noti_info',
        'channel_id': '',
        'noti_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def check_channel_unique(session, request_info=None):
    """
    检查频道名称唯一性-内部
    :param session:
    :param title: 频道名称
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'check_channel_unique',
        'title': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def check_save_reward(session, request_info=None):
    """
    检查是否可发奖
    :param session:
    :param channel_id: 频道ID
    :param type: 类型，1为频频道编辑发奖，2为频道作者发奖
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'check_save_reward',
        'channel_id': '',
        'type': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def del_column(session, request_info=None):
    """
    删除栏目-内部
    :param session:
    :param column_id: 栏目id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'del_column',
        'column_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def edit_channel(session, request_info=None):
    """
    编辑频道-内部
    :param session:
    :param game_column_id: 漫剧默认栏目ID
    :param drama_column_id: 对话剧默认栏目ID
    :param title: 标题
    :param column_id: 漫画默认栏目ID
    :param allow_pos: 是否允许投稿，1为是，0为否，默认1
    :param title_image: 封面
    :param drama_need_audit: 对话剧是否需要审核，1为是，0为否，默认1
    :param desc: 简介
    :param game_need_audit: 漫剧是否需要审核，1为是，0为否，默认1
    :param channel_id: 频道id
    :param allow_join: 是否允许加入，1为是，0为否，默认1
    :param tags: 标签，多个标签用英文逗号分隔
    :param need_audit: 漫画是否需要审核，1为是，0为否，默认1
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'edit_channel'
    }
    data = {
        'game_column_id': '',
        'drama_column_id': '',
        'title': '',
        'column_id': '',
        'allow_pos': '',
        'title_image': '',
        'drama_need_audit': '',
        'desc': '',
        'game_need_audit': '',
        'channel_id': '',
        'allow_join': '',
        'tags': '',
        'need_audit': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def edit_column(session, request_info=None):
    """
    编辑栏目-内部
    :param session:
    :param column_id: 栏目id
    :param name: 名称
    :param is_public: 是否公开，1为是，0为否
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'edit_column'
    }
    data = {
        'column_id': '',
        'name': '',
        'is_public': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def follow_channel(session, request_info=None):
    """
    关注频道
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'follow_channel'
    }
    data = {
        'channel_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def gain_channel_task_reward(session, request_info=None):
    """
    获取频道任务奖励-内部
    :param session:
    :param channel_id: 频道ID
    :param task_id: 任务类型，1,2,3,4
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'gain_channel_task_reward',
        'channel_id': '',
        'task_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_author_reward_info(session, request_info=None):
    """
    获取作者奖励信息
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_author_reward_info',
        'channel_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_expend_list(session, request_info=None):
    """
    频道支出日志-内部
    :param session:
    :param channel_id: 频道id
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_expend_list',
        'channel_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_income_list(session, request_info=None):
    """
    获取频道收入日志-内部
    :param session:
    :param channel_id: 频道ID
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_income_list',
        'channel_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_info(session, request_info=None):
    """
    获取频道设置信息-内部
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_info',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_log_unread(session, request_info=None):
    """
    频道资产日志未读标识
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_log_unread',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_task_list(session, request_info=None):
    """
    获取频道任务列表-内部
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_task_list',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_channel_wealth_info(session, request_info=None):
    """
    获取频道资产信息
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_channel_wealth_info',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_column_content_list(session, request_info=None):
    """
    栏目内容列表-内部
    :param session:
    :param column_id: 栏目ID
    :param last_id: 最后访问内容ID
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_column_content_list',
        'column_id': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_column_list(session, request_info=None):
    """
    获取频道栏目列表-内外通用
    :param session:
    :param channel_id: 频道id
    :param type: 栏目类型，0为所有，1为漫画，2为漫剧，3为漫影，默认所有
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_column_list',
        'channel_id': '',
        'type': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_column_show_list(session, request_info=None):
    """
    频道排首页-对内
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_column_show_list',
        'channel_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_history_recommend_list(session, request_info=None):
    """
    频道历史推荐作品列表-内部
    :param session:
    :param channel_id: 频道ID
    :param page: 页码
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_history_recommend_list',
        'channel_id': '',
        'page': '',
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_inner_channel_info(session, request_info=None):
    """
    获取频道主页-内部
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_inner_channel_info',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_member_apply_list(session, request_info=None):
    """
    获取加入频道申请列表-内部
    :param session:
    :param channel_id: 频道id
    :param last_id: 最后访问申请id
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_member_apply_list',
        'channel_id': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_member_contribute_info(session, request_info=None):
    """
    获取频道编辑贡献信息-内部
    :param session:
    :param channel_id: 频道ID
    :param user_id: 用户ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_member_contribute_info',
        'channel_id': '',
        'user_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_member_list(session, request_info=None):
    """
    获取频道成员列表-内外通用
    :param session:
    :param type: 类型，1为主编和荐稿人，0为所有人，默认所有人
    :param channel_id: 频道ID
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_member_list',
        'type': '',
        'channel_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_new_content_list(session, request_info=None):
    """
    最新收录列表-外部
    :param session:
    :param channel_id: 频道ID
    :param teenager_mode:
    :param last_id: 最后访问内容ID
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_new_content_list',
        'channel_id': '',
        'teenager_mode': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_out_channel_info(session, request_info=None):
    """
    获取频道主页-外部
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_out_channel_info',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_out_column_content_list(session, request_info=None):
    """
    栏目内容列表-外部
    :param session:
    :param last_id: 最后访问内容id
    :param column_id: 栏目id
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_out_column_content_list',
        'last_id': '',
        'column_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_out_column_show_list(session, request_info=None):
    """
    频道排首页-对外
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_out_column_show_list',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_report_info(session, request_info=None):
    """
    获取频道报表信息
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_report_info',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_reward_author_list(session, request_info=None):
    """
    获取奖励作者列表
    :param session:
    :param channel_id: 频道ID
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_reward_author_list',
        'channel_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_search_channel_list(session, request_info=None):
    """
    获取搜索频道列表-外部
    :param session:
    :param keyword: 关键字，为空时为推荐列表
    :param tags:
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_search_channel_list',
        'keyword': '',
        'tags': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_subscribed_channel_list(session, request_info=None):
    """
    获取订阅频道列表
    :param session:
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_subscribed_channel_list',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def get_today_recommend_list(session, request_info=None):
    """
    获取频道推荐作品列表-内部
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'get_today_recommend_list',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def quit_channel(session, request_info=None):
    """
    退出频道-内部
    :param session:
    :param channel_id: 频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'quit_channel'
    }
    data = {
        'channel_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def recommend_content(session, request_info=None):
    """
    推荐作品-内部
    :param session:
    :param channel_id: 频道ID
    :param content_id: 内容ID
    :param type: 类型，1为漫画，2为漫剧，3为漫影
    :param user_id: 推荐人ID
    :param desc: 简介
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'recommend_content'
    }
    data = {
        'channel_id': '',
        'content_id': '',
        'type': '',
        'user_id': '',
        'desc': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def reject_member_apply(session, request_info=None):
    """
    拒绝申请加入频道-内部
    :param session:
    :param apply_id: 申请加入频道ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'reject_member_apply'
    }
    data = {
        'apply_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def remove_member(session, request_info=None):
    """
    移除频道成员-内部
    :param session:
    :param channel_id: 频道ID
    :param user_id: 频道成员ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'remove_member'
    }
    data = {
        'channel_id': '',
        'user_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def remove_to_column(session, request_info=None):
    """
    作品移到其它栏目-内部
    :param session:
    :param content_ids: 内容ID，多个以英文逗号分隔
    :param src_column_id: 原栏目ID
    :param dest_column_id: 目标栏目ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'remove_to_column'
    }
    data = {
        'content_ids': '',
        'src_column_id': '',
        'dest_column_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def reward_member_list(session, request_info=None):
    """
    奖励成员列表
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'reward_member_list',
        'channel_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def save_channel_reward(session, request_info=None):
    """
    发放频道奖励
    :param session:
    :param channel_id: 频道ID
    :param type: 类型，1为频频道编辑发奖，2为频道作者发奖
    :param reward_info: 奖励明细，{user_id}:{res_type}:{res_value},{user_id}:{res_type}:{res_value}
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'save_channel_reward'
    }
    data = {
        'channel_id': '',
        'type': '',
        'reward_info': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def submit_recommend_contents(session, request_info=None):
    """
    确认推荐-内部
    :param session:
    :param channel_id: 频道ID
    :param contents: 推荐列表：type[类型，1为漫画，2为漫剧，3为漫影],content_id[内容ID],desc[简介]
    :param is_confirm: 是否确认，1为是，0为否
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'submit_recommend_contents'
    }
    data = {
        'channel_id': '',
        'contents': '',
        'is_confirm': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def transfer_channel(session, request_info=None):
    """
    转让频道-内部
    :param session:
    :param channel_id: 频道ID
    :param user_id: 频道成员ID，成员ID为0时转让给官方
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'transfer_channel'
    }
    data = {
        'channel_id': '',
        'user_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def unfollow_channel(session, request_info=None):
    """
    取消关注频道
    :param session:
    :param channel_id: 频道id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'unfollow_channel'
    }
    data = {
        'channel_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 只定义了接口没有具体的用例
@log_request_info
def unrecommend_content(session, request_info=None):
    """
    取消推荐作品-内部
    :param session:
    :param channel_id: 频道id
    :param content_id: 内容id
    :param type: 类型，1为漫画，2为漫剧，3为漫影
    :param user_id: 推荐人
    :param desc: 简介
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Channel',
        'a': 'unrecommend_content'
    }
    data = {
        'channel_id': '',
        'content_id': '',
        'type': '',
        'user_id': '',
        'desc': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)
