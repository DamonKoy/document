import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def add_coupon(session, request_info=None):
    """
    4.9.9-用户领取优惠券
    :param session:
    :param coupon_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Coupon',
        'a': 'add_coupon',
    }
    data = {
        'coupon_id': "",
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)






