import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def checkIsVip(session, request_info=None):
    """
    检查用户是否是会员
    :param session:
    :param request_info:
    :request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'BigMember',
        'a': 'checkIsVip'
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


@log_request_info
def getPrivilegeList(session, request_info=None):
    """
    新会员特权主页
    :param session:
    :param request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'BigMember',
        'a': 'getPrivilegeList'
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


@log_request_info
def get_privilege_list(session, request_info=None):
    """
    权益介绍
    :param session:
    :param request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'BigMember',
        'a': 'get_privilege_list'
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


@log_request_info
def open_vip_alert(session, request_info=None, vip_tag=None):
    """
    会员开通成功弹窗
    :param session:
    :param request_info:
    :param vip_tag:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'BigMember',
        'a': 'open_vip_alert',
        'vip_tag': vip_tag
    }

    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)
