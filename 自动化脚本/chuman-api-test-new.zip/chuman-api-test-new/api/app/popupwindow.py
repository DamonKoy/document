import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_homepage_alert(session, request_info = None):
    """
    获取app首页弹窗
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PopupWindow',
        'a': 'get_homepage_alert',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_abt_alert_list(session, request_info = None):
    """
    获取abt弹窗列表
    :param session:
    :param request_time:
    :param encode_token:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'PopupWindow',
        'a': 'get_abt_alert_list',
        'request_time': '',
        'encode_token': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
