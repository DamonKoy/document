import os
from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def sync(session, request_info=None):
    """
    每日签到
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'sync',
        'version': '',
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)
