import os
import requests
from utils.common import handle_test_data
from utils.decorators import log_request_info
api_url = os.getenv('api_url')


@log_request_info
def get_user_switch(session, request_info=None):
    """
    获取我的消息开关
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_user_switch',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def is_guide_user(session, request_info=None):
    """
    是否有新手引导
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'is_guide_user',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_my_list(session, request_info=None):
    """
    获取我的功能列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_my_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def user_profile(session, request_info=None):
    """
    获取我的信息
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_profile',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def follow_list(session, request_info=None):
    """
    获取我关注的用户列表
    :param session:
    :param user_id: 用户id
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'follow_list',
        'user_id': '',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def my_fans(session, request_info=None):
    """
    获取我的粉丝列表
    :param session:
    :param user_id: 用户id
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'my_fans',
        'user_id': '',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def login(request_info):
    """
    手机号码登录
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'login',
    }
    data = {
        'user': "",
        'password': "",
    }

    data = handle_test_data(data, request_info)
    return requests.post(api_url, params=params, data=data)


@log_request_info
def get_bind_phone_status(session, request_info=None):
    """
    获取手机绑定状态
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_bind_phone_status',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def user_edit(session, request_info=None):
    """
    修改用户信息
    :param session:
    :param intro: 简介
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_edit',
    }
    data = {'intro': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def user_edit_avatar(session, request_info=None):
    """
    修改用户头像
    :param session:
    :param version:
    :param avatar: 头像链接
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_edit',
    }
    data = {'version': '', 'avatar': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_verified(session, request_info=None):
    """
    获取发送到手机的注册验证码
    :param session:
    :param phone_num:手机号码
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_verified',
        'phone_num': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_subscribed_user_action_list(session, request_info=None):
    """
    获取订阅用户动态列表
    :param session:
    :param last_id: 最后浏览的id
    :param page: 页码
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_subscribed_user_action_list',
        'last_id': '',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_user_action_list(session, request_info=None):
    """
    获取订阅用户动态列表
    :param session:
    :param user_id: 用户id
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_new_user_action_list',
        'user_id': '',
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def user_info(session, request_info=None):
    """
    获取订阅用户动态列表
    :param session:
    :param user_id: 用户id
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_info',
        'user_id': '',
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def contact_home_page(session, request_info=None):
    """
    获取触友主页面信息
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'contact_home_page',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_first_fan_and_like(session, request_info=None):
    """
    获取第一个点赞与关注信息
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_first_fan_and_like',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_interest_user_list(session, request_info=None):
    """
    获取可能感兴趣的人
    :param session:
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_interest_user_list',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_gold_gem_switch(session, request_info=None):
    """
    获取用户允许金钻抵消开关
    :param session:
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_gold_gem_switch',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_personality_dress_type(session, request_info=None):
    """
    获取个性装扮分类
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_personality_dress_type',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_personality_dress_list(session, request_info=None):
    """
    获取用户允许金钻抵消开关
    :param session:
    :param dress_type: 类型（1头像框；2人设背景；3聊天气泡；4进场动效）
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_personality_dress_list',
        'dress_type': '',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def set_user_background(session, request_info=None):
    """
    获取用户允许金钻抵消开关
    :param session:
    :param background_img: 背景图片地址
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'set_user_background',
    }
    data = {'background_img': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_subscribed_user_info(session, request_info=None):
    """
    获取订阅用户详情
    :param session:
    :param user_id: 用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_subscribed_user_info',
        'user_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_action_user_info(session, request_info=None):
    """
    获取关注圈用户详情
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_action_user_info',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def gift_points(session, request_info=None):
    """
    打赏用户
    :param session:
    :param coins: 金币
    :param gems: 钻石
    :param to_user: 用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'gift_points',
    }
    data = {'coins': '', 'gems': '', 'to_user': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def user_follow_objs(session, request_info=None):
    """
    批量关注对象
    :param session:
    :param ids: 用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_follow_objs',
    }
    data = {'ids': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def set_user_switch(session, request_info=None):
    """
    设置我的消息开关
    :param session:
    :param allow_chat_noti: 接收聊天消息通知（聊天消息），1为是，0为否,
    :param allow_getui: 接收个推（新消息通知），1为是，0为否,
    :param allow_group_greet: 接收群聊打招呼（允许频道邀请），1为是，0为否,
    :param allow_invite: 接收社团邀请（允许社团邀请），1为是，0为否,
    :param allow_user_greet: 接收陌生人打招呼（允许添加好友），1为是，0为否,
    :param allow_friend_phone: 接收好友连麦通知，1为是，0为否,
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'set_user_switch',
    }
    data = {'allow_chat_noti': '', 'allow_getui': '',
            'allow_group_greet': '', 'allow_invite': '',
            'allow_user_greet': '', 'allow_friend_phone': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_attention_value(session, request_info=None):
    """
    增加用户关注值
    :param session:
    :param type: 用户id
    :param type: 类型，1为点击详情，2为点赞，3为评论
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'add_attention_value',
    }
    data = {'user_id': '', 'type': type}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_creation_log_list(session, request_info=None):
    """
    我关注的动态
    :param session:
    :param last_id: 最后访问的ID
    :param pagesize: 每页数量
    :param version: 版本号：1
    :param type: 类型，0为全部，1为大触，2为追番，3为漫画社
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_creation_log_list',
        'last_id': '',
        'pagesize': 10,
        'version': '',
        'type': type,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def add_not_interest_user_list(session, request_info=None):
    """
    添加不感兴趣的人
    :param session:
    :param target_id: 目标用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'add_not_interest_user_list',
        'target_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def save_user_tag(session, request_info=None):
    """
    保存用户标签
    :param session:
    :param tag_names: 用户标签
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'save_user_tag',
    }
    data = {'tag_names': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def change_entry_effect(session, request_info=None):
    """
    保存用户标签
    :param session:
    :param obj_id: 装扮id
    :param anchor_id: 主播id（直播间更换时才传）
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'change_entry_effect',
    }
    data = {'obj_id': '', 'anchor_id': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def user_luck(session, request_info=None):
    """
    获取用户运气值
    :param session:
    :param user_id: 用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_luck',
    }
    data = {'user_id': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_target_like(session, request_info=None):
    """
    点赞对象
    :param session:
    :param type: 类型，1为单篇，2为连载，3为帖子，4为悬赏，5为梦映岛心情故事，6为FM，7为发布动态，8交流帖，
    9视频帖子，10直播动态,101为单篇评论，102为连载评论，103为帖子评论，104为悬赏评论，105为梦映岛心情故事评论，
    106为FM评论，107为发布动态评论，108交流帖评论
    :param sp_type: 子分类，type[1,2,101,102]:1为漫画，2为漫剧，3为漫影，type[5,105]:1为故事，2为心情
    :param target_id:对象ID
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'add_target_like',
    }
    data = {'type': type, 'sp_type': '', 'target_id': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def card_game_draw(session, request_info=None):
    """
    纸牌游戏
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'card_game_draw',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_luck(session, request_info=None):
    """
    检查用户运气值
    :param session:
    :param user_id: 用户id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'check_luck',
    }
    data = {'user_id': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_personality_banner(session, request_info=None):
    """
    检查用户运气值
    :param session:
    :param channel: 1头像框列表，2背景列表，3气泡列表，4进场动效列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_personality_banner',
        'channel': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def change_chat_bubble(session, request_info=None):
    """
    检查用户运气值
    :param session:
    :param obj_id: 装扮id
    :param anchor_id: 主播id（直播间更换时才传）
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'change_chat_bubble',
    }
    data = {
        'obj_id': '',
        'anchor_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def thirdparty_login(session, request_info=None):
    """
    第三方登录
    :param session:
    :param name: 登录方式：qq、wechat、weibo
    :param session_token:
    :param version:
    :param username:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'thirdparty_login',
    }
    data = {
        'name': '',
        'session_token': '',
        'version': '',
        'username': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def follow(session, request_info=None):
    """
    关注用户
    :param session:
    :param following_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'follow',
    }
    data = {
        'following_id': '',
        'version': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def follow_remove(session, request_info=None):
    """
    取消关注用户
    :param session:
    :param following_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'follow_remove',
    }
    data = {
        'following_id': '',
        'version': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)



@log_request_info
def get_verified_test(session, request_info=None):
    """
    测试脚手架接口--获取注册时的验证码
    :param session:
    :param phone_num:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'get_verified_test',
        'phone_num': '',



    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)




@log_request_info
def new_register(session, request_info=None):
    """
    注册用户，生成userid
    :param session:
    :param check_code:
    :param phone_num:
    :param pwd:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'new_register',

    }
    data = {'check_code': '', 'phone_num': '', 'pwd': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)