import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_selected_post_list(session, type, region_id, page, pagesize):
    """
    Post - 5.1.0- 话题精华帖子列表
    :param session:
    :param type:
    :param region_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_selected_post_list',
        'type': type,
        'region_id': region_id,
        'page': page,
        'pagesize': pagesize,

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_selected_post_list(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_selected_post_list',
        'type': '',
        'region_id': '',
        'page': '',
        'pagesize': '',
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def add_post(session, owner_type, owner_id, type, title, content):
    """
    Post - 5.1.0-发布帖子
    :param session:
    :param owner_type:
    :param owner_id:
    :param type:
    :param title:
    :param content:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'add_post',

    }
    data = {'owner_type': owner_type, 'owner_id': owner_id, 'type': type, 'title': title, 'content': content}

    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def add_post(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'add_post'
    }
    data = {'owner_type': '', 'owner_id': '', 'type': '', 'title': '', 'content': ''}

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def del_post(session, post_id, type, reason=None):
    """
    删除帖子
    :param session:
    :param post_id:
    :param type:
    :param reason:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'del_post',

    }
    data = {'post_id': post_id, 'type': type, 'reason': reason}

    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def del_post(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'del_post',

    }
    data = {'post_id': '', 'type': '', 'reason': ''}

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def get_post_info(session, post_id):
    """
    Post - 5.1.0-漫区帖子详情
    :param session:
    :param post_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_post_info',
        'post_id': post_id,

    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_post_info(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_post_info',
        'post_id': ''
    }
    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_new_post_list(session, type, region_id, page, pagesize):
    """
    Post - 5.1.0-漫区最新帖子列表
    :param session:
    :param type:
    :param region_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_new_post_list',
        'type': type,
        'region_id': region_id,
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_new_post_list(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_new_post_list',
        'type': '',
        'region_id': '',
        'page': '',
        'pagesize': ''
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def get_hot_post_list(session, type, region_id, page, pagesize):
    """
    Post - 5.1.0-漫区最热帖子列表
    :param session:
    :param type:
    :param region_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_hot_post_list',
        'type': type,
        'region_id': region_id,
        'page': page,
        'pagesize': pagesize,

    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_hot_post_list(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_hot_post_list',
        'type': '',
        'region_id': '',
        'page': '',
        'pagesize': ''
    }

    params = handle_test_data(params, request_info)

    return session.get(api_url, params=params)


@log_request_info
def check_add_post(session, allow_check):
    """
    5.0.0-检查是否能发布帖子
    :param session:
    :param allow_check:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'check_add_post',
        'allow_check': allow_check,

    }

    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def check_add_post(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'check_add_post',
        'allow_check': '',

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_shadow_post_list(session, type, region_id, page=None, pagesize=None):
    """
    4.9.9-漫区最新帖子列表【yishon】【马甲包】
    :param session:
    :param type:
    :param region_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_shadow_post_list',

    }

    data = {
        'type': type,
        'region_id': region_id,
        'page': page,
        'pagesize': pagesize
    }

    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def get_shadow_post_list(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_shadow_post_list',

    }

    data = {
        'type': '',
        'region_id': '',
        'page': '',
        'pagesize': ''
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_shaow_attention_posts(session, last_id=None, page=None, pagesize=None):
    """
    4.9.81-获取用户关注帖子列表
    :param session:
    :param last_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_shaow_attention_posts',
        'last_id': last_id,
        'page': page,
        'pagesize': pagesize

    }
    return session.post(api_url, params=params)


# 2.0版本
@log_request_info
def get_shaow_attention_posts(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_shaow_attention_posts',
        'last_id': '',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def deduplicate_video_post(session, post_id=None):
    """
    用户视频贴去重
    :param session:
    :param post_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'deduplicate_video_post',
        'post_id': post_id

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def deduplicate_video_post(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'deduplicate_video_post',
        'post_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_subscribed_post_list(session, post_id=None, region_id=None, scene_id=None):
    """
    帖子推荐
    :param session:
    :param post_id:
    :param region_id:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_subscribed_post_list',
        'post_id': post_id,
        'region_id': region_id,
        'scene_id': scene_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_subscribed_post_list(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_subscribed_post_list',
        'post_id': '',
        'region_id': '',
        'scene_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def getSquareTabList(session, type=1):
    """
    获取发现子tab列表
    :param session:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'getSquareTabList',
        'type': type
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def getSquareTabList(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'getSquareTabList',
        'type': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_comment_info(session, comment_id):
    """
    帖子评论详情
    :param session:
    :param comment_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_comment_info',
        'comment_id': comment_id
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_comment_info(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_comment_info',
        'comment_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_hot_comment_list(session, post_id, last_id, first_comment_id, pagesize):
    """
    帖子热门评论列表
    :param session:
    :param post_id:
    :param last_id:
    :param first_comment_id:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_hot_comment_list',
        'post_id': post_id,
        'last_id': last_id,
        'first_comment_id': first_comment_id,
        'pagesize': pagesize

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_hot_comment_list(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_hot_comment_list',
        'post_id': '',
        'last_id': '',
        'first_comment_id': '',
        'pagesize': ''

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_comment_list(session, post_id, last_id, pagesize):
    """
    帖子最新评论列表
    :param session:
    :param post_id:
    :param last_id:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_new_comment_list',
        'post_id': post_id,
        'last_id': last_id,
        'pagesize': pagesize

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_new_comment_list(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_new_comment_list',
        'post_id': '',
        'last_id': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_post_dislike_reason_list(session):
    """
    获取不喜欢帖子原因列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_post_dislike_reason_list'
    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_post_dislike_reason_list(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_post_dislike_reason_list'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_user_attention_post_list(session, page=None, pagesize=None):
    """
    获取用户关注帖子列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_user_attention_post_list',
        'page': page,
        'pagesize': pagesize

    }
    return session.get(api_url, params=params)


# 2.0版本
@log_request_info
def get_user_attention_post_list(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'get_user_attention_post_list',
        'page': '',
        'pagesize': ''

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def select_post(session, post_id, is_selected):
    """
    帖子设为精华
    :param session:
    :param post_id:
    :param is_selected:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'select_post'

    }
    data = {
        'post_id': post_id,
        'is_selected': is_selected
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def select_post(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'select_post'

    }
    data = {
        'post_id': '',
        'is_selected': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def top_post(session, post_id, is_top):
    """
    帖子设为置顶
    :param session:
    :param post_id:
    :param is_top:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'top_post'

    }
    data = {
        'post_id': post_id,
        'is_top': is_top
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def top_post(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'top_post'

    }
    data = {
        'post_id': '',
        'is_top': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def add_dislike_post(session, post_id, region_id, region_type, reason_type,
                     reason_id, reason, black_user_id, type):
    """
    不喜欢帖子
    :param session:
    :param post_id:
    :param region_id:
    :param region_type:
    :param reason_type:
    :param reason_id:
    :param reason:
    :param black_user_id:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'add_dislike_post'
    }
    data = {
        'post_id': post_id,
        'region_id': region_id,
        'region_type': region_type,
        'reason_type': reason_type,
        'reason_id': reason_id,
        'reason': reason,
        'black_user_id': black_user_id,
        'type': type
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def add_dislike_post(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'add_dislike_post'
    }
    data = {
        'post_id': '',
        'region_id': '',
        'region_type': '',
        'reason_type': '',
        'reason_id': '',
        'reason': '',
        'black_user_id': '',
        'type': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def transfer_post(session, post_id, region_id):
    """
    转移帖子
    :param session:
    :param post_id:
    :param region_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'transfer_post'
    }
    data = {
        'post_id': post_id,
        'region_id': region_id
    }
    return session.post(api_url, params=params, data=data)


# 2.0版本
@log_request_info
def transfer_post(session, request_info=None):

    params = {
        'm': 'Api',
        'c': 'Post',
        'a': 'transfer_post'
    }
    data = {
        'post_id': '',
        'region_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)
