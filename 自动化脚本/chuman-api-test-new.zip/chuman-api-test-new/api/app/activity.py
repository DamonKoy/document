import os

from utils.common import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_anchor_rank(session, page=None, pagesize=None):
    """
    获取主播营收排行榜
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Activity',
        'a': 'get_anchor_rank',
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def get_author_rank(session, page=None, pagesize=None):
    """
    获取作者营收排行榜
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Activity',
        'a': 'get_author_rank',
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def get_video_rank(session, type, page=None, pagesize=None):
    """
    获取漫影排行榜
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Activity',
        'a': 'get_video_rank',
        'type': type,
        'page': page,
        'pagesize': pagesize
    }
    return session.get(api_url, params=params)


@log_request_info
def get_speedup_result(session, page_type=None):
    """
    获取服装拉新加速效果
    :param session:
    :param page_type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Activity',
        'a': 'get_speedup_result',
        'page_type': page_type,
    }
    return session.get(api_url, params=params)


@log_request_info
def get_character_photo(session, page_type=None, image_id=None):
    """
    获取对应的人设图
    :param session:
    :param page_type:
    :param image_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Activity',
        'a': 'get_character_photo',
        'page_type': page_type,
        'image_id': image_id
    }
    return session.get(api_url, params=params)