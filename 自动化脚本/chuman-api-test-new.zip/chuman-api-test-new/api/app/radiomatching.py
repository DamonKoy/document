import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def start_couple(session, request_info=None):
    """
    CP匹配
    :param session:
    :param sex:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'RadioMatching',
        'a': 'start_couple',
        'sex': '',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)
