import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_recommend_short_video_list(session, request_info=None):
    """
    获取漫影tab推荐列表
    :param session:
    :param scene_id: 场景id
    :param page: 页码
    :param pagesize: 页大小
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_recommend_short_video_list',
        'scene_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_my_short_video_list(session, request_info=None):
    """
    获取我发布的漫影列表
    :param session:
    :param scene_id: 场景id
    :param page: 页码
    :param pagesize: 页大小
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_my_short_video_list',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def user_video_list(session, request_info=None):
    """
    获取用户漫影列表
    :param session:
    :param type: 类型
    :param user_id: 用户id
    :param page: 页码
    :param pagesize: 页大小
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'user_video_list',
    }
    data = {
        'type': '',
        'user_id': '',
        'page': '',
        'pagesize': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def info(session, request_info=None):
    """
    Video - 5.1.0 短视频详情
    :param session:
    :param id: 漫影id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'info',
        'id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def fav(session, request_info=None):
    """
    点赞漫影
    :param session:
    :param video_id: 漫影id
    :param action: 操作 1为点赞，0为取消点赞
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'fav',
    }
    data = {
        'video_id': '',
        'action': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_video_permission(session, request_info=None):
    """
    获取发布漫影token
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_video_permission',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def publish_video(session, request_info=None):
    """
    发布漫影
    :param session:
    :param 'describe': 标题,
    :param 'classification': 分类,
    :param 'source': 来源,
    :param 'video_url': 视频链接,
    :param 'cover': 封面链接,
    :param 'duration': 时长,
    :param 'width': 宽,
    :param 'height': 高,
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'publish_video',
    }
    data = {
        'describe': '',
        'classification': '',
        'source': '',
        'video_url': '',
        'cover': '',
        'duration': '',
        'width': '',
        'height': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


#创作入口已屏蔽，删除接口先不跑
# @log_request_info
# def delete_video(session, request_info=None):
#     """
#     删除漫影
#     :param session:
#     :param id: 漫影id
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'delete_video',
#     }
#     data = {'id': ''}
#     data = handle_test_data(data, request_info)
#     return session.post(api_url, params=params, data=data)



#创作入口已屏蔽，接口先不跑
# @log_request_info
# def get_dynamic_material_list(session, request_info=None):
#     """
#     获取动态素材列表
#     :param session:
#     :param category:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_dynamic_material_list',
#         'category': category,
#         'page': page,
#         'pagesize': pagesize,
#
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)




@log_request_info
def get_first_category_list(session, request_info=None):
    """
    Video - 5.1.0 获取短视频一级分类列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_first_category_list',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def get_second_category_list(session, request_info=None):
    """
    Video - 5.1.0 获取短视频二级分类列表
    :param session:
    :param first_category_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_second_category_list',
        'first_category_id': '',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_tag_list(session, request_info=None):
    """
    Video - 5.1.0 获取短视频标签列表
    :param session:
    :param second_category_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'get_tag_list',
        'second_category_id': '',
        'page': '',
        'pagesize': '',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def check_category_and_tag_status(session, request_info=None):
#     """
#     Video - 5.1.0 判断分类和标签状态
#     :param session:
#     :param first_category_id:
#     :param second_category_id:
#     :param tag_id:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'check_category_and_tag_status',
#         'second_category_id': second_category_id,
#         'first_category_id': first_category_id,
#         'tag_id': tag_id,
#
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)




@log_request_info
def next(session, request_info=None):
    """
    Video - 5.1.0 详情页向上滑动切换视频
    :param session:
    :param video_id:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'next',
        'video_id': '',
        'scene_id': '',

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)




@log_request_info
def check_show_user_video_list(session, request_info=None):
    """
    5.0.0 检查是否显示我的短视频列表入口
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'check_show_user_video_list',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)




@log_request_info
def check_show_editor(session, request_info=None):
    """
    5.0.0 检查是否显示编辑器入口
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'check_show_editor',
        'scene_id': '',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_video_music_list(session, request_info=None):
#     """
#     5.0.0 获取声音列表
#     :param session:
#     :param category:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_video_music_list',
#         'category': category,
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)



# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_music_recommend_list(session, request_info=None):
#     """
#     5.0.0 获取声音推荐列表
#     :param session:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_music_recommend_list',
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_music_search_list(session, request_info=None):
#     """
#     5.0.0 获取声音搜索列表
#     :param session:
#     :param key_word:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_music_search_list',
#         'key_word': key_word,
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_video_subtitle(session, request_info=None):
#     """
#     5.0.0 获取花字列表
#     :param session:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_video_subtitle',
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_transition_list(session, request_info=None):
#     """
#     5.0.0 获取转场
#     :param session:
#     :param category_id:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_transition_list',
#         'category_id': category_id,
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_transition_category(session, request_info=None):
#     """
#     5.0.0 获取转场分类
#     :param session:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_transition_category',
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


# 客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_music_category_list(session, request_info=None):
#     """
#     5.0.0 获取音乐分类列表
#     :param session:
#     :param page:
#     :param pagesize:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_music_category_list',
#         'page': page,
#         'pagesize': pagesize
#     }
#
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


@log_request_info
def check_show_tab(session, request_info=None):
    """
    4.9.9检查是否显示首页tab
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'check_show_tab',
        'scene_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


#客户端已屏蔽漫影创作入口，不会触发此接口
# @log_request_info
# def get_category_list(session, request_info=None):
#     """
#     4.9.9-获取标签列表
#     :param session:
#     :return:
#     """
#     params = {
#         'm': 'Api',
#         'c': 'Video',
#         'a': 'get_category_list',
#     }
#     params = handle_test_data(params, request_info)
#     return session.get(api_url, params=params)


@log_request_info
def is_white_list(session, request_info=None):
    """
    4.9.9-判断用户是否是白名单
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Video',
        'a': 'is_white_list'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)

