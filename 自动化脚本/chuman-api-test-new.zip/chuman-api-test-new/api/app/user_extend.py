import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_vip_info(session, request_info=None):
    """
    我的会员信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserExtend',
        'a': 'get_vip_info',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)