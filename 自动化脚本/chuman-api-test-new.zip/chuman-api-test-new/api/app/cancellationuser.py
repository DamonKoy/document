import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def cancellation_user(session, reason_type, reason, is_agree, phone_num, captcha):

    params = {
        'm': 'Api',
        'c': 'CancellationUser',
        'a': 'cancellation_user',

    }
    data= {
        'reason_type': reason_type,
        'reason': reason,
        'is_agree': is_agree,
        'phone_num': phone_num,
        'captcha': captcha,

    }

    return session.post(api_url, params=params, data=data)
