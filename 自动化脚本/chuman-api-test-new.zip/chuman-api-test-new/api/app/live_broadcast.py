import os
from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def to_give_gift(session, request_info=None):
    """
    直播送礼
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'to_give_gift',
    }

    data = {
        'live_id': '',
        'gift_id': '',
        'gift_num': '',
    }

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def start_broadcasting(session, request_info=None):
    """
    直播开播
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'start_broadcasting',
    }

    data = {
        'studio_cover': 'app/live/cover/live_cover_53824953_d97b2a4cd58349399c6df3fc82128801.jpg',
        'studio_title': '未央祁27072的触live',
        'character_id': '47879308',
        'placard': '',
    }

    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def stop_broadcasting(session, request_info=None):
    """
    直播停播
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'stop_broadcasting',
    }

    data = {
        'live_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_studio_info(session, request_info=None):
    """
    获取直播间信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'get_studio_info',
    }

    data = {
        'live_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_my_wealth(session):
    """
    获取我的财富
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserExtend',
        'a': 'get_my_wealth',
    }

    return session.get(api_url, params=params)


@log_request_info
def to_follow_anchor(session, request_info=None):
    """
    关注主播
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'to_follow_anchor',
    }

    data = {
        'live_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def follow_remove(session, request_info=None):
    """
    取关
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'follow_remove',
    }

    data = {
        'version': '1',
        'following_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def share_live(session, request_info=None):
    """
    直播分享
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'share_live',
        'live_id': '',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def join_fan_group(session, request_info=None):
    """
    直播间加入粉丝团
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'join_fan_group',
    }
    data = {
        'fee_type': '1',
        'anchor_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def to_expired_fan_group(session, request_info=None):
    """
    过期粉丝团
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'to_expired_fan_group',
        'anchor_id': '',
        'user_id': '',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_recommend_anchor_list(session, request_info=None):
    """
    获取推荐的主播列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'get_new_recommend_anchor_list',
        'page': 1,
        'pagesize': 50,
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_follow_anchor_list(session, request_info=None):
    """
    获取关注的主播列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'get_follow_anchor_list',
        'page': 1,
        'pagesize': 20,
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_latest_studio_info(session, request_info=None):
    """
    获取最新直播间信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'get_latest_studio_info',
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_exp_log_list(session):
    params = {
        'm': 'Api',
        'c': 'UserExtend',
        'a': 'get_exp_log_list',
        'page_size': 10,
        'page': 1
    }

    return session.get(api_url, params=params)


@log_request_info
def given_gift_list(session):
    """
    送出的礼物列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserExtend',
        'a': 'given_gift_list',
        'page_size': 50,
        'page': 1,
        'pagesize': 50,
    }

    return session.get(api_url, params=params)


@log_request_info
def received_gift_list(session):
    """
    收到的礼物列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'UserExtend',
        'a': 'received_gift_list',
        'page_size': 50,
        'page': 1,
        'pagesize': 50,
    }

    return session.get(api_url, params=params)


@log_request_info
def user_profile(session):
    params = {
        'm': 'Api',
        'c': 'User',
        'a': 'user_profile',
    }

    return session.get(api_url, params=params)


@log_request_info
def add_to_black(session, request_info):
    """
    拉黑
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'add_to_black',
    }

    data = {
        'user_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def remove_from_black(session, request_info):
    """
    移出黑名单
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'remove_from_black',
    }

    data = {
        'user_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def editPlacardInfo(session, request_info=None):
    """
    编辑公告
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'editPlacardInfo',
    }
    data = {
        'live_id': '',
        'studio_placard': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def buy_entry_effect(session, request_info):
    """
    购买进场物效
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'buy_entry_effect',
    }

    data = {
        'obj_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def buy_chat_bubble(session, request_info):
    """
    购买聊天气泡
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'buy_chat_bubble',
    }

    data = {
        'obj_id': '',
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def to_dress_up(session, request_info):
    """
    主播换装
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'to_dress_up',
    }
    data = {
        'live_id': '',
        'json_data': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def to_change_background(session, request_info):
    """
    更换背景
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'to_change_background',
    }
    data = {
        'live_id': '',
        'material_type': '',
        'material_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def getSetupUserList(session, request_info):
    """
    获取直播间被设置的用户列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'LiveBroadcast',
        'a': 'getSetupUserList',
        'live_id': '',
        'type': 1,
        'page': 1,
        'pagesize': 20
    }

    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)

