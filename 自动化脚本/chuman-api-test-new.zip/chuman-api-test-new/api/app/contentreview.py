import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def check_code_info(session, request_info = None):
    """
    4.9.8-检查审核对象内容
    :param session:
    :param content:
    :param user_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ContentReview',
        'a': 'check_code_info'
    }
    data = {
        'content': '',
        'user_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)