# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')



@log_request_info
def create_group(session, request_info=None):
    """
    创建同人群组
    :param session:
    :param logo_url:
    :param title:
    :param intro:
    :param category_first:
    :param category_second:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'create_group',
    }

    data = {
        'logo_url': '',
        'title': '',
        'intro': '',
        'category_first': '',
        'category_second': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)




@log_request_info
def get_group_first_theme_list(session, request_info=None):
    """
    获取同人群组一级主题
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'get_group_first_theme_list',
        'page': 1,
        'pagesize': 30
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def get_group_second_theme_list(session, request_info=None):
    """
    获取同人群组二级主题
    :param session:
    :param firstThemeId:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'get_group_second_theme_list',
        'firstThemeId': '',
        'page': 1,
        'pagesize': 30
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def disband_group(session, request_info=None):
    """
    解散同人群组
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'disband_group',
    }
    data = {'id': ''}


    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def batch_group(session, request_info=None):
    """
    获取同人群组列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'batch_group',
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def get_tidy_group(session, request_info=None):
    """
    简约群组主页
    :param session:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'get_tidy_group',
        'group_id': '',
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def check_user_status(session, request_info=None):
    """
    5.1.0-检查用户状态
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'check_user_status',
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def get_post_privilege(session, request_info=None):
    """
    5.1.0-获取帖子管理权限
    :param session:
    :param group_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Group',
        'a': 'get_post_privilege',
        'group_id': ''
    }


    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)