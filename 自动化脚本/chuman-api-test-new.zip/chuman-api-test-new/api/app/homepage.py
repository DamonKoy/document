import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_home_banner_list(session, request_info=None):
    """
    获取首页新闻列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_home_banner_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_home_page_alert(session, request_info=None):
    """
    获取旧版首页弹窗
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_home_page_alert',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_home_content_list(session, request_info=None):
    """
    获取旧版首页内容列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_home_content_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_obj_list(session, request_info=None):
    """
    获取旧版首页推荐内容列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_recommend_obj_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def homepage_new_list(session, request_info=None):
    """
    获取旧版首页推荐列表
    :param session:
    :param: page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'homepage_new_list',
        'page': 1,
        'pagesize': 30,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_group_list(session, request_info=None):
    """
    获取换一换作品列表
    :param session:
    :param type: 类型
    :param pagesize: 获取数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_recommend_group_list',
        'type': '',
        'pagesize': 30,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_content_list(session, request_info=None):
    """
    获取旧版首页最新内容列表
    :param session:
    :param last_time: 最后时间
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_new_content_list',
        'last_time': '',
        'pagesize': 30,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_subscribed_obj_action_list(session, request_info=None):
    """
    获取旧版首页订阅对象动态列表
    :param session:
    :param page: 页数
    :param pagesize: 每页数量
    :param time: 时间
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_subscribed_obj_action_list',
        'page': 1,
        'pagesize': 30,
        'time': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_follow_unread(session, request_info=None):
    """
    旧版检查关注是否有未读
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'check_follow_unread',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_special_info(session, request_info=None):
    """
    获取专题信息
    :params: special_id: 专题id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_new_special_info',
        'special_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def square_scenarized(session, request_info=None):
    """
    获取广场场景化
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'square_scenarized',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_recommend_like_content_list(session, request_info=None):
    """
    猜你喜欢
    :param session:
    :param scene_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'get_recommend_like_content_list',
        'scene_id': '',
        'page': 1,
        'pagesize': 30
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def homepage_new_list(session, request_info=None):
    """
    首页推荐列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'HomePage',
        'a': 'homepage_new_list',
        'page': 1,
        'pagesize': 30
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
