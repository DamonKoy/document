# -*- coding: UTF-8 -*-
import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def add_customize_emotions(session, request_info=None):
    """
    4.9.8-新增用户自定义表情包
    :param session:
    :param emoticons_url:
    :param height:
    :param width:
    :param source:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'add_customize_emotions',
        'emoticons_url': '',
        'height': '',
        'width': '',
        'source': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def delete_customize_emotions(session, request_info=None):
    """
    4.9.8-删除用户自定义表情包
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'delete_customize_emotions',
        'id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_IM_emotions_config(session, request_info=None):
    """
    4.9.8-获取聊天表情包配置信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'get_IM_emotions_config',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_chuman_emotions_list(session, request_info=None):
    """
    4.9.8-获取触触表情包列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'get_chuman_emotions_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_official_emotions_list(session, request_info=None):
    """
    4.9.8-获取官方表情包列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'get_official_emotions_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def picture_transfer_signature(session, request_info=None):
    """
    4.9.8-获取图片转存签名
    :param session:
    :param string:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'picture_transfer_signature',
        'string': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_customize_emotions_list(session, request_info=None):
    """
    4.9.8-获取用户自定义表情包列表
    :param session:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Emoticons',
        'a': 'get_customize_emotions_list',
        'page': '',
        'pagesize': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)