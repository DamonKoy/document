import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def brand_new_get_friend_chat_list(session, request_info=None):
    """
    新版IM列表
    :param session: 用户session，数据类型为requests.sessions.Session
    :param user_ids: 必填项，用户ID，以‘,’分隔，例如1,2,3
    :param request_info:
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'brand_new_get_friend_chat_list'
    }
    data = {'user_ids': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_greet_message(session, request_info=None):
    """
    获取打招呼聊天信息列表
    :param session: 用户session，数据类型为requests.sessions.Session
    :param receiver_id: 对方用户ID
    :param request_info:
    :param greet_type: 打招呼类型：1为普通打招呼，3为CP匹配打招呼（默认1）
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_greet_message',
        'receiver_id': '',
        'greet_type': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def send_friend_greet(session, request_info=None):
    """
    发送/回复打招呼信息
    :param session: 用户session，数据类型为requests.sessions.Session
    :param receiver_id: 接收用户ID
    :param request_info:
    :param message: 打招呼信息，最多20字
    :param greet_type: 打招呼类型：1为普通打招呼，3为CP匹配打招呼
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'send_friend_greet'
    }
    data = {
        'receiver_id': '',
        'message': '',
        'greet_type': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_common_chat_list(session, request_info=None):
    """
    获取通用聊天列表（补充社团、消息通知列表）
    :param session: 用户session，数据类型为requests.sessions.Session
    :param request_info:
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_common_chat_list'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_common_chat_unread_num(session, request_info=None):
    """
    获取好友列表未读数
    :param session: 用户session，数据类型为requests.sessions.Session
    :param request_info:
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_common_chat_unread_num'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def to_friend_greet(session, request_info=None):
    """
    发起打招呼页面
    :param session: 用户session，数据类型为requests.sessions.Session
    :param user_id: 用户ID
    :param request_info:
    :param greet_type: 打招呼类型：1为普通打招呼，3为cp匹配大招呼
    :return: 该接口请求返回的响应，数据类型为requests.models.Response
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'to_friend_greet'
    }
    data = {'user_id': '', 'greet_type': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_friend_info(session, request_info=None):
    """
    获取好友详情
    :param session:
    :param request_info:
    :param friend_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_friend_info',
        'friend_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_friend_list(session, request_info=None):
    """
    好友列表
    :param session:
    :param request_info:
    :param page:
    :param pagesize:
    :return:
    """

    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_friend_list',
        'page': 1,
        'pagesize': 10,
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def brand_new_get_chat_list(session, request_info=None):
    """
    新版IM聊天列表
    :param session:
    :param request_info:
    :param friend_im_ids:
    :param group_im_ids:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'brand_new_get_chat_list',

    }
    data = {'friend_im_ids': '', 'group_im_ids': ''}
    data = handle_test_data(data, request_info)

    return session.post(api_url, params=params, data=data)


@log_request_info
def disabled_send_friend_in_batch(session, request_info=None):
    """
    隐藏一键发送好友入口
    :param session:
    :param request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'disabled_send_friend_in_batch'
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


@log_request_info
def check_show_friend_request(session, request_info=None):
    """
    是否显示一键加好友
    :param session:
    :param request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'check_show_friend_request'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_im_greet_word_list(session, request_info=None):
    """
    获取IM快捷回复语
    :param session:
    :param request_info:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'get_im_greet_word_list',
        'page': 1,
        'pagesize': 10
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def send_friend_request_in_batch(session, request_info=None):
    """
    一键发送好友请求
    :param session:
    :param request_info:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Chat',
        'a': 'send_friend_request_in_batch'
    }
    params = handle_test_data(params, request_info)
    return session.post(api_url, params=params)


