import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def notification_category_page_new(session, request_info=None):
    """
    获取评论与点赞消息
    :param: page: 页数
    :param: pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'notification_category_page_new',
        'type': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_square_noti_unread(session, request_info=None):
    """
    获取广场消息未读数
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_square_noti_unread',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def notification_list(session, request_info=None):
    """
    获取消息列表
    :param: type: 类型
    :param: pagesize： 每页数量
    :param: last_id: 最后请求的消息id
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'notification_list',
    }
    data = {
        'type': '',
        'pagesize': '',
        'last_id': '',
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_user_noti_unread(session, request_info=None):
    """
    获取我的信息
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_user_noti_unread',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_spotlight_notice_list(session, request_info=None):
    """
    获取聚合页消息列表
    :param session:
    :param column_id: 栏目id
    :param page: 页数
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_spotlight_notice_list',
        'column_id': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_spotlight_column_list(session, request_info=None):
    """
    获取聚合页栏目列表
    :param session:
    :param official_user_id: 官方自定义角色id（默认0为触漫娘）
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_spotlight_column_list',
        'official_user_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_official_user_notice_page(session, request_info=None):
    """
    官方自定义角色消息页面
    :param session:
    :param official_user_id: 官方自定义角色id
    :param last_id: 最后日志id
    :param pagesize: 每页数量
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_official_user_notice_page',
        'official_user_id': '',
        'last_id': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_user_like_list_noti(session, request_info=None):
    """
    获取用户点赞列表
    :param session:
    :param log_id: 记录id
    :param fold_type: 类型
    :param page: 页码
    :param pagesize: 每页个数
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Notification',
        'a': 'get_user_like_list_noti',
        'log_id': '',
        'fold_type': '',
        'page': '',
        'pagesize': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
