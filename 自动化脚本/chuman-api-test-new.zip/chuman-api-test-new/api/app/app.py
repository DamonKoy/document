import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def sync(session, request_info=None):
    """
      初始化第一次请求
      :param session:
      :param request_info:
      :param version:
      :return:
      """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'sync',
        'version': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def config(session, request_info=None):
    """
        获取鉴黄配置
        :param session:
        :param request_info:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'config',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_content(session, request_info=None):
    """
        检查字符串内容是否合法
        :param session:
        :param request_info:
        :param content:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'check_content',
    }
    data = {'content': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def qiniu_grant_token(session, request_info=None):
    """
        获取七牛上传或下载token
        :param session:
        :param request_info:
        :param action:
        :param query:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_grant_token',
        'action': '',
        'query': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_teenager_alert(session):
    """
        获取青少年模式弹窗信息
        :param session:
        :param request_info:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'get_teenager_alert',
    }
    # params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_ios_masking_flag(session):
    """
    IOS屏蔽审核问题内容
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'get_ios_masking_flag',
    }
    return session.get(api_url, params=params)


@log_request_info
def qiniu_delete_file(session, request_info=None):
    """
        删除七牛文件
        :param session:
        :param request_info:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_delete_file',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def qiniu_video_token(session):
    """
        获取七牛短视频上传token
        :param session:
        :param request_info:
        :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_video_token',
    }
    return session.get(api_url, params=params)


@log_request_info
def get_menu_list(session, request_info=None):
    """
    获取通用菜单选项列表
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'get_menu_list',
    }
    data = {'modules': ''}
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def qiniu_grant_token_save_key(session, request_info=None):
    """
    获取七牛上传或下载token
    :params: action: download(下载token，默认),upload(上传token)
    :params: query: 图片路径,download时必须
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_grant_token_save_key',
        'action': '',
        'query': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def qiniu_private_token(session):
    """
    获取七牛私有空间上传token
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_private_token',

    }
    return session.get(api_url, params=params)


@log_request_info
def qiniu_private_url(session, request_info=None):
    """
    获取七牛私有空间图片访问地址
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_private_url',
        'fileName': ''

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


# 只定义了接口没有具体的用例
@log_request_info
def getNewsInfo(session, request_info=None):
    """
    5.3.0-新闻获取
    :param session:
    :param news_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'getNewsInfo',
        'news_id': news_id

    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def set_device_push_id(session, request_info=None):
    """
    4.9.9-设置设备推送cid
    :param session:
    :param app_device_id:
    :param dreampix_device_id:
    :param app_push_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'set_device_push_id',
    }
    data = {
        'app_device_id': '',
        'dreampix_device_id': '',
        'app_push_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def set_new_device_token(session, request_info=None):
    """
    4.9.9-设置设备号
    :param session:
    :param app_device_id:
    :param dreampix_device_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'set_new_device_token',
    }
    data = {
        'app_device_id': '',
        'dreampix_device_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


#只有接口定义，没有具体的用例
@log_request_info
def get_qiniu_private_token(session, request_info = None):
    """
    获取七牛私有空间上传token-web端使用
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'get_qiniu_private_token',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


#只有接口定义，没有具体的用例
@log_request_info
def get_qiniu_private_url(session, request_info=None):
    """
    获取七牛私有空间图片访问地址-web端使用
    :param session:
    :param file_path:
    :param water_mark:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'get_qiniu_private_url',
        'file_path': file_path,
        'water_mark': water_mark
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def qiniu_applog_token(session):
    """
    获取七牛前端日志上传token
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'app',
        'a': 'qiniu_applog_token',
    }
    return session.get(api_url, params=params)




