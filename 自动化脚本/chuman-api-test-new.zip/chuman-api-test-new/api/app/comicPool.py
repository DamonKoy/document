import os

from utils.common import log_request_info

api_url = os.getenv('api_url')




@log_request_info
def get_comic_list(session, scene_id=None, page=1, pagesize=30):
    """
    获取漫画单篇列表
    :param session:
    :param scene_id: 场景id
    :param page: 页码
    :param pagesize: 页大小
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicPool',
        'a': 'get_comic_list',
        'scene_id': scene_id,
        'page': page,
        'pagesize': pagesize,
    }
    return session.get(api_url, params=params)