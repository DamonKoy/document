import os
from utils.decorators import log_request_info
from utils.common import handle_test_data


api_url = os.getenv('api_url')


@log_request_info
def get_space_package_list(session, request_info=None):
    params = {
        'm': 'Api',
        'c': 'ActionTemplate',
        'a': 'get_space_package_list',
        'res_ids': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_honey_word(session):
    params = {
        'm': 'Api',
        'c': 'ActionTemplate',
        'a': 'get_honey_word',
    }
    return session.get(api_url, params=params)