import os

from utils.common import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_special_effect_list(session, category_id, page=None, pagesize=None):
    """
    5.3.0获取特效列表
    :param session:
    :param category_id:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ContentVideo',
        'a': 'get_special_effect_list',
        'category_id': category_id,
        'page': page,
        'pagesize': pagesize,


    }

    return session.get(api_url, params=params)



@log_request_info
def get_category_list(session, type, page=None, pagesize=None):
    """
    5.3.0获取分类列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ContentVideo',
        'a': 'get_category_list',
        'type': type,
        'page': page,
        'pagesize': pagesize,


    }

    return session.get(api_url, params=params)



@log_request_info
def get_video_tone_list(session, category_id, page=None, pagesize=None):
    """
    5.3.0获取音色列表
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ContentVideo',
        'a': 'get_video_tone_list',
        'category_id': category_id,
        'page': page,
        'pagesize': pagesize,


    }

    return session.get(api_url, params=params)



@log_request_info
def get_voice_token(session):
    """
    5.3.0获取语音服务token
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ContentVideo',
        'a': 'get_voice_token',
    }

    return session.get(api_url, params=params)