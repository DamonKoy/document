import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_picture(session, request_info=None):
    """
    AI - 获取已处理图片
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'get_picture',

    }
    data = {
        'id': ''
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)



@log_request_info
def get_ai_fixed_text(session, request_info=None):
    """
    AI - 获取ai页面固定文案
    :param session:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'get_ai_fixed_text',
        'type': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def deal_picture(session, request_info=None):
    """
    AI - 处理图片
    :param session:
    :param pic_url:
    :param method:
    :param type:
    :param model_index:
    :param model_name:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'deal_picture',

    }
    data = {
        'pic_url': '',
        'method': '',
        'type': '',
        'model_index': '',
        'model_name': ''
    }

    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


# 客户端已经没有入口调这个接口
@log_request_info
def batch_del_picture(session, request_info=None):
    """
    AI - 5.0.0 批量删除ai记录
    :param session:
    :param ids:
    :param type:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'batch_del_picture',
        'ids': ids,
        'type': type

    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def save_picture(session, request_info=None):
    """
    AI - 5.0.0 保存ai图片到图片列表
    :param session:
    :param id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'save_picture',
        'id': id
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



@log_request_info
def batch_picture(session, request_info=None):
    """
    5.0.0 ai图片获取
    :param session:
    :param type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'AI',
        'a': 'batch_picture',
        'type': '',
        'page': '',
        'pagesize': ''
    }

    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
