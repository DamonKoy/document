import os
from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def count_share_num(session, request_info=None):
    """
    5.1.0-统计分享次数
    :param session:
    :param chuman_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'count_share_num',
        'chuman_id': '',
        'type': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def web_get_short_video_info(session, request_info=None):
    """
    4.10.0-获取分享短视频详情
    :param session:
    :param share_token:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'web_get_short_video_info',
        'share_token': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def web_get_recommend_short_video_list(session, request_info=None):
    """
    4.10.0-tab-web短视频推荐列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'web_get_recommend_short_video_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_tag_list(session, request_info=None):
    """
    漫画标签列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'get_tag_list',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def check_user_bind_status(session, request_info=None):
    """
    4.9.8-检查用户是否可以领取优惠券
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'check_user_bind_status',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_role_vote_homepage(session, request_info=None):
    """
    偶像榜主页
    :param session:
    :param user_token:
    :param group_id:
    :param authorize_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Share',
        'a': 'get_role_vote_homepage',
        'user_token': '',
        'group_id': '',
        'authorize_id': '',
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)



