# -*- coding: UTF-8 -*-
import os


from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_course_training_list(session, request_info=None):
    """
    5.4.0-获取课程练习列表
    :param session:
    :param course_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_course_training_list',
        'course_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_module_list(session, request_info=None):
    """
    5.4.0-获取触漫学院模块列表
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_module_list'
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_video_info(session, request_info=None):
    """
    5.4.0-获取视频info
    :param session:
    :param training_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_video_info'
    }
    data = {
        'training_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def buy_plate(session, request_info=None):
    """
    5.4.0-购买全套课程
    :param session:
    :param training_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'buy_plate'
    }
    data = {
        'plate_id': ''
    }
    data = handle_test_data(data, request_info)
    return session.post(api_url, params=params, data=data)


@log_request_info
def get_study_plate_list(session, request_info=None):
    """
    5.4.0-获取课程板块列表
    :param session:
    :param module_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_study_plate_list',
        'module_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_plate_list(session, request_info=None):
    """
    5.4.0-获取板块列表
    :param session:
    :param module_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Academy',
        'a': 'get_plate_list',
        'module_id': ''
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)