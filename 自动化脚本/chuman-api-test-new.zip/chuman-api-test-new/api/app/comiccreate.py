import os

from utils.decorators import log_request_info

api_url = os.getenv('api_url')


@log_request_info
def get_create_works_spdiy_list(session, scene_id):
    """
    ComicCreate - 5.0.0-创作页主页作品及角色信息
    :param session:
    :param scene_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'get_create_works_spdiy_list',
        'scene_id': scene_id,

    }

    return session.get(api_url, params=params)


@log_request_info
def get_create_new_resource_list(session):
    """
    ComicCreate - 4.9.7-获取上新信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'get_create_new_resource_list',

    }

    return session.get(api_url, params=params)


@log_request_info
def close_create_window(session):
    """
    ComicCreate - 4.9.3-关闭浮窗
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'close_create_window',

    }

    return session.get(api_url, params=params)


@log_request_info
def check_user_reward(session):
    """
    ComicCreate - 4.9.3-判断用户创建漫画是否弹窗奖励弹窗
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'check_user_reward',

    }

    return session.get(api_url, params=params)


@log_request_info
def create_homepage(session):
    """
    ComicCreate - 4.9.5-创作页主页信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'create_homepage'
    }

    return session.get(api_url, params=params)


@log_request_info
def get_create_resource_list(session):
    """
    ComicCreate - 5.0.0-创作页素材信息
    :param session:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'ComicCreate',
        'a': 'get_create_resource_list',

    }

    return session.get(api_url, params=params)