import os

from utils.decorators import log_request_info
from utils.common import handle_test_data

api_url = os.getenv('api_url')


@log_request_info
def get_conversation_list(session, request_info=None):
    """
    广场-话题列表
    :param session:
    :param from_id:
    :param region_type:
    :param page:
    :param pagesize:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Region',
        'a': 'get_conversation_list',
        'from_id': "",
        'region_type': "",
        'page': 1,
        'pagesize': 10
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)


@log_request_info
def get_new_banner_list(session, request_info=None):
    """
    广场banner列表
    :param session:
    :param subject_id:
    :return:
    """
    params = {
        'm': 'Api',
        'c': 'Region',
        'a': 'get_new_banner_list',
        'subject_id': ""
    }
    params = handle_test_data(params, request_info)
    return session.get(api_url, params=params)
