import requests


class CloudPackage:
    def __init__(self):
        # 获取用户token
        self.headers = {
          'MAuthorization': "946c573c9e2ad8f49ee4608e6da0b359:4d4781176d7783f23923cd9ed988c092:",
          'Accept-Type': "application/json, text/plain, */*",
          'Connection': "keep-alive",
          'Accept-Encoding': "gzip",
          'token': "1jc86fwbu162dnse1jjkvxvrpuy7p9px",
          'Host': "admin-center-dev.chumanapp.com",
          'way': '9'
        }
        self.data = {

        }

    def geturl(self, url):
        return requests.get(url, headers=self.headers).json()

    def posturl(self, url):
        return requests.post(url, headers=self.headers, data=self.data).json()

    def get_resultorcount(self, command, result, count=0):
        if command == "result":
            return result
        else:
            for i in result["data"]["list"]:
                if i["status"] == "1" or i["status"] == 1:
                    count += 1
            return count

    def get_category_column(self, id, command):
        result = self.geturl(f"http://admin-center-dev.chumanapp.com/admin/index/transfer?cloud_category_id={id}&page=1&pagesize=10&admin_center%7Cproxy_url=%2Fsecure%2Findex.php%3Fm%3DApi%26c%3DAdmCloudPackage%26a%3Dcloud_columns_list&admin_center%7Cextract_query=1")
        return self.get_resultorcount(command, result)






