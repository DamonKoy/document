import csv
import json
import os

import allure
import json_tools
import yaml

from utils.log import CustomLogger

logger = CustomLogger.get_logger()
env_config_file = 'config/env_config.yaml'


def get_test_data(file_path):
    """
    获取测试数据
    :param file_path: 存储测试数据的文件名
    :return: 测试数据，类型为list，如[(1,2), (3,4)]，一个元组代表一行数据
    """
    if file_path.endswith(".csv"):
        return read_csv(file_path)


def get_yaml_data(yaml_file):
    """
    获取yaml文件内容
    """
    yaml_data = {}
    with open(yaml_file, encoding='utf-8') as config_file_obj:
        yaml_obj = yaml.load(config_file_obj, Loader=yaml.FullLoader)
    for key, value in yaml_obj.items():
        yaml_data[key] = value
    return yaml_data


def get_value_from_envconfig(env, key):
    """
    获取env环境对应key的值
    """
    env_config = get_yaml_data(env_config_file)[env]
    value = env_config[key]
    return value


def read_csv(csv_file_path):
    """
    读取csv文件，并返回数据
    :param csv_file_path: csv文件的文件名
    :return: csv文件中的数据，类型为list，如[(1,2), (3,4)]，一个元组代表一行数据
    """
    data_list = []
    with open(csv_file_path, encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)
        for row in reader:
            data_list.append(tuple(row))
    return data_list


def attach_request_info_to_allure(response, env):
    """
    把请求信息以附件的形式添加到allure报告中
    :param response: 请求返回的response
    :param env: 执行环境
    :return:
    """
    response.encoding = "utf-8"
    request = response.request
    request_info = f"""请求的详细信息如下所示：
=============== request info ===============
METHOD: {request.method}
URL: {request.url}
HEADERS: {request.headers}
BODY: {request.body}

=============== response  info ===============
STATUS_CODE: {response.status_code}
HEADERS: {response.headers}
BODY: {response.text}
    """
    logger.info(request_info)
    allure.attach(request_info,  f'{env}_request_info.txt', attachment_type=allure.attachment_type.TEXT)


def write_diff_response(data, diff_data):
    """
    两个响应的内容写入对应的txt，用于本地文件对比
    :param data:
    :param diff_data:
    :return:
    """
    with open('./reports/data_response.json', mode='w+', encoding='utf-8') as fd:
        fd.write(json.dumps(data, indent=4, sort_keys=True, ensure_ascii=False))
        fd.close()

    with open('./reports/diff_data_response.json', mode='w+', encoding='utf-8') as fs:
        fs.write(json.dumps(diff_data, indent=4, sort_keys=True, ensure_ascii=False))
        fs.close()


def diff_response(res, diff_res):
    """
    对比两个响应的内容是否相同，不相同时抛出错误信息
    :param res:
    :param diff_res:
    :return:
    """
    env = os.getenv('env')
    diff_env = os.getenv('diff_env')

    attach_request_info_to_allure(res, env)
    attach_request_info_to_allure(diff_res, diff_env)

    data = res.json()
    diff_data = diff_res.json()
    write_diff_response(data, diff_data)
    result = json_tools.diff(data, diff_data)
    if result:
        logger.error(f'json对比报错，报错信息为：{result}')
        allure.attach(json.dumps(data, indent=4).encode('utf-8'),
                      f'{env}_response.json',
                      attachment_type=allure.attachment_type.JSON)
        allure.attach(json.dumps(diff_data, indent=4).encode('utf-8'),
                      f'{diff_env}_response.json',
                      attachment_type=allure.attachment_type.JSON)
        raise Exception(result)
