import os

import pytest

from conftest import get_user_session
from diff_testcases.diff_uitl import get_test_data, get_value_from_envconfig, diff_response
from utils.common import log_test_info

env = os.getenv('env')
diff_env = os.getenv('diff_env')


@pytest.mark.diff
@pytest.mark.parametrize('method, user_id, params, data', get_test_data('diff_testcases/diff_data.csv'))
@log_test_info
def test_diff(method, user_id, params, data):
    session = get_user_session(user_id, env=env)
    diff_session = get_user_session(user_id, env=diff_env)
    res = session.request(method=method,
                          url=get_value_from_envconfig(env, 'api_url'),
                          params=params,
                          data=data)
    res_diff = session.request(method=method,
                               url=get_value_from_envconfig(diff_env, 'api_url'),
                               params=params,
                               data=data)
    diff_response(res, res_diff)
