import os

from utils.log import logger
from utils import file_loader

# 环境变量配置文件路径，默认在根目录下
env_config_file = './config/env_config.yaml'


def pytest_addoption(parser):
    """
    增加自定义命令行参数
    """
    parser.addoption(
        "--env", action="store", default="demo", help="testcase execute environment"
    )
    parser.addoption(
        "--diff-env", action="store", default="demo-cf", help="diff testcase execute environment"
    )


def pytest_configure(config):
    """
    加载pytest执行项目时附带的参数；加载项目配置文件，并把其中内容添加到环境变量
    :param config:
    :return:
    """
    env = config.getoption("--env")
    os.environ['diff_env'] = config.getoption("--diff-env")
    os.environ['env'] = env
    # 加载配置文件，并把其中内容添加到环境变量
    env_config = file_loader.load_file_to_dict(env_config_file)[env]
    for key, value in env_config.items():
        os.environ[key] = str(value)


def pytest_sessionstart(session):
    """
    初始化用户数据，测试开始前执行
    :param session:
    :return:
    """
    from utils.service import init_user
    logger.info(f"\n{'=' * 50}开始测试前，初始化用户数据{'=' * 50}")
    init_user()
    logger.info(f"\n{'=' * 50}开始执行新一轮的测试用例，测试环境是{os.getenv('env')}{'=' * 50}")


def pytest_runtest_setup(item):
    logger.info(f"\n{'*' * 40}开始执行用例{item.originalname}{'*' * 40}\n")


# @pytest.hookimpl(hookwrapper=True)
# def pytest_runtest_call(item):
#     """
#     捕获单个测试用例执行过程中抛出的异常，并打印出来
#     :param item:
#     :return:
#     """
#     try:
#         outcome = yield
#         return outcome.get_result()
#     except Exception:
#         logger.exception(f'执行用例{item.originalname}过程中出现异常')
#         # raise


def pytest_runtest_teardown(item):
    logger.info(f"\n{'*' * 40}用例{item.originalname}执行完毕{'*' * 40}\n")


# @pytest.fixture(autouse=True)
# def caplog():
#     """
#     替换pytest中caplog引用的自带logging库，改为loguru，把日志信息显示到allure报告中
#     :param _caplog:
#     :return:
#     """
#     from _pytest.logging import caplog as _caplog
#
#     class PropogateHandler(logging.Handler):
#         def emit(self, record):
#             logging.getLogger(record.name).handle(record)
#
#     handler_id = logger.add(PropogateHandler(), format="{message}")
#     yield _caplog
#     logger.remove(handler_id)
