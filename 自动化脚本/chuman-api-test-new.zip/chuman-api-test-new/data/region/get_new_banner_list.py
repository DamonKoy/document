import pytest
from data import common_data
from utils import common

_controller = 'region'


@pytest.fixture()
def get_new_banner_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_new_banner_list'),
        'subject_id': "6"
    }
    yield test_data
