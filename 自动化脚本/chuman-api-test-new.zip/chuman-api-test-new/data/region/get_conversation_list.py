import pytest
from data import common_data
from utils import common

_controller = 'region'


@pytest.fixture()
def get_conversation_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_conversation_list'),
        'from_id': "0",
        'region_type': "1",
    }
    yield test_data
