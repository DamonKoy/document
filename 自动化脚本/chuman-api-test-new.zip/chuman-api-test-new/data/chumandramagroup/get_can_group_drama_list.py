import pytest
from data import common_data
from utils import common

_controller = 'chumandramagroup'


@pytest.fixture()
def get_can_group_drama_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_can_group_drama_list'),
        'type': 0,
        'page': 1,
        'pagesize': 30,
    }
    yield test_data
