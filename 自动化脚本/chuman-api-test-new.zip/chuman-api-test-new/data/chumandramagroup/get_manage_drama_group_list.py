import pytest
from data import common_data
from utils import common

_controller = 'chumandramagroup'


@pytest.fixture()
def get_manage_drama_group_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_manage_drama_group_list'),
        'page': 1,
        'pagesize': 30,
        'type': 0,
    }
    yield test_data
