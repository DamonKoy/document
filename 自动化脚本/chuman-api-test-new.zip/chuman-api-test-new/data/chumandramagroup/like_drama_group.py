import pytest
from data import common_data
from utils import common
from api.app import chumandramagroup

_controller = 'chumandramagroup'


@pytest.fixture()
def like_drama_group_data():
    drama_group_list_data = {
        'page': 1,
        'pagesize': 50,
    }
    group_id = chumandramagroup.get_drama_contribute_list(common_data.main_user_id_session, request_info=drama_group_list_data).json()["data"]["list"][0]["group_id"]

    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'like_drama_group'),
        'group_id': group_id,
    }
    yield test_data
