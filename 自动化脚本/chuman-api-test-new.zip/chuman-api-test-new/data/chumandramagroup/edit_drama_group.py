import pytest
from data import common_data
from utils import common
from api.app import chumandramagroup

_controller = 'chumandramagroup'


@pytest.fixture()
def edit_drama_group_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'edit_drama_group'),
        'group_id': '',
        'title_image': 'app/cover/template/images/cover_template_33700837_419e02b4e81f4d3fbe6e5697d5061e8d.jpg',
        'title': 'test',
        'category': 'PY,love,campus',
        'desc': 'test',
        'club_id': '',
        'type': 0,
    }
    yield test_data


@pytest.fixture()
def del_drama_group_data():
    group_list_dat ={
        'page': 1,
        'pagesize': 30,
        'type': 0,
    }
    group_id = chumandramagroup.get_manage_drama_group_list(common_data.main_user_id_session, request_info=group_list_dat).json()["data"]["group_list"][0]["group_id"]

    test_data = {
        'session': common_data.main_user_id_session,
        'group_id': group_id,
    }
    yield test_data
