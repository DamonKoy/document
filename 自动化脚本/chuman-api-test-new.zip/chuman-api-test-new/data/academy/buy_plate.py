import pytest
from data import common_data
from utils import common

_controller = 'Academy'


@pytest.fixture()
def buy_plate_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'plate_id': 1212,
        'schema_file': common.get_schema_path(_controller, 'buy_plate')
    }
    yield test_data
