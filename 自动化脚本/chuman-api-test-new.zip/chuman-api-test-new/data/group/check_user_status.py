import pytest
from data import common_data
from utils import common

_controller = 'group'


@pytest.fixture()
def check_user_status_data():
    test_data = {
        'session': common_data.create_group_user_session,
        'schema_file': common.get_schema_path(_controller, 'check_user_status')
    }
    yield test_data
