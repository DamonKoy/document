import pytest
from data import common_data
from utils import common

_controller = 'group'


@pytest.fixture()
def disband_group_data():
    test_data = {
        'session': common_data.create_group_user_session,
        'schema_file': common.get_schema_path(_controller, 'disband_group')
    }
    yield test_data
