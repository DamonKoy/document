import pytest
from data import common_data
from utils import common
from api.app import group

_controller = 'group'


@pytest.fixture()
def get_group_second_theme_list_data():
    category_first = group.get_group_first_theme_list(common_data.create_group_user_session).json()['data']['list'][0][
        'id']
    test_data = {
        'session': common_data.create_group_user_session,
        'firstThemeId': category_first,
        'schema_file': common.get_schema_path(_controller, 'get_group_second_theme_list')
    }
    yield test_data
