import pytest
from data import common_data
from utils import common

_controller = 'group'


@pytest.fixture()
def get_post_privilege_data():
    test_data = {
        'session': common_data.create_group_user_session,
        'schema_file': common.get_schema_path(_controller, 'get_post_privilege')
    }
    yield test_data
