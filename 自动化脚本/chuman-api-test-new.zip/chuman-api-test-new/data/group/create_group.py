import pytest
from data import common_data
from utils import common
from api.app import group
from utils.common import gen_random_string

_controller = 'group'


@pytest.fixture()
def create_group_data():
    logo_url = 'app/users/club_title_image/createClubIcon_0_20200819142626.jpg'
    title = gen_random_string()
    intro = '大群组'
    category_first = group.get_group_first_theme_list(common_data.create_group_user_session).json()['data']['list'][0]['id']
    request_info = {'firstThemeId': category_first}
    category_second = group.get_group_second_theme_list(common_data.create_group_user_session, request_info).json()['data']['list'][0]['id']
    test_data = {
        'session': common_data.create_group_user_session,
        'logo_url': logo_url,
        'title': title,
        'intro': intro,
        'category_first': category_first,
        'category_second': category_second,
        'schema_file': common.get_schema_path(_controller, 'create_group')
    }
    yield test_data
