import pytest
from data import common_data
from utils import common

_controller = 'notification'


@pytest.fixture()
def CAL_notification_category_page_new_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'notification_category_page_new'),
        'type': 1,
        'last_id': '',
        'pagesize': 30,
    }
    yield test_data
