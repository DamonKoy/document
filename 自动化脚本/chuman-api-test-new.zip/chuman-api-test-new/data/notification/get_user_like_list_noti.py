import pytest
from data import common_data
from utils import common

_controller = 'notification'


@pytest.fixture()
def get_user_space_like_list_noti_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_user_like_list_noti'),
        'log_id': 49550409,
        'fold_type': 9,
        'page': 1,
        'pagesize': 50,
    }
    yield test_data
