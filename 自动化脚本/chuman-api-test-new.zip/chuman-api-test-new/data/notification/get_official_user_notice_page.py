import pytest
from data import common_data
from utils import common

_controller = 'notification'


@pytest.fixture()
def get_qianqian_user_notice_page_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_official_user_notice_page'),
        'official_user_id': 940005,
        'last_id': '',
        'pagesize': 30,
    }
    yield test_data
