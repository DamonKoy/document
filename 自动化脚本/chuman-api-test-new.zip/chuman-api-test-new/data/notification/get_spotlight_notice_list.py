import pytest
from data import common_data
from utils import common

_controller = 'notification'


@pytest.fixture()
def get_qianqian_new_spotlight_notice_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_spotlight_notice_list'),
        'column_id': 17,
        'page': 1,
        'pagesize': 50,
    }
    yield test_data
