import pytest
from data import common_data
from utils import common

_controller = 'userRealAuth'


@pytest.fixture()
def check_identity_valid_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'check_identity_valid')
    }
    yield test_data
