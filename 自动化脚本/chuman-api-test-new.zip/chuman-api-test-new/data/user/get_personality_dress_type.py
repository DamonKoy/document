import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def get_personality_dress_type_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_personality_dress_type')
    }
    yield test_data
