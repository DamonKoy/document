import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def get_bind_phone_status_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_bind_phone_status')
    }
    yield test_data
