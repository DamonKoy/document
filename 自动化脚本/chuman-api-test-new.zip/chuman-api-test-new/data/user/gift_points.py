import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def gift_points_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'schema_file': common.get_schema_path(_controller, 'gift_points'),
        'coins': 1, 'gems': 0, 'to_user': common_data.main_user_id
    }
    yield test_data
