import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def set_user_switch_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'set_user_switch'),
        'allow_chat_noti': 1, 'allow_getui': 1, 'allow_group_greet': 1,
        'allow_invite': 1, 'allow_user_greet': 1, 'allow_friend_phone': 1
    }
    yield test_data
