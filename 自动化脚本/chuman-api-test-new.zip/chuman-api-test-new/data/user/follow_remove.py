import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def follow_remove_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'follow_remove'),
        'following_id': common_data.money_not_enough_user_id,
        'version': '',
    }
    yield test_data
