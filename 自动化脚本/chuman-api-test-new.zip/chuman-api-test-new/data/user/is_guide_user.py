import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def is_guide_user_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'is_guide_user')
    }
    yield test_data
