import pytest
from data import common_data
from utils import common

_controller = 'user'


@pytest.fixture()
def get_subscribed_user_info_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_subscribed_user_info'),
        'user_id': common_data.money_enough_user_id
    }
    yield test_data
