import pytest
from data import common_data
from utils import common

_controller = 'propgiftpack'


@pytest.fixture()
def get_prop_giftpack_info_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_prop_giftpack_info'),
        'prop_giftpack_id': '172'
    }
    yield test_data
