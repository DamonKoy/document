import pytest
from data import common_data
from utils import common

_controller = 'spdiy'


@pytest.fixture()
def package_category_list_comic_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'package_category_list_comic'),
        'category': '1',
        'sex': '1',
        'res_id': '1',
    }
    yield test_data
