import pytest
from data import common_data
from utils import common

_control = 'spdiy'


@pytest.fixture()
def get_package_category_list_character_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_control, 'package_category_list_character'),
    }
    yield test_data
