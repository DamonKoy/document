import pytest
from data import common_data
from utils import common

_controller = 'spdiy'


@pytest.fixture()
def buy_package_set_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'schema_file': common.get_schema_path(_controller, 'buy_package_set'),
        'set_id': '',
        'version': '1',
        'coupon_token': ''
    }
    yield test_data
