import pytest
from data import common_data
from utils import common

_controller = 'spdiy'


@pytest.fixture()
def get_first_class_name_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_first_class_name')
    }
    yield test_data
