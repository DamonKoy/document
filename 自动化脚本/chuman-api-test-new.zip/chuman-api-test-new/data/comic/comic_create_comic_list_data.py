import pytest
from data import common_data
from utils import common

from api.app import comic

_control = "Comic"


@pytest.fixture()
def get_comic_create_comic_list_data():
    session = common_data.main_user_id_session
    comic_id = comic.comic_edit(session).json().get('data').get('data').get('comic_id')
    test_data = {
        "session": session,
        "schema_file": common.get_schema_path(_control, "comic_create_comic_list")
                 }
    yield test_data
    comic.comic_del(session, comic_id)