import pytest
from data import common_data
from utils import common

_control = "Comic"


@pytest.fixture()
def get_share_config_data():
    test_data = {
        "session": common_data.main_user_id_session,
        "schema_file": common.get_schema_path(_control, "share_config")
                 }
    yield test_data