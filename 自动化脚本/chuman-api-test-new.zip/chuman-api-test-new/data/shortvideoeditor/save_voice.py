import pytest
from data import common_data
from utils import common

_controller = 'shortvideoeditor'


@pytest.fixture()
def save_voice_data():
    upload_json = [{"song_name": "aaaa", "song_time": 30, "cover": "aaaa", "song_url": "aaaa"}]
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'save_voice'),
        'upload_json': upload_json
    }
    yield test_data
