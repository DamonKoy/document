import pytest
from data import common_data
from utils import common

_controller = 'contentreview'

@pytest.fixture()
def check_code_info_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'check_code_info'),
        'content': 'WIFI:T:WPA;P:ub5zqxvm;S:MY;',
        'user_id': common_data.main_user_id,
    }
    yield test_data
