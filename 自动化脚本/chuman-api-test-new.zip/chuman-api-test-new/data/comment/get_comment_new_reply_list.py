import pytest
from data import common_data
from utils import common
from api.app import comic
from api.app import comment

_controller = 'comment'


@pytest.fixture()
def get_comment_new_reply_list_data():
    # comic_id = comic.comic_create_comic_list(common_data.main_user_id_session).json()['data']['list'][0]['comic_id']
    # comment_id = comment.get_new_comment_list(common_data.main_user_id_session, {'obj_id': comic_id, 'comment_type': 2}).json()['data']['list'][0]['comment_id']
    session = common_data.main_user_id_session
    comic_id = comic.comic_edit(common_data.main_user_id_session).json().get('data').get('data').get('comic_id')
    request_info = {
        'comment_type': 2,
        'comment_obj_id': comic_id,
        'message': 'testing'
    }
    comment_id = comment.add_comment(session, request_info=request_info).json().get('data').get('comment_id')
    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'get_comment_new_reply_list'),
        'comment_type': 2,
        'comment_id': comment_id,
    }
    yield test_data
    comic.comic_del(session, comic_id)
