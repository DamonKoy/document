import pytest
from data import common_data
from utils import common

_control = "ComicCreate"


@pytest.fixture()
def get_check_user_reward_data():
    test_data = {
        "session": common_data.main_user_id_session,
        "schema_file": common.get_schema_path(_control, "check_user_reward")
                 }
    yield test_data
