import pytest
from data import common_data
from utils import common

_control = "CoverEditor"


@pytest.fixture()
def get_buy_cover_resource_data():
    test_data = {
        "session": common_data.main_user_id_session,
        "schema_file": common.get_schema_path(_control, "buy_cover_resource")
                 }
    yield test_data
