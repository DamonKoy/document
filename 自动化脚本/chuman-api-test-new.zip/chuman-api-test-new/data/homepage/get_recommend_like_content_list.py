import pytest
from data import common_data
from utils import common

_controller = 'homepage'


@pytest.fixture()
def get_recommend_like_content_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'scene_id': 1001001002,
        'schema_file': common.get_schema_path(_controller, 'get_recommend_like_content_list')
    }
    yield test_data
