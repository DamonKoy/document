import pytest
from data import common_data
from utils import common

_controller = 'radiomatching'


@pytest.fixture()
def start_couple_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'start_couple'),
        'sex': 2,
        'scene_id': 1002002003002,
    }
    yield test_data
