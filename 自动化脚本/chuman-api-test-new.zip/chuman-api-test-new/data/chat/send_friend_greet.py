import pytest
from data import common_data
from utils import common

_controller = 'chat'


@pytest.fixture()
def send_friend_greet_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'send_friend_greet'),
        'receiver_id': common_data.money_enough_user_id,
        'message': 'hi',
        'greet_type': '1'
    }
    yield test_data
