import pytest
from data import common_data
from utils import common
from utils.common import gen_random_string

_controller = 'customroles'


data = [
    {"avatar": "app/users/web_default/web_default_user_id_18138722_dabe1db9d12247247c00162811f0a4cc.jpg",
     "name": gen_random_string(),
     "sex": 1},
    {"avatar": "app/users/web_default/web_default_user_id_18138722_dabe1db9d12247247c00162811f0a4cc.jpg",
     "name": gen_random_string(),
     "sex": 2}
]

@pytest.fixture()
def add_custom_role_data(request):
    param = request.param
    test_data = {
        'avatar': param['avatar'],
        'name': param['name'],
        'sex': param['sex'],
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'add_custom_role')
    }
    yield test_data
