from api.app import customroles
from data.customroles.get_custom_role_list import *

_controller = 'customroles'


@pytest.fixture()
def delete_custom_role_data(get_custom_role_list_data):
    test_data = {
        'session': common_data.main_user_id_session,
        'ids': customroles.get_custom_role_list(common_data.main_user_id_session, request_info=get_custom_role_list_data).json()['data']['list'][0][
                'character_id'],
        'schema_file': common.get_schema_path(_controller, 'delete_custom_role')
    }
    yield test_data
