import pytest
from data import common_data
from utils import common

_controller = 'customroles'


@pytest.fixture()
def get_custom_role_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_custom_role_list')
    }
    yield test_data
