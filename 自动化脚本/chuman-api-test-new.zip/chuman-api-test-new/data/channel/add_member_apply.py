import pytest

from data import common_data
from utils import common
from api.app import channel

_controller = 'channel'


@pytest.fixture(params=[
    {
        'case_id': 1,
        'case_name': '申请加入频道失败-不带必填参数channel_id',
        'channel_id': None ,
        'content': '111'
    },
    {
        'case_id': 2,
        'case_name': '申请加入频道失败-必填参数channel_id为空',
        'channel_id': '',
        'content': 111
    },
    {
        'case_id': 3,
        'case_name': '申请加入频道失败-必填参数channel_id不存在',
        'channel_id': 0,
        'content': 111
    }
])
def add_member_apply_fail_data(request):
    test_data = {
        'session': common_data.main_user_id_session,
        'channel_id': request.param['channel_id'],
        'content': request.param['content'],
    }
    yield test_data


@pytest.fixture(params=[
    {
        'case_id': 5,
        'case_name': '申请加入频道成功-不带非必填参数content',
        'channel_id': 111,
        'content': None,
        'asserts': {
            'status': 'ok',
            'data.result': True
        }
    },
    {
        'case_id': 6,
        'case_name': '申请加入频道成功-带非必填参数content',
        'channel_id': 111,
        'content': 111,
        'asserts': {
            'status': 'ok',
            'data.result': True
        }
    }
])
def add_member_apply_success_data(request):
    test_data = {
        'session': common_data.main_user_id_session,
        'channel_id': common_data.channel_user_channel_id,
        'content': request.param['content'],
        'schema_file': common.get_schema_path(_controller, 'add_member_apply'),
        'asserts': request.param['asserts']
    }
    yield test_data
    res = channel.get_member_apply_list(common_data.channel_user_session,
                                        request_info={'channel_id': common_data.channel_user_channel_id}).json()
    apply_id = ''
    for item in res.get('data').get('list'):
        if item['user_info']['user_id'] == int(common_data.main_user_id):
            apply_id = item['apply_id']
            break
    channel.reject_member_apply(common_data.channel_user_session, request_info={'apply_id': apply_id})
