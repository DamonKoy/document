import pytest
from data import common_data
from utils import common


_controller = 'actiontemplate'


@pytest.fixture()
def get_space_package_list_with_resid():
    test_data = {
        'session': common_data.main_user_id_session,
        'res_ids': "44695,44637,32,44456,44696,44636",
        'schemas_file': common.get_schema_path(_controller, 'get_space_package_list')
    }
    yield test_data


@pytest.fixture()
def get_space_package_list_without_resid():
    test_data = {
        'session': common_data.main_user_id_session,
        'res_ids': '',
    }
    yield test_data