import pytest
from data import common_data
from utils import common

_control = "ComicTemplate"


@pytest.fixture()
def get_template_list_data():
    test_data = {
        "session": common_data.main_user_id_session,
        "schema_file": common.get_schema_path(_control, "get_template_list")
                 }
    yield test_data
