import pytest
from data import common_data
from utils import common

_controller = 'chumandrama'
group_id = 1179518


@pytest.fixture()
def get_last_role_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'group_id': 1179518,
        'schema_file': common.get_schema_path(_controller, 'get_last_role_list')
    }
    yield test_data
