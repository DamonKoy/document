import pytest
from data import common_data
from utils import common

_controller = 'chumandrama'
group_id = 1179518

@pytest.fixture()
def share_drama_group_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'group_id': group_id,
        'schema_file': common.get_schema_path(_controller, 'share_drama_group')
    }
    yield test_data
