import pytest
from data import common_data
from utils import common
import os

_controller = 'chumandrama'

main_user_id = os.getenv('main_user_id')
guest_user_id = os.getenv('guest_user_id')
money_enough_user_id = os.getenv('money_enough_user_id')

group_id = 1179518
drama_id = 9445717
has_like_drama_id = 9225708
role_id = 60344018
page = 1
pagesize = 30

is_view = 1


@pytest.fixture()
def get_content_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'drama_id': drama_id,
        'is_view': is_view,
        'schema_file': common.get_schema_path(_controller, 'get_content_list')
    }
    yield test_data
