import pytest
from data import common_data
from utils import common

_controller = 'chumandrama'
drama_id = 9445717

@pytest.fixture()
def get_drama_base_info_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'drama_id': drama_id,
        'schema_file': common.get_schema_path(_controller, 'get_drama_base_info')
    }
    yield test_data
