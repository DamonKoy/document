import pytest
import os
from data import common_data
from utils import common

_controller = 'chumandrama'
money_enough_user_id = os.getenv('money_enough_user_id')


@pytest.fixture()
def user_follow_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'user_id': money_enough_user_id,
        'schema_file': common.get_schema_path(_controller, 'user_follow')
    }
    yield test_data
