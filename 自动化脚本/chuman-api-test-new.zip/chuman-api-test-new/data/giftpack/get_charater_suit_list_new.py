import pytest
from data import common_data
from utils import common

_controller = 'giftpack'


@pytest.fixture()
def get_charater_suit_list_new_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_charater_suit_list_new')
    }
    yield test_data
