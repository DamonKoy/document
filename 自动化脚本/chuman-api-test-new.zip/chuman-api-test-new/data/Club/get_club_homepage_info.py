import os

import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = common.extract_value_by_expr('id', club.checkUserClub(session).json())


@pytest.fixture(params=[
    {
        'case_name': '用户已加入社团时，获取广场-社团信息',
        'club_id': 3000303
    },
    {
        'case_name': '用户没有加入社团时，获取广场-社团信息',
        'club_id': ''
    }
])
def get_club_homepage_info_data(request):
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_club_homepage_info'),
        'case_name': request.param['case_name'],
        'club_id': request.param['club_id'],
        'page': None,
        'pagesize': None
    }
    yield test_data

