import pytest
from data import common_data
from utils import common
from utils.common import *
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = extract_value_by_expr('data.clubInfo.id', club.checkUserClub(session).json())
member_id = os.getenv('main_user_id')


@pytest.fixture()
def save_club_position_name_data():
    custom_name_json = [{"club_position_custom_name": "宣传委员",
                         "club_position_id": "5", "club_position_name": "宣传委员"},
                        {"club_position_custom_name": "管理员11", "club_position_id": "4", "club_position_name": "管理员"},
                        {"club_position_custom_name": "普通成员", "club_position_id": "3", "club_position_name": "普通成员"},
                        {"club_position_custom_name": "管理员队长", "club_position_id": "2", "club_position_name": "管理员队长"},
                        {"club_position_custom_name": "社长", "club_position_id": "1", "club_position_name": "社长"}]
    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'save_club_position_name'),
        'club_id': club_id,
        'custom_name_json': custom_name_json
    }
    yield test_data

