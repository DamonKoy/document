import pytest
from data import common_data
from utils import common
from utils.common import *
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = common.extract_value_by_expr('id', club.checkUserClub(session).json())


@pytest.fixture()
def is_club_banned_data():

    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'is_club_banned'),
        'club_id': club_id
    }
    yield test_data

