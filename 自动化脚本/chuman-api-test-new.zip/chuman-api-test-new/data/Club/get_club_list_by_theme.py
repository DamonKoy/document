import pytest
from data import common_data
from utils.common import *
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = extract_value_by_expr('id', club.checkUserClub(session).json())


@pytest.fixture()
def get_club_list_by_theme_data():
    theme_first_id = club.get_club_theme_first_list(session).json()["data"]["list"][0]["theme_first_id"]
    theme_second_id = club.get_club_theme_second_list(session, request_info={'theme_first_id': theme_first_id}).json()["data"]["list"][0]["theme_second_id"]
    test_data = {
        'session': session,
        'schema_file': get_schema_path(_controller, 'get_club_theme_second_list'),
        'theme_first_id': theme_first_id,
        'theme_second_id': theme_second_id,
        'page': 1,
        'pagesize': 10

    }
    yield test_data

