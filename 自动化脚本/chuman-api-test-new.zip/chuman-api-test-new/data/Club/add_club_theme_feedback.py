import os

import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = club.checkUserClub(session).json()['data']['clubInfo']['id']
# club_id = 3000303


@pytest.fixture()
def add_club_theme_feedback_data():

    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'add_club_theme_feedback'),
        'title': 'test'
    }
    yield test_data

