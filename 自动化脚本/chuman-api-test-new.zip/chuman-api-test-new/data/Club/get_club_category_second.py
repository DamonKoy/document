import os

import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
data = None
club_id = common.extract_value_by_expr('id', club.checkUserClub(session).json())


@pytest.fixture()
def get_club_category_second_data():
    theme_first_id = club.get_club_category_first(session, request_info=data).json()['data']['list'][0][
        'theme_first_id']

    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'get_club_category_second'),
        'theme_first_id': theme_first_id
    }
    yield test_data

