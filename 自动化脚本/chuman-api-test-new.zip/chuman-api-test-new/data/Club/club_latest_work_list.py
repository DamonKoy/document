import pytest
from data import common_data
from utils import common
from utils.common import *
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session

club_id = extract_value_by_expr('data.clubInfo.id', club.checkUserClub(session).json())



@pytest.fixture()
def club_latest_work_list_data():

    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'club_latest_work_list'),
        'club_id': club_id
    }
    yield test_data

