import os

import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'Club'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Club/'
session = common_data.main_user_id_session
club_id = common.extract_value_by_expr('id', club.checkUserClub(session).json())

@pytest.fixture()
def getClubNoticeUnreadNum_data():

    test_data = {
        'session': session,
        'schema_file': common.get_schema_path(_controller, 'getClubNoticeUnreadNum')
    }
    yield test_data

