import pytest
from data import common_data
from utils import common

_controller = 'app'


@pytest.fixture()
def check_content_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'check_content'),
        'content': '大笑哈哈哈'
    }
    yield test_data
