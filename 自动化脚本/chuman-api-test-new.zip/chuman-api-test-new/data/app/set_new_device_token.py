import pytest
from data import common_data
from utils import common

_controller = 'app'


@pytest.fixture()
def set_new_device_token_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'set_new_device_token'),
        'app_device_id': None,
        'dreampix_device_id': None
    }
    yield test_data
