import pytest
from data import common_data
from utils import common

_controller = 'app'


@pytest.fixture()
def qiniu_private_url_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'qiniu_private_url'),
        'fileName': 1
    }
    yield test_data
