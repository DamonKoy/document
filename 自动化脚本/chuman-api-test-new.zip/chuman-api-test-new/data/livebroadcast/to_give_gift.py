import pytest

from data import common_data
from utils import common
from utils.service import start_broadcasting, stop_broadcasting


_controller = 'livebroadcast'


@pytest.fixture()
def give_blue_diamond_gift_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
        'gift_id': 1,
        'gift_num': 1,
        'schema_file': common.get_schema_path(_controller, 'to_give_gift')
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture()
def give_gift_without_gift_id_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
        'gift_num': 1,
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture()
def give_gift_without_gift_num_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
        'gift_id': 1,
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture()
def give_gift_without_live_id_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': "",
        'gift_id': 1,
        'gift_num': 1,
    }
    yield test_data



@pytest.fixture()
def give_gift_without_money_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_not_enough_user_session,
        'live_id': live_id,
        'gift_id': 1,
        'gift_num': 1,
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture(params=[
    {
        'case_name': '赠送连击钻石礼物',
        'live_id': "",
        'gift_id': 119,
        'gift_num': 2,
    },
    {
        'case_name': '赠送非连击钻石礼物',
        'live_id': "",
        'gift_id': 119,
        'gift_num': 1,
    }
])
def give_different_gift_data(request):
    live_id = start_broadcasting()

    test_data = {
        'session': common_data.money_enough_user_session,
        'gift_id': request.param['gift_id'],
        'gift_num': request.param['gift_num'],
        'live_id': live_id,
        # 'asserts': request.param['asserts']
    }
    yield test_data
    stop_broadcasting(live_id)



