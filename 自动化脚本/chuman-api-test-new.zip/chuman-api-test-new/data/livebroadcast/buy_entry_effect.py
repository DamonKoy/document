import pytest

from data import common_data

_controller = 'livebroadcast'


@pytest.fixture()
def buy_entry_effect_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'obj_id': "6",
    }
    yield test_data


@pytest.fixture()
def buy_entry_effect_data_without_id():
    test_data = {
        'session': common_data.money_enough_user_session,
        'obj_id': "",
    }
    yield test_data
