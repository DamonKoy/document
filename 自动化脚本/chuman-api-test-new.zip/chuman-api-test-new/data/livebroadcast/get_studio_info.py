import pytest
from data import common_data
from utils.service import start_broadcasting, stop_broadcasting
from utils import common

_controller = 'livebroadcast'


@pytest.fixture()
def get_studio_info_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
        'c_type': 1,
        'schema_file': common.get_schema_path(_controller, 'get_studio_info')
    }
    yield test_data

    stop_broadcasting(live_id)


