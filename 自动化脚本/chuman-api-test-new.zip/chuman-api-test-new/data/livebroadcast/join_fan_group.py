import os
from utils import common
import pytest
from data import common_data

_controller = 'livebroadcast'


@pytest.fixture()
def join_fan_group_week_data():
    anchor_id = os.getenv('live_broadcast_user_id')
    test_data = {
        'session': common_data.money_enough_user_session,
        'fee_type': '1',
        'anchor_id': anchor_id,
        'schema_file': common.get_schema_path(_controller, 'join_fan_group')
    }
    yield test_data


@pytest.fixture()
def join_fan_group_month_data():
    anchor_id = os.getenv('live_broadcast_user_id')
    test_data = {
        'session': common_data.money_enough_user_session,
        'fee_type': '2',
        'anchor_id': anchor_id,
        # 'schema_file': common.get_schema_path(__controller, 'add_member_apply')
    }
    yield test_data


@pytest.fixture()
def join_fan_group_without_fee_type():
    anchor_id = os.getenv('live_broadcast_user_id')
    test_data = {
        'session': common_data.money_enough_user_session,
        'fee_type': '',
        'anchor_id': anchor_id,
        # 'schema_file': common.get_schema_path(__controller, 'add_member_apply')
    }
    yield test_data


@pytest.fixture()
def join_fan_group_without_anchor_id():
    anchor_id = os.getenv('live_broadcast_user_id')
    test_data = {
        'session': common_data.money_enough_user_session,
        'fee_type': '2',
        'anchor_id': "",
        # 'schema_file': common.get_schema_path(__controller, 'add_member_apply')
    }
    yield test_data