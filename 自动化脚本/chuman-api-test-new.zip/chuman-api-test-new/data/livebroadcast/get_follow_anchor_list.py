import pytest
from data import common_data
from utils import common

_controller = 'livebroadcast'


@pytest.fixture()
def get_follow_anchor_list_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'schema_file': common.get_schema_path(_controller, 'get_follow_anchor_list')
    }
    yield test_data



