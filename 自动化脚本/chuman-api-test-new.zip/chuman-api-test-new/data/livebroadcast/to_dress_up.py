import pytest

from data import common_data
from utils import common
from utils.service import start_broadcasting, stop_broadcasting

_controller = 'livebroadcast'

@pytest.fixture()
def to_dress_up_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.live_broadcast_user_session,
        'live_id': live_id,
        'json_data': '[{"img":"spdiy/cloth/1508465655000904.png","rid":"5494","cid":"4","sp":2,"d":10,"w":200.0,"h":294.0,"x":147.0,"y":120.0},{"img":"spdiy/cloth/1508465708000981.png","rid":"5495","cid":"4","sp":1,"d":10,"w":69.0,"h":89.0,"x":225.0,"y":122.0}]',
        'schema_file': common.get_schema_path(_controller, 'to_dress_up'),
    }
    yield test_data

    stop_broadcasting(live_id)
