import pytest
from data import common_data
from utils import common
from utils.service import start_broadcasting, stop_broadcasting


_controller = 'livebroadcast'


@pytest.fixture()
def get_setup_user_list_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_setup_user_list'),
        'live_id': live_id,
    }
    yield test_data

    stop_broadcasting(live_id)
