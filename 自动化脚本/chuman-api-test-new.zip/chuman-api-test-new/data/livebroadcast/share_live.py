import pytest
from data import common_data
from utils.service import start_broadcasting, stop_broadcasting


_controller = 'livebroadcast'


@pytest.fixture()
def share_live_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture()
def share_live_without_live_id_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': "",
    }
    yield test_data

