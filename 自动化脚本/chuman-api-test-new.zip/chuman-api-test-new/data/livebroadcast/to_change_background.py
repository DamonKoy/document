import pytest

from data import common_data
from utils import common
from utils.service import start_broadcasting, stop_broadcasting

_controller = 'livebroadcast'


@pytest.fixture()
def to_change_background_data():
    live_id = start_broadcasting()
    data = {
        'session': common_data.live_broadcast_user_session,
        'live_id': live_id,
        'material_type': 1,
        'material_id': 99,
        'schema_file': common.get_schema_path(_controller, 'to_change_background')
    }
    yield data

    stop_broadcasting(live_id)


@pytest.fixture()
def change_effect_data():
    live_id = start_broadcasting()
    data = {
        'session': common_data.live_broadcast_user_session,
        'live_id': live_id,
        'material_type': 2,
        'material_id': 12,
    }
    yield data

    stop_broadcasting(live_id)


@pytest.fixture()
def anzhuo_cancel_effect_data():
    live_id = start_broadcasting()
    data = {
        'session': common_data.live_broadcast_user_session,
        'live_id': live_id,
        'material_type': 2,
        'material_id': -1,
    }
    yield data

    stop_broadcasting(live_id)