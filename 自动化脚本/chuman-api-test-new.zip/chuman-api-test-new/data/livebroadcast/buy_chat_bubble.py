import pytest

from data import common_data

_controller = 'livebroadcast'


@pytest.fixture()
def buy_chat_bubble_data():
    test_data = {
        'session': common_data.money_not_enough_user_session,
        'obj_id': '51'
    }
    yield test_data


@pytest.fixture()
def buy_chat_bubble_data_without_id_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'obj_id': ''
    }
    yield test_data