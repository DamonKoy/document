import pytest
from data import common_data
from utils import common
from utils.service import start_broadcasting, stop_broadcasting


_controller = 'livebroadcast'


@pytest.fixture()
def edit_placard_info_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'edit_placard_info'),
        'live_id': live_id,
        'studio_placard': 'api-auto-test'
    }
    yield test_data

    stop_broadcasting(live_id)
