import pytest
from data import common_data
from utils.service import start_broadcasting, stop_broadcasting
from utils import common

__controller = 'livebroadcast'


@pytest.fixture()
def to_follow_anchor_data():
    live_id = start_broadcasting()
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': live_id,
        'schema_file': common.get_schema_path(__controller, 'to_follow_anchor')
    }
    yield test_data

    stop_broadcasting(live_id)


@pytest.fixture()
def to_follow_anchor_without_live_id_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'live_id': "",
        'schema_file': common.get_schema_path(__controller, 'to_follow_anchor')
    }
    yield test_data

