import pytest
from data import common_data
from utils import common
from api.app import video

_controller = 'video'


@pytest.fixture()
def publish_video_data():
    second_category_id_data = {
        "first_category_id": video.get_first_category_list(common_data.main_user_id_session).json()["data"]["list"][0]["id"]
    }

    tag_lsit_data = {
        'second_category_id': video.get_second_category_list(common_data.main_user_id_session, request_info=second_category_id_data).json()["data"]["list"][0]["id"],
        'page': 1,
        'pagesize': 10,
    }

    classification = str(video.get_tag_list(common_data.main_user_id_session, request_info=tag_lsit_data).json()["data"]["list"][0]["id"])

    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'publish_video'),
        'describe': '测试上传，审核后台可不处理',
        'classification': classification,
        'source': 1,
        'video_url': 'app/short/video/short_video_40206216_9bf8332efa0c801640421d54d4114dd1.mov',
        'cover': 'app/short/video/titles/short_video_title_40206216_40A7C94B-7829-40A0-8AD7-1C49D577B994.jpg',
        'duration': 6,
        'width': 540,
        'height': 720,
    }
    yield test_data
