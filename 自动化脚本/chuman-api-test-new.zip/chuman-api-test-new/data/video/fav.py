import pytest
from data import common_data
from utils import common
from api.app import video

_controller = 'video'


@pytest.fixture()
def fav_data():
    video_lsit_data = {
        'scene_id': 1001005001,
        'page': 0,
        'pagesize': 50,
    }
    video_id = video.get_recommend_short_video_list(common_data.main_user_id_session, request_info=video_lsit_data).json()['data']['list'][0]['video_id']

    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'fav'),
        'video_id': video_id,
        'action': 1,
    }
    yield test_data
