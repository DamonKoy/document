import pytest
from data import common_data
from utils import common
from api.app import video

_controller = 'video'

@pytest.fixture()
def get_second_category_list_data():
    first_category_id = video.get_first_category_list(common_data.main_user_id_session).json()["data"]["list"][0]["id"]

    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_second_category_list'),
        'first_category_id': first_category_id,
    }
    yield test_data
