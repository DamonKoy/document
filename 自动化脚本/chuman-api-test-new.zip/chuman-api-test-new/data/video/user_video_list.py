import pytest
from data import common_data
from utils import common

_controller = 'video'


@pytest.fixture()
def user_video_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'user_video_list'),
        'type': 2,
        'user_id': 34353886,
        'page': 1,
        'pagesize': 50,
    }
    yield test_data
