import pytest
from data import common_data
from utils import common

from api.app import chumandramagroup

_controller = 'creation'


@pytest.fixture()
def get_drama_group_info_data():
    session = common_data.main_user_id_session
    request_info = {
        'title': 'Test',
        'category': 'PY',
        'type': 0
    }
    group_id = chumandramagroup.edit_drama_group(session, request_info=request_info).json().get('data').get('group_id')
    test_data = {
        'session': common_data.main_user_id_session,
        'group_id': group_id,
        'schema_file': common.get_schema_path(_controller, 'get_drama_group_info')
    }
    yield test_data
    chumandramagroup.del_drama_group(session, request_info={'group_id': group_id})
