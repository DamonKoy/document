import pytest
from data import common_data
from utils import common

_controller = 'creation'


@pytest.fixture()
def get_creation_notice_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_creation_notice')
    }
    yield test_data
