import os
from utils.log import logger

from utils.service import get_user_session

env = os.getenv('env')


main_user_id = os.getenv('main_user_id')
main_user_id_session = get_user_session(main_user_id, env)
money_enough_user_id = os.getenv('money_enough_user_id')
money_enough_user_session = get_user_session(money_enough_user_id, env)
money_not_enough_user_id = os.getenv('money_not_enough_user_id')
money_not_enough_user_session = get_user_session(money_not_enough_user_id, env)
live_broadcast_user_id = os.getenv('live_broadcast_user_id')
live_broadcast_user_session = get_user_session(live_broadcast_user_id, env)
create_group_user_id = os.getenv('create_group_user_id')
create_group_user_session = get_user_session(create_group_user_id, env)
channel_user_id = os.getenv('channel_user_id')
channel_user_session = get_user_session(channel_user_id, env)
channel_user_channel_id = os.getenv('channel_user_channel_id')
club_user_id = os.getenv('club_user_id')
club_user_session = get_user_session(club_user_id, env)
club_user_club_id = os.getenv('club_user_club_id')
