import pytest
from api.app import refund
from data import common_data
from utils import common

_controller = 'refund'


@pytest.fixture()
def update_refund_data():

    test_data = {
        'session': common_data.main_user_id_session,
        'refund_no': refund.refund_detail(common_data.main_user_id_session).json()['data']['refund_no'],
        'type': 1,
        'schema_file': common.get_schema_path(_controller, 'update_refund')
    }
    yield test_data
