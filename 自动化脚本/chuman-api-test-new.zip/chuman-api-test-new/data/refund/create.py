import pytest
from data import common_data
from utils import common

_controller = 'refund'
user_name = 'test_name'
user_telephone = 19929778902
id_card_front = 'web_refund_idCard/web_default_user_id_18138722_7476a51398715d28784b70d6f8260235.jpg'
id_card_back = 'web_refund_idCard/web_default_user_id_18138722_7476a51398715d28784b70d6f8260235.jpg'
book_main_pic = 'web_refund_idCard/web_default_user_id_18138722_7476a51398715d28784b70d6f8260235.jpg'
book_guarder_pic = 'web_refund_idCard/web_default_user_id_18138722_7476a51398715d28784b70d6f8260235.jpg'
book_child_pic = 'web_refund_idCard/web_default_user_id_18138722_7476a51398715d28784b70d6f8260235.jpg'
refund_type = 1
ali_account = 13929448902
ali_real_name = 192938495050
bank_name = '中国建设银行'
bank_card_no = None
bank_real_name = None
user_email = '373758489@qq.com'
user_phone = None
id_card_no = 4409020099404262048


@pytest.fixture()
def create_data():

    test_data = {
        'session': common_data.main_user_id_session,
        'user_name': user_name,
        'user_telephone': user_telephone,
        'id_card_front': id_card_front,
        'id_card_back': id_card_back,
        'book_main_pic': book_main_pic,
        'book_guarder_pic': book_guarder_pic,
        'book_child_pic': book_child_pic,
        'refund_type': refund_type,
        'ali_account': ali_account,
        'ali_real_name': ali_real_name,
        'bank_name': bank_name,
        'user_email': user_email,
        'id_card_no': id_card_no,
        'bank_card_no': bank_card_no,
        'bank_real_name': bank_real_name,
        'user_phone': user_phone,
        'schema_file': common.get_schema_path(_controller, 'create')
    }
    yield test_data
