import pytest

from data import common_data
from utils import common


_controller = 'bigmember'


@pytest.fixture()
def open_vip_alert_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'open_vip_alert')

    }
    yield test_data


