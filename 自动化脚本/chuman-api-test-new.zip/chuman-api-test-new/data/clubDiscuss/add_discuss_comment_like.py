import pytest
from data import common_data
from utils import common
from api.app import clubDiscuss, club

_controller = 'clubDiscuss'
club_id = club.checkUserClub(common_data.main_user_id_session).json()['data']['clubInfo']['id']
discuss_id = clubDiscuss.get_club_discuss_list(common_data.main_user_id_session, {'club_id': club_id, 'type': 1}).json()['data']['discuss'][0][
        'discuss_id']
comment_id = clubDiscuss.add_discuss_comment(common_data.main_user_id_session, {'club_id': club_id, 'discuss_id': discuss_id, 'message': 'test'}).json()['data']['comment']['comment_id']

@pytest.fixture()
def add_discuss_comment_like_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'comment_id': comment_id,
        'club_id': club_id,
        'discuss_id': discuss_id,
        'schema_file': common.get_schema_path(_controller, 'add_discuss_comment_like')
    }
    yield test_data
