import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'clubDiscuss'
club_id = club.checkUserClub(common_data.main_user_id_session).json()['data']['clubInfo']['id']


@pytest.fixture()
def get_discussion_at_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'type': 1,
        'club_id': club_id,
        'schema_file': common.get_schema_path(_controller, 'get_discussion_at_list')
    }
    yield test_data
