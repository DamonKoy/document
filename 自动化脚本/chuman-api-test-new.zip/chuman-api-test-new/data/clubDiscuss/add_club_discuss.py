import pytest
from data import common_data
from utils import common
from api.app import club

_controller = 'clubDiscuss'
club_id = club.checkUserClub(common_data.main_user_id_session).json()['data']['clubInfo']['id']
title = common.gen_random_string()
instructions = common.gen_random_string()
is_extern = 0


@pytest.fixture()
def add_club_discuss_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'club_id': club_id,
        'title': title,
        'instructions': instructions,
        'is_extern': is_extern,
        'schema_file': common.get_schema_path(_controller, 'add_club_discuss')
    }
    yield test_data
