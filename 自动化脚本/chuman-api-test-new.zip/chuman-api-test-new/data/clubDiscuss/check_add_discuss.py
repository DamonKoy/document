import pytest
from data import common_data
from utils import common

_controller = 'clubDiscuss'


@pytest.fixture()
def check_add_discuss_data():
    test_data = {
        'session': common_data.club_user_session,
        'club_id': common_data.club_user_club_id,
        'schema_file': common.get_schema_path(_controller, 'check_add_discuss')
    }
    yield test_data
