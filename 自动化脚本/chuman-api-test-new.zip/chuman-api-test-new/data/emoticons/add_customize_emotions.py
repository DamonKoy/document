import pytest
from data import common_data
from utils import common

_controller = 'emoticons'

emoticons_url = 'app/users/im/emotions/pic_49550409_0cc65377fa1534548ccbcc0cb9c7c3c9.jpg'

data = [
    {'emoticons_url': emoticons_url, 'width': 256, 'height': 256, 'source': 1}
]

@pytest.fixture()
def add_customize_emotions_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'emoticons_url': "http://qnc-lb.chumanapp.com/app/users/pic/pic_15833787_9021c03e509c16116febaebb6bf9a1b9.png",
        'width': "1160",
        'height': "2600",
        'source': 4,
        'schema_file': common.get_schema_path(_controller, 'add_customize_emotions')
    }
    yield test_data
