import pytest
import os
from data import common_data
from utils import common

_controller = 'emoticons'


@pytest.fixture()
def delete_customize_emotions_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'id': os.getenv('emoticons_id'),
        'schema_file': common.get_schema_path(_controller, 'delete_customize_emotions')
    }
    yield test_data
