import pytest
from data import common_data
from utils import common
import os

_controller = 'homepageSlice'
first_theme_id = os.getenv('first_theme_id')


@pytest.fixture()
def get_recommend_club_list_by_theme_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'first_theme_id': 4,
        'page': 1,
        'pagesize': 30,
        'schema_file': common.get_schema_path(_controller, 'get_recommend_club_list_by_theme')
    }
    yield test_data
