import pytest
from data import common_data
from utils import common
from api.app import post

_controller = 'Post'

post_json_schema = 'json_schema/Post/'
club_id = 3000303


@pytest.fixture()
def get_subscribed_post_list_data():
    add_post_request_info = {
        'owner_type': 1,
        'owner_id': club_id,
        'type': 1,
        'title': 'test_title',
        'content': 'test_content'
    }
    session = common_data.main_user_id_session
    post_id = post.add_post(session, request_info=add_post_request_info).json()['data']['post_id']
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_subscribed_post_list'),
        'post_id': post_id,
        'region_id': club_id,
        'scene_id': None
    }

    yield test_data
    del_post_request_info = {
        'post_id': post_id,
        'type': 1
    }
    post.del_post(session, del_post_request_info)
