import os

import pytest
from data import common_data
from utils import common
from api.app import post

_controller = 'Post'
main_user_id = os.getenv('main_user_id')

post_json_schema = 'json_schema/Post/'
club_id = 3000303
title = 'test-title'
content = 'test-content'
page = 1
pagesize = 30
owner_type = 1
type = 1

# add_post_schema = post_json_schema + 'add_post.json'


@pytest.fixture()
def add_post_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'add_post'),
        'owner_type': owner_type,
        'owner_id': club_id,
        'type': 1,
        'title': title,
        'content': content,
        'post_id': None
    }
    yield test_data
    post_id = test_data['post_id']
    data = {'post_id': post_id, 'type': 1, 'reason': ''}
    post.del_post(common_data.main_user_id_session, request_info=data)

