import pytest
from data import common_data
from utils import common

_controller = 'adventuregame'


@pytest.fixture()
def give_single_gift_data():
    test_data = {
        'session': common_data.money_enough_user_session,
        'schema_file': common.get_schema_path(_controller, 'give_single_gift')
    }
    yield test_data
