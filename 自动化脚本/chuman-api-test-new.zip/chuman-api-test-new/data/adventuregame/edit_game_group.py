import pytest

from data import common_data
from utils import common
from api.app import adventuregame

_controller = 'adventuregame'


@pytest.fixture()
def edit_game_group_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'edit_game_group')
    }
    yield test_data
    if test_data.get('group_id'):
        adventuregame.delele_game_group(common_data.main_user_id_session, test_data['group_id'])

