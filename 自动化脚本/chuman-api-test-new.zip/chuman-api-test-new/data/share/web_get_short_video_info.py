import pytest
from data import common_data
from utils import common

_controller = 'share'


@pytest.fixture()
def web_get_short_video_info_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'web_get_short_video_info'),
        'share_token': 'S0N4WmtqelhSSzA9',
    }
    yield test_data
