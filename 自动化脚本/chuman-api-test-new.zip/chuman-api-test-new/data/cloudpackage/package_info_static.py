import pytest
from data import common_data
from utils import common
from api.app import cloudpackage

_controller = 'cloudpackage'


@pytest.fixture()
def package_info_static_data():

    session = common_data.main_user_id_session
    cloud_package_id = cloudpackage.category_package_list(session=session, category_id=10, editor_type=3).json()['data']['list'][0]['package_id']

    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'package_info_static'),
        'cloud_package_id': cloud_package_id,
        'system': 'android',
        'editor_type': '',
    }
    yield test_data
