import pytest
from data import common_data
from utils import common

_controller = 'cloudpackage'


@pytest.fixture()
def column_package_list_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'column_package_list'),
        'column_id': 34,
        'page': 1,
        'pagesize': 50,
        'block_size': 1,
        # 'category_id': '',
        # 'type': '',
        'history_list': '',
        'editor_type': '',
    }
    yield test_data
