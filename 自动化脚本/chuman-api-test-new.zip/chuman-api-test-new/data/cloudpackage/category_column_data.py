import pytest
from data import common_data
from utils import common

_control = "CloudPackage"


@pytest.fixture()
def get_category_column_data():
    test_data = {
        "session": common_data.main_user_id_session,
        "schema_file": common.get_schema_path(_control, "get_category_column")
                 }
    yield test_data
