import pytest
from data import common_data
from utils import common

_controller = 'cloudpackage'


@pytest.fixture()
def get_scene_package_info_by_column_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_scene_package_info_by_column'),
        'column_id': 0,
        'page': 1,
        'pagesize': 30,
    }
    yield test_data
