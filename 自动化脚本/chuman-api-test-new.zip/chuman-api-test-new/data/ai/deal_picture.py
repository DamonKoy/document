import pytest
from data import common_data
from utils import common

_controller = 'ai'


@pytest.fixture()
def deal_picture_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'deal_picture'),
        'pic_url': 'app/users/avatars/user_avatar_49550409_5f00e2c82c784753951f53fffe2f2444.jpg',
        'method': 'style_transfer',
        'type': 3,
        'model_index': 0,
        'model_name': 'UGATIT'
    }
    yield test_data
