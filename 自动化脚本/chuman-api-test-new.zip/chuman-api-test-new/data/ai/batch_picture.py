import pytest
from data import common_data
from utils import common

_controller = 'ai'


@pytest.fixture()
def batch_picture_data():
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'batch_picture'),
        'type': 3,
        'page': 1,
        'pagesize': 30
    }
    yield test_data
