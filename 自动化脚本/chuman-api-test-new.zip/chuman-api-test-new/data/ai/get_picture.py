import pytest
from data import common_data
from utils import common
from api.app import ai

_controller = 'ai'


@pytest.fixture()
def get_picture_data():
    deal_picture_data = {
        'pic_url': 'app/users/avatars/user_avatar_49550409_5f00e2c82c784753951f53fffe2f2444.jpg',
        'method': 'style_transfer',
        'type': 3,
        'model_index': 0,
        'model_name': 'UGATIT',
    }
    id = ai.deal_picture(common_data.main_user_id_session, request_info=deal_picture_data).json()["data"]["id"]
    test_data = {
        'session': common_data.main_user_id_session,
        'schema_file': common.get_schema_path(_controller, 'get_picture'),
        'id': id
    }
    yield test_data
