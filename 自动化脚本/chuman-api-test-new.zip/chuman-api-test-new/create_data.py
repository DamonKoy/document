# 这份文件需传入directory_name到方法里面，以及配置file_name_list列表

import os
#data目录地址
directory_path = os.path.join(os.getcwd(), "data")


#文件名,这里用api名字（需自己配置）
file_name_list = [
"get_content_list",
"share_drama_group",
]


def create_data(directory_name, file_name_list=file_name_list):
    """
    按新框架要求，以模块为单位，生成data下面某个模块的接口的data文件
    :param directory_name: data下面的目录名，如要生成chat模块的，就填"chat/"
    :param file_name_list: data/XX模块下面的文件名列表（即模块相关的接口列表）(建议自己整理一波模块中有被引用的接口，因为有一些接口虽然在
                          api文件中定义了，但是并没有相关的用例)，如api/app/chat.py里面只有一个接口send_friend_greet且有被引用来写用例，，那就在file_name_list
                          里面填send_friend_greet,有多个就填多个
    :return:
    """
    for name in file_name_list:
        file = os.path.join(directory_path, directory_name, name) + ".py"
        try:
            os.mkdir(directory_path + directory_name.replace("_", ""))
        except Exception as e:
            print(e, "123444")
        content = "import pytest\n" \
                  + "from data import common_data\n"\
                  + "from utils import common\n\n"\
                  + "_controller = '" + directory_name[:-1] + "'\n\n\n" \
                  + "@pytest.fixture()\n" \
                  + "def " + name + "_data():\n" \
                  + "    test_data = {\n" \
                  + "        'session': common_data.main_user_id_session,\n" \
                  + "        'schema_file': common.get_schema_path(_controller, '" + name + "')\n" \
                  + "    }\n" \
                  + "    yield test_data\n"

        with open(file, 'w') as f:
            f.write(content)
            f.close()


create_data("chumandrama/")


