# 这份文件只需传入api_module_name到方法里面

import os
import re
# api目录地址
directory_path = os.path.join(os.getcwd(), "api", "app")


def create_api(api_module_name):
    """
    按新框架要求，转换api文件, 填入要转换的api模块名，然后运行函数，就会生成一个以原来模块名后面加_new尾缀的文件，检查生成的内容如果没问题，就
    可以删掉的来的文件，用新生成的文件代替
    :param api_module_name: 要修改的api模块名
    :return:
    """
    file_name = os.path.join(directory_path, api_module_name) + ".py"

    # 读旧api模块内容并进行替换
    with open(file_name, 'r', encoding='utf-8') as fr:
        content = fr.read().replace("from utils.common import log_request_info", "from utils.decorators import log_request_info\nfrom utils.common import handle_test_data")
        content = re.sub(r'(\(session, .+\))', "(session, request_info=None)", content)
        content = re.sub(r'(\(session\))', "(session, request_info=None)", content)
        content = content.replace('return session.post(api_url, params=params, data=data)', "data = handle_test_data(data, request_info)\n    return session.post(api_url, params=params, data=data)")
        content = content.replace('return session.post(api_url, params=params)', "params = handle_test_data(params, request_info)\n    return session.post(api_url, params=params)")
        content = content.replace('return session.get(api_url, params=params, data=data)', "data = handle_test_data(data, request_info)\n    return session.get(api_url, params=params, data=data)")
        content = content.replace('return session.get(api_url, params=params)', "params = handle_test_data(params, request_info)\n    return session.get(api_url, params=params)")

        # 把替换后的肉空写入新文件中
        with open(directory_path + api_module_name + "_new.py", 'w', encoding='utf-8') as f:
            f.write(content)
            f.close()

        fr.close()


create_api('chumandrama')



