# Android测试

![android_test](http://o84t5lcxv.bkt.clouddn.com/e6a5b948e822815d3819218f6eafeb1e.png)

目前Google在大力推Espresso,
Robotium老牌但是积累雄厚.
Appium成了大众框架
Macaca是后起的新秀

# iOS测试

![ios_test](http://o84t5lcxv.bkt.clouddn.com/975ffa196dd3d3521ab7d4be9b2d17aa.png)

Uiautomation已经被apple抛弃
XCTest的体系开始崛起. 比如KIF XCUITest

# Appium
概念&原理：
http://std.mama.cn/testGroup/appium_share/blob/master/README.md

Appium 1.6.0 以上新特性：
* UI Automator 2 -> 支持 toast
* XCUITest