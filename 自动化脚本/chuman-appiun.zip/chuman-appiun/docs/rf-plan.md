# Robot Framework 孕管安卓 app UI 自动化测试工作计划

## 目的
利用 Robot Framework 对孕管安卓 app ，实现 UI 层的“[关键字驱动](http://blog.sina.com.cn/s/blog_54237fe101016r5b.html)”自动化测试

## 工具以及开源项目组成
* [python 2.7](https://www.python.org/) - 开发语言
* [Appium](http://appium.io/)==1.5.3 - 移动端测试框架
* [Robot Framework](http://robotframework.org/)==3.0 - 关键字驱动测试框架
* [robotframework-appiumlibrary](https://github.com/serhatbolsu/robotframework-appiumlibrary)==1.3.7 - RF扩展库
* [robotframework-ride](https://github.com/robotframework/RIDE) - RF图形化编辑器
* [app-inspector](https://macacajs.github.io/app-inspector/cn/) - 浏览器端的移动设备 UI 查看器
* [SimpleRegex/SRL-Python](https://github.com/SimpleRegex/SRL-Python) - python 简化正则匹配

## 计划范围
孕育管家安卓版 V5.4.1，测试环境，app UI层较稳定的功能，以及主流程，日常测试中重复操作可转化为自动化测试的功能点。参考主流程列表（部分实现）如下：
![list](http://o84t5lcxv.bkt.clouddn.com/2f8df3623ad384dcd7110198506a1a7e.png)

## 使用该方案已知的优点
* 自定义关键字可以用中文的形式编写流程用例，比较容易上手
* 结构化地分层组织元素、关键字，比较快速生成项目，原则上容易维护用例
* 有完善的 html 报告生成器，方便展示结果和查找log
* 有 jenkins 插件，方便展示测试结果和集成
* appium 是跨平台的，所以安卓端的用例以后部分可以复用在 IOS 端
* 可以将某些复杂的过程封装，并以关键字形式方便其他人使用

## 项目难点以及风险点
* UI层的自动化需要频繁适应版本变更
* 持续集成需要用到的设备以及部署方式，方便测试人员编写执行用例，方便用例按计划任务运行
* 分布式并行执行用例的运行方式，减少用例执行耗时
* 测试用例失败后的策略，区分失败原因并及时更新项目代码的方式
* 项目效果评估

## 实施步骤以及时间点
1. 09.19 - 09.23	实现基础 demo，包括按钮元素、变量、操作流程等的自定义用户关键字封装，实现5个主流程的测试用例
2. 09.26 - 09.30	实现更多主要流程用例，封装大部分元素、整理项目代码结构：
	* suite:某一功能的集合
	* case:核心事件-结果
	* keyword1:动作
	* keyword2:动作集合
	* 页面元素变量
3. 10.08 - 10.14	研究 webview 的测试方法，封装 webview 部分的关键字
4. 10.17 - 10.21	研究部署方式，设备的接入方式，并集成到 jenkins ；研究用例并行执行方式，**用例试运行**
5. 10.24 - 10.28	研究版本变更维护方案；研究更多扩展库的使用，添加更丰富的关键字和功能，满足数据驱动、丰富断言等需求
6. 10.31 - 11.04	整理 docker 环境，构建数据还原环境。
7. 11.07 - 11.11	整理持续集成环境，有需要的话重整安卓打包流程

如果前面积累的经验顺畅，之后是妈妈圈的时间安排：
* 11.14 - 11.25	二周完成妈妈圈主流程测试用例
* 11.28 - 11.30	妈妈圈 Robot Framework **测试项目部署**

## 课程培训安排
原则上需要每周一次，如果测试任务紧可能延期
1. 环境安装，基础知识，demo演示
2. RIDE工具使用，RF 知识加强：Resource 资源文件、变量和常量、Keyword 关键字、循环＆分支
3. 查找app元素工具，appium 知识加强：服务关键字、滑动操作、特殊动作等
4. RF 内置测试库
5. RF 的 Selenium2Library 扩展库使用，对 webview 进行测试
6. 部署方式，jenkins 集成，用例运行执行方式
7. 版本变更维护方式
8. RF 额外内容，其他扩展库，数据驱动等

## 工作计划输出清单：
1. 孕管安卓 app （妈妈圈 app）的 Robot Framework 自动化测试项目代码
2. jenkins UI自动化测试的构建任务，报告输出和邮件推送
3. Robot Framework 项目文档以及课程培训文档
4. 课程培训中录制的视频
