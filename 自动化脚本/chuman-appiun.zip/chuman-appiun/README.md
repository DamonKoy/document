# Robot Framework 孕管安卓 app UI 自动化测试
[![Build Status](http://jenkins.corp.mama.cn/jenkins/buildStatus/icon?job=rf-pregnancy)](http://jenkins.corp.mama.cn/jenkins/job/rf-pregnancy)

## requirements
* [python 2.7](https://www.python.org/) - 开发语言
* [Appium](http://appium.io/)==1.5.3 - 移动端测试框架
* [Robot Framework](http://robotframework.org/)==3.0 - 关键字驱动测试框架
* [robotframework-appiumlibrary](https://github.com/serhatbolsu/robotframework-appiumlibrary)==1.4.2 - RF扩展库

## 项目文档
1. [~~工作计划~~](docs/rf-plan.md)
2. [概览](docs/introduce.md)
3. [windows 环境安装教程](docs/install.md)
4. [查找 app 元素](docs/app-inspector.md)
5. [robotframework 的编辑器](docs/rf-editor.md)
6. [robotframework 使用基础](docs/rf-use-basics.md)
7. [appium 知识](docs/appium.md)

视频地址：链接:https://pan.baidu.com/s/1pL2FPQ7 密码:nts2