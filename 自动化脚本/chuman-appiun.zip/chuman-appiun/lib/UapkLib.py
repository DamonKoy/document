# coding=utf-8
import requests
import json


class UapkLib:

    def __init__(self):
        self.url_package = 'http://uapk.mama.cn/index.php/Home/Package/package'
        self.url_package_list = 'http://uapk.mama.cn/index.php/Home/Package/package_list'
        self.data = {'path': ''}

    def uapk_project(self):
        u"""获取安卓 apk 的项目简称
        """
        r = requests.post(self.url_package, data=self.data)
        r_json = self._get_json(r)
        return r_json['data']['pathList']

    def uapk_version(self, project):
        u"""获取安卓某项目的 apk 版本号
        """
        data = {'path': project}
        r = requests.post(self.url_package, data=data)
        r_json = self._get_json(r)
        return r_json['data']['pathList']

    def uapk_env(self, project):
        u"""获取安卓 apk 环境
        """
        data = {'path': project + '/' + self.uapk_version(project)}
        r = requests.post(self.url_package, data=data)
        r_json = self._get_json(r)
        return r_json['data']['pathList']

    def uapk_address(self, project, version=''):
        u"""获取安卓 apk 网络地址
         """
        if version == '':
            version = max(self.uapk_version(project))
        data = {'path': project + '/' + version + '/grey/',
                'page': 1, 'pageNum': 10}
        r = requests.post(self.url_package_list, data=data)
        r_json = self._get_json(r)
        return r_json['data']['packages'][0]['path']

    def _get_json(self, r):
        u"""对原 response 进行字符串分割
        """
        r_str = r.text.split('<', 1)
        r_json = json.loads(r_str[0])
        return r_json

# if __name__ == '__main__':
#     b = UapkLib()
#     a = b.uapk_address('pt', version='5.4.0')
#     print a

