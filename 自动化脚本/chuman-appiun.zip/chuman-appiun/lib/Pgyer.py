# -*- coding:utf-8 -*-
import requests
import json
from time import sleep
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities


class Pgyer:
    def __init__(self):
        self._api_key = '036e2e6c23594c33e98c6ea4cd4b46a7'
        self.uKey = 'ac1eeac86dcb2234aefd10e6141794da'
        self.aId = 'dcd4cb785ee03df03e02f91b73165449'

    def upload(self, file_path, description, publish_range=2, to_public=2, password=''):
        u"""上传App"""
        url = 'http://www.pgyer.com/apiv1/app/upload'
        data = {'uKey': self.uKey, '_api_key': self._api_key,
                'publishRange': publish_range,
                'isPublishToPublic': to_public, 'password': password,
                'updateDescription': description}
        files = {'file': open(file_path, 'rb')}
        headers = {'enctype': 'multipart/form-data'}
        r = requests.post(url, data=data, files=files, headers=headers)
        return r.json()

    def install(self, app_version, password=''):
        u"""安装某版本App"""
        a_key = self._get_a_key(app_version)[-1]
        url = 'http://www.pgyer.com/apiv1/app/install'
        data = {'aKey': a_key, '_api_key': self._api_key, 'password': password}
        r = requests.get(url, data=data)
        return r.json()

    def view(self, app_version):
        u"""获取某版本App详细信息"""
        a_key = self._get_a_key(app_version)[-1]
        url = 'http://www.pgyer.com/apiv1/app/view'
        data = {'aKey': a_key, '_api_key': self._api_key, 'uKey': self.uKey}
        r = requests.post(url, data=data)
        dict = json.loads(r.text)
        return json.dumps(dict, ensure_ascii=False, indent=1)

    def view_group(self):
        u"""获取App组详细信息"""
        url = 'http://www.pgyer.com/apiv1/app/viewGroup'
        data = {'aId': self.aId, '_api_key': self._api_key}
        r = requests.post(url, data=data)
        return r.json()

    def builds(self):
        u"""获取App所有版本"""
        url = 'http://www.pgyer.com/apiv1/app/builds'
        data = {'aId': self.aId, '_api_key': self._api_key, 'uKey': self.uKey, 'page': '1'}
        r = requests.post(url, data=data)
        return r.json()

    def shortcut(self):
        u"""验证App短链接"""
        url = 'http://www.pgyer.com/apiv1/app/getAppKeyByShortcut'
        data = {'_api_key': self._api_key, 'shortcut': 'YYGJ'}
        r = requests.post(url, data=data)
        return r.json()

    def delete(self, a_key):
        u"""删除指定aKey的一个apk"""
        driver = webdriver.Remote(command_executor='http://192.168.14.45:4444/wd/hub',
                                  desired_capabilities=DesiredCapabilities.CHROME)
        driver.get('https://www.pgyer.com/user/login')
        driver.find_element_by_id('email').send_keys('2453557220@163.com')
        driver.find_element_by_id('password').send_keys('mama1234')
        driver.find_element_by_id('submitButton').click()
        driver.get('https://www.pgyer.com/manager/version/index/' + self.aId)
        js = 'javascript:deleteApp(\'' + a_key + '\');'
        try:
            driver.execute_script(js)
        except:
            pass
        driver.switch_to.alert.accept()
        driver.quit()

    def delete_version(self, app_version):
        u"""批量删除某个版本的apk"""
        a_key_list = self._get_a_key(app_version)[:-1]
        print a_key_list
        driver = webdriver.Remote(command_executor='http://192.168.14.45:4444/wd/hub',
                                  desired_capabilities=DesiredCapabilities.CHROME)
        driver.get('https://www.pgyer.com/user/login')
        driver.find_element_by_id('email').send_keys("2453557220@163.com")
        driver.find_element_by_id('password').send_keys("mama1234")
        sleep(1)
        driver.find_element_by_id('submitButton').click()
        sleep(2)
        driver.get('https://www.pgyer.com/manager/version/index/' + self.aId)
        sleep(2)
        for a_key in a_key_list:
            js = 'javascript:deleteApp(\'' + a_key + '\');'
            try:
                driver.execute_script(js)
            except:
                pass
            driver.switch_to.alert.accept()
        driver.quit()
        return 'delete finish'

    def download(self, app_version):
        u"""下载某个版本最新的apk"""
        a_key = self._get_a_key(app_version)[-1]
        print a_key
        r = requests.get('http://www.pgyer.com/apiv1/app/install?'
                         '_api_key=' + self._api_key +
                         '&aKey=' + a_key)
        with open("../APP/pregnancy.apk", "wb") as code:
            code.write(r.content)
        return 'download finish'

    def _get_a_key(self, app_version):
        r = self.view_group()
        a_key_list = []
        for a in r['data']:
            if a['appVersion'] == app_version:
                a_key_list.append(a['appKey'])
        return a_key_list

#if __name__ == '__main__':
    #    run = Pgyer()
    # for a in range(1, 6):
    #    run.upload(file_path='pregnancy_5.3.0.apk', description='api_5.3.0_' + str(a))
    #print run.delete_version('5.3.0')
    #print run.download('5.3.0')
    #print run.view('5.3.0')
