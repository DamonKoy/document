# -*- coding:utf-8 -*-
import datetime


class Getdate:
    def compare_today(self, date):
        u"""判断是否与今天日期相同"""
        now = datetime.datetime.now().date()
        month = int(now.strftime('%m'))
        day = int(now.strftime('%d'))
        today = str(month)+'月'+str(day)+'日'
        today = today.decode('utf8')
        #print month,day,today
        if(date == today):
            return True
        else:
            raise AssertionError(u'日期不相等')

    def compare_yesterday(self, date):
        u"""判断是否与昨天日期相同"""
        day = datetime.datetime.now().date() - datetime.timedelta(days=1)
        month = int(day.strftime('%m'))
        day = int(day.strftime('%d'))
        yesterday = str(month) + '月' + str(day) + '日'
        yesterday = yesterday.decode('utf8')
        #print month,day,yesterday
        if (date == yesterday):
            return True
        else:
            raise AssertionError(u'日期不相等')

    def compare_tomorrow(self, date):
        u"""判断是否与明天日期相同"""
        day = datetime.datetime.now().date() + datetime.timedelta(days=1)
        month = int(day.strftime('%m'))
        day = int(day.strftime('%d'))
        tomorrow = str(month) + '月' + str(day) + '日'
        tomorrow = tomorrow.decode('utf8')
        #print month, day, tomorrow
        if (date == tomorrow):
            return True
        else:
            raise AssertionError(u'日期不相等')

# if __name__ == '__main__':
#     print Getdate().compare_yesterday(u"3月24日")
